import type { Config } from "tailwindcss";
import typography from "@tailwindcss/typography";
import forms from "@tailwindcss/forms"; // Added this import

export default {
  content: ["./app/**/*.{js,jsx,ts,tsx}"],
  darkMode: 'class', // Added for dark mode
  theme: {
    extend: {
      colors: {
        primary: { // Indigo palette from ui-enhancement-plan
          50: '#EEF2FF',
          100: '#E0E7FF',
          200: '#C7D2FE',
          300: '#A5B4FC',
          400: '#818CF8',
          500: '#6366F1', // Main primary
          600: '#4F46E5', // Darker primary
          700: '#4338CA',
          800: '#3730A3',
          900: '#312E81',
          950: '#1E1B4B',
        },
        secondary: { // Teal palette from ui-enhancement-plan
          50: '#F0FDFA',
          100: '#CCFBF1',
          200: '#99F6E4',
          300: '#5EEAD4',
          400: '#2DD4BF',
          500: '#14B8A6', // Main secondary
          600: '#0D9488', // Darker secondary
          700: '#0F766E',
          800: '#115E59',
          900: '#134E4A',
          950: '#062F2C',
        },
        neutral: { // Slate palette for backgrounds/text
          50: '#F8FAFC',  // Lightest background for light mode
          100: '#F1F5F9', // Default light page background
          200: '#E2E8F0', // Light borders, subtle text for dark mode
          300: '#CBD5E1', // Medium-light text for dark mode
          400: '#94A3B8', // Muted text for light mode
          500: '#64748B', // Default text for light mode
          600: '#475569', // Stronger text for light mode, subtle borders for dark
          700: '#334155', // Default borders for dark mode, card backgrounds
          800: '#1E293B', // Darker card backgrounds for dark mode
          900: '#0F172A', // Default page background for dark mode
          950: '#0B111E', // Deepest dark for accents or specific elements
        },
        // Semantic aliases for easier theming (optional but recommended)
        // These can be adjusted based on final choices for neutral shades
        'page-background-light': '#F1F5F9', // neutral-100
        'page-background-dark': '#0F172A',   // neutral-900
        'text-light': '#334155',             // neutral-700 (can also use primary/secondary)
        'text-dark': '#E2E8F0',              // neutral-200 (can also use primary/secondary)
        'card-background-light': '#FFFFFF',
        'card-background-dark': '#1E293B',   // neutral-800
        'border-light': '#E2E8F0',           // neutral-200
        'border-dark': '#334155',            // neutral-700
      },
      typography: ({ theme }) => ({
        DEFAULT: {
          css: {
            '--tw-prose-body': theme('colors.neutral[700]'),
            '--tw-prose-headings': theme('colors.neutral[800]'),
            '--tw-prose-lead': theme('colors.neutral[600]'),
            '--tw-prose-links': theme('colors.primary[600]'),
            '--tw-prose-bold': theme('colors.neutral[800]'),
            '--tw-prose-counters': theme('colors.neutral[500]'),
            '--tw-prose-bullets': theme('colors.neutral[400]'),
            '--tw-prose-hr': theme('colors.neutral[300]'), // Adjusted for better visibility in light
            '--tw-prose-quotes': theme('colors.neutral[800]'),
            '--tw-prose-quote-borders': theme('colors.neutral[300]'), // Adjusted
            '--tw-prose-captions': theme('colors.neutral[500]'),
            '--tw-prose-code': theme('colors.neutral[800]'), // Code text color
            '--tw-prose-pre-code': theme('colors.neutral[800]'), // Code block text color
            '--tw-prose-pre-bg': theme('colors.neutral[100]'),   // Code block background
            '--tw-prose-th-borders': theme('colors.neutral[400]'), // Adjusted
            '--tw-prose-td-borders': theme('colors.neutral[300]'), // Adjusted
            // Invert/Dark mode styles
            '--tw-prose-invert-body': theme('colors.neutral[300]'),
            '--tw-prose-invert-headings': theme('colors.neutral[100]'),
            '--tw-prose-invert-lead': theme('colors.neutral[400]'),
            '--tw-prose-invert-links': theme('colors.primary[400]'),
            '--tw-prose-invert-bold': theme('colors.neutral[100]'),
            '--tw-prose-invert-counters': theme('colors.neutral[500]'),
            '--tw-prose-invert-bullets': theme('colors.neutral[600]'), // Adjusted for better visibility in dark
            '--tw-prose-invert-hr': theme('colors.neutral[700]'),
            '--tw-prose-invert-quotes': theme('colors.neutral[100]'),
            '--tw-prose-invert-quote-borders': theme('colors.neutral[700]'),
            '--tw-prose-invert-captions': theme('colors.neutral[500]'),
            '--tw-prose-invert-code': theme('colors.neutral[100]'), // Dark mode code text
            '--tw-prose-invert-pre-code': theme('colors.neutral[100]'), // Dark mode code block text
            '--tw-prose-invert-pre-bg': theme('colors.neutral[800]'),    // Dark mode code block background
            '--tw-prose-invert-th-borders': theme('colors.neutral[600]'),
            '--tw-prose-invert-td-borders': theme('colors.neutral[700]'),
          },
        },
      }),
      boxShadow: {
        'card': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        'button': '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      },
      borderRadius: {
        'xl': '1rem', // Tailwind's default rounded-xl is 0.75rem, this is larger
        '2xl': '1.5rem',// Tailwind's default rounded-2xl is 1rem, this is larger
      },
    },
  },
  plugins: [
    typography,
    forms // Added @tailwindcss/forms
  ],
} satisfies Config;
