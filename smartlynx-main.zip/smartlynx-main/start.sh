#!/bin/sh -ex

# This file is how Fly starts the server (configured in fly.toml). Before starting
# the server though, we need to run any prisma migrations that haven't yet been
# run, which is why this file exists in the first place.
# Learn more: https://community.fly.io/t/sqlite-not-getting-setup-properly/4386

echo "Running database migrations for main database..."
npm run prisma:migrate:deploy:main

echo "Running database migrations for analytics database..."
npm run prisma:migrate:deploy:analytics

echo "Starting application..."
npm run start
