# Plan: Revoked Link Management & Cleanup

This document outlines the plan to implement a comprehensive strategy for managing revoked links, including making revocation reversible, adding manual permanent deletion, and implementing automatic cleanup of old revoked links and their associated data.

## Goals

1.  Allow users to reactivate (unrevoke) links they previously revoked.
2.  Provide users with an option to permanently delete revoked links immediately.
3.  Implement an automatic cleanup process to permanently delete links (and associated data) that have been revoked for a defined period (e.g., 30 days).
4.  Free up database space (main and analytics) and S3 storage used by old, unwanted revoked links.

## Implementation Steps

1.  **Schema Change (`SharedLink` Model):**
    *   **File:** `prisma/schema.prisma`
    *   **Action:** Add an optional `revokedAt` field (`DateTime?`) to the `SharedLink` model.
    *   **Follow-up:** Generate and run a database migration (`npx prisma migrate dev --name add_revoked_at_to_sharedlink`).

2.  **Update Revoke/Unrevoke Logic:**
    *   **File:** `app/routes/dashboard.tsx` (Action Function)
    *   **Action (Revoke Intent):** Modify the `revoke` intent handler:
        *   Set `revoked = true`.
        *   Set `revokedAt = new Date()`.
    *   **Action (Unrevoke Intent):** Add a new `unrevoke` intent handler:
        *   Verify the link belongs to the user.
        *   Set `revoked = false`.
        *   Set `revokedAt = null`.
    *   **File:** `app/routes/dashboard.tsx` (UI Component)
    *   **UI (Active Links Tab):** Keep the "Revoke" button (triggers `revoke` intent).
    *   **UI (Revoked Links Tab):** Replace the disabled "Revoked" button with an active "Reactivate" button (triggers `unrevoke` intent).

3.  **Implement Manual Permanent Deletion:**
    *   **File:** `app/routes/dashboard.tsx` (UI Component)
    *   **UI:** Add a "Delete Permanently" button next to "Reactivate" on the "Revoked Links" tab.
    *   **UI:** Implement a simple client-side confirmation modal (e.g., using `window.confirm` initially, or a custom modal component) triggered by the "Delete Permanently" button.
    *   **File:** `app/routes/dashboard.tsx` (Action Function)
    *   **Action (Delete Intent):** Add a new `delete-permanently` intent handler:
        *   Verify the link exists, belongs to the user, and `revoked` is true.
        *   Call `deleteAnalyticsEventsForLink(linkId)`.
        *   Call `deleteFileFromS3(storageKey)`.
        *   Delete the `SharedLink` record using `prisma.sharedLink.delete()`.
    *   **File:** `app/models/analytics.server.ts`
    *   **Backend:** Create a new function `deleteAnalyticsEventsForLink(linkId: string)` that uses the analytics Prisma client (`@prisma/analytics-client`) to delete all `AnalyticsEvent` records where `linkId` matches.
    *   **File:** `app/s3.server.ts`
    *   **Backend:** Create a new function `deleteFileFromS3(storageKey: string)` that uses the AWS SDK (`DeleteObjectCommand`) to delete the object from the S3 bucket. Handle potential errors.

4.  **Implement Automatic Deletion (Scheduled Job):**
    *   **File:** Create `app/routes/api.cron.delete-revoked-links.ts` (or similar).
    *   **API Route Logic:**
        *   Protect the route (e.g., check for a secret header/token passed by the cron job runner).
        *   Calculate the date 30 days ago.
        *   Find `SharedLink` records where `revoked: true` AND `revokedAt < thirtyDaysAgo`.
        *   Loop through the found links:
            *   Call `deleteAnalyticsEventsForLink(link.id)`.
            *   Call `deleteFileFromS3(link.storageKey)`.
            *   Delete the `SharedLink` record (`prisma.sharedLink.delete({ where: { id: link.id } })`).
        *   Log results (how many links processed/deleted).
        *   Return a success response.
    *   **File:** `vercel.json` (or create if it doesn't exist)
    *   **Configuration:** Add a Vercel Cron Job definition to trigger the API route daily. Example:
        ```json
        {
          "crons": [
            {
              "path": "/api/cron/delete-revoked-links",
              "schedule": "0 5 * * *" // Run daily at 5:00 AM UTC
            }
          ]
        }
        ```
        *Note: The cron path needs protection.*

5.  **Add UI Disclaimer:**
    *   **File:** `app/routes/dashboard.tsx` (UI Component)
    *   **UI:** Add a small text element above the list on the "Revoked Links" tab: "Note: Revoked links are automatically deleted after 30 days."

## Considerations

*   **Error Handling:** Ensure robust error handling in the deletion functions (analytics, S3, main DB) and the cron job route.
*   **Cron Job Security:** The cron job endpoint needs protection to prevent unauthorized execution (e.g., checking a secret environment variable passed in the request).
*   **Database Load:** For the automatic deletion job, consider potential load if many links need deletion simultaneously. Process in batches if necessary.
*   **User Notification:** Decide if users should be notified before automatic deletion (likely overkill, the disclaimer should suffice).
*   **Retention Period:** Confirm 30 days is the desired retention period for revoked links before automatic deletion.
