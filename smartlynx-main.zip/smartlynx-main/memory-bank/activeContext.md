# Active Context: SmartLynx (As of 2025-05-11 ~22:45 MDT)

## 1. Current Focus

*   **Dark Mode Implementation (Phase 1):** Actively working on implementing the foundational elements of dark mode as per the UI Enhancement Plan. This includes Tailwind configuration, ThemeContext, ThemeToggle, and initial styling of global elements and key pages.
*   **Address Critical Test Coverage Gaps:** (Temporarily superseded by Dark Mode work) Implement missing unit/integration tests for Stripe and Branding actions in `dashboard.tsx`, the action in `link.$accessKey.tsx`, and dashboard loader filter logic. Update E2E tests for UI changes and user cleanup. Cypress end-to-end testing has been removed and will be replaced with a new E2E testing strategy.
*   **UI Enhancement Plan Implementation:** (Phase 1 in progress)
*   **Refinement:** Consider adding legal page links to Auth0 Universal Login pages if possible.

## 2. Recent Changes

*   **Dark Mode Foundation (Current Session - 2025-05-16):**
    *   Updated `tailwind.config.ts` to enable `darkMode: 'class'`, defined extended color palettes (Primary: Indigo, Secondary: Teal, Neutral: Slate) with light/dark variants, added semantic color aliases, and configured `@tailwindcss/forms`.
    *   Created `app/contexts/ThemeContext.tsx` with `ThemeProvider` and `useTheme` hook to manage theme state (light/dark), localStorage persistence, and system preference detection.
    *   Wrapped the application in `app/root.tsx` with `ThemeProvider`.
    *   Created `app/components/ThemeToggle.tsx` with SVG icons (Sun/Moon) to switch themes.
    *   Integrated `ThemeToggle` into `app/components/Header.tsx`.
    *   Applied theme-aware global styles (body background, text colors) in `app/root.tsx` and updated `Footer` styles.
    *   Updated `app/components/Header.tsx` with theme-aware background and text colors.
    *   Applied initial dark mode styling to key pages:
        *   `app/routes/_index.tsx` (Landing Page)
        *   `app/routes/dashboard.tsx` (Dashboard - main layout, cards, buttons)
        *   `app/routes/link.$accessKey.tsx` (Public Link Page)
    *   Installed `@tailwindcss/forms` dependency.
    *   Updated `tailwind.config.ts` with typography overrides for dark mode to improve readability on prose-styled pages.
    *   Added `dark:prose-invert` to `app/routes/terms-of-service.tsx` and `app/routes/privacy.tsx` to apply dark mode typography.
    *   Resolved `@prisma/analytics-client` not found error by performing a clean build.

*   **Code Review Critical Fixes (May 2025):**
    *   Implemented a series of critical fixes identified during a comprehensive code review.
    *   **Deployment:** Corrected Dockerfile (PostgreSQL alignment, Prisma generation) and start.sh (migrations for both DBs). Updated .dockerignore.
    *   **Testing:** Added missing mock for `prismaAnalytics` in test setup. Added tests for `getAnalyticsEventCountsForLink`.
    *   **Dependencies:** Removed unused packages (`animejs`, `bcryptjs`, `puppeteer`). Installed and configured `@tailwindcss/typography`.
    *   **Prisma:** Cleaned up `analytics.schema.prisma` (removed stub) and `seed.ts` (removed bcrypt comments).
    *   **Code Cleanup:** Addressed dead/commented code, unused variables/imports, and minor refactors in `app/utils.ts`, `app/routes/_index.tsx`, `app/components/LocalTime.tsx`, `app/routes/link.$accessKey.tsx`, `app/routes/presign-logo-upload.tsx`, `app/models/analytics.server.ts`, and `vitest.config.ts`.

*   **Link Expiry Timezone Fix (Major):**
    *   Diagnosed and resolved complex timezone handling issues affecting the link expiry feature across local and production environments.
    *   Initial attempts using built-in `Date` parsing proved inconsistent between environments.
    *   Installed `date-fns` and `date-fns-tz` libraries for robust date/time manipulation.
    *   Refactored `formatDateTimeLocal` in `app/utils.ts` to use `date-fns`'s `format` for consistent local time display in the `datetime-local` input.
    *   Refactored `parseLocalDateTime` in `app/utils.ts` to use `date-fns-tz`'s `fromZonedTime`, requiring the client's IANA timezone name to be passed.
    *   Updated `app/routes/dashboard.tsx` component to:
        *   Capture the client's IANA timezone name using `Intl.DateTimeFormat().resolvedOptions().timeZone` in a `useEffect` hook.
        *   Include a hidden input field (`clientTimezone`) in the expiry form.
    *   Updated the `update-expiry` action in `app/routes/dashboard.tsx` to read the `clientTimezone` from form data and pass it to `parseLocalDateTime`, ensuring correct UTC conversion.
    *   Resolved intermittent build errors related to `@prisma/analytics-client` by cleaning `node_modules`/`build` and reinstalling/rebuilding.

*   **Dashboard Link Expiry UI Fix (Previous Iteration):**
    *   Fixed the "Clear" button for link expiration dates in `app/routes/dashboard.tsx`.
    *   Refactored the expiry form to use `useFetcher` (`linkActionFetcher`).
    *   Modified the `update-expiry` action to return a `cleared: true` flag upon successful clearing.
    *   Added a `useEffect` hook to watch the `linkActionFetcher` state:
        *   If `cleared` is true in the fetcher data (indicating a successful clear action), the hook retrieves the corresponding form reference via `expiryFormRefs` and calls `.reset()` on it. This clears the date input visually by resetting it to its default value (which becomes empty after revalidation).
        *   Triggers `revalidator.revalidate()` after any successful `update-expiry` action (save or clear) to update the displayed expiry text, button visibility, and the input's `defaultValue`.

*   **Error Handling Improvements (Iterative):**
    *   Implemented Global Error Boundary in `app/root.tsx` to catch unhandled errors and display user-friendly fallback UI (including specific 404/401 messages).
    *   Added server-side `try...catch` blocks around critical database/API calls in `app/routes/link.$accessKey.tsx` (loader/action), `app/routes/dashboard.tsx` (create-link-record, Stripe session actions), and `app/routes/api.analytics.$linkId.ts` (loader), ensuring 500 errors are caught and logged.
    *   Improved client-side error feedback in `app/routes/dashboard.tsx` to display specific errors returned from file upload and link management actions contextually.
    *   Verified and refined error handling in Stripe webhook handler (`app/routes/api.stripe.webhooks.ts`).
    *   Added server-side `try...catch` around database writes in less critical dashboard actions (`revoke`, `update-expiry`, `update-description`, branding actions).

*   **Stripe E2E Testing:**
    *   Created new Cypress spec file `cypress/e2e/stripe.cy.ts`.
    *   Implemented Cypress task (`updateUserSubscription` in `cypress/tasks/db.ts`) for simulating webhook effects by updating the test database.
    *   Registered the task in `cypress.config.ts`.
    *   Updated `cy.login()` command (`cypress/support/commands.ts`) and `create-user.ts` script to support creating users with specific plans/Stripe details and perform UI login.
    *   Implemented E2E tests covering upgrade initiation, billing portal initiation, and UI updates after simulated upgrade/cancellation webhooks.
    *   Updated `tsconfig.json` to correctly include Cypress task/support files for type-checking/linting.

*   **Legal Pages Refinement:**
    *   Updated placeholder contact information in `privacy.tsx` and `terms-of-service.tsx` with actual contact details.
    *   Completed the refinement of legal pages for production readiness.

*   **Auth0 Production Credentials:**
    *   Replaced Auth0 development keys with production keys for all connections (including social logins).
    *   Ensured the authentication system is fully production-ready.

*   **Analytics Database Separation:**
    *   Created a separate PostgreSQL database (`smartlynx-analytics`) for analytics events.
    *   Defined a new Prisma schema (`prisma/analytics.schema.prisma`) for the analytics database.
    *   Added `ANALYTICS_DATABASE_URL` environment variable.
    *   Generated a separate Prisma client (`@prisma/analytics-client`) for the analytics database.
    *   Created a dedicated service (`app/analytics.db.server.ts`) for the analytics Prisma client instance.
    *   Updated analytics model functions (`app/models/analytics.server.ts`) to use the new client and schema.
    *   Removed analytics models (`AnalyticsEvent`, `EventType`) from the main Prisma schema (`prisma/schema.prisma`).
    *   Created and applied migrations for both databases to reflect the schema changes.
    *   Updated relevant code (`app/routes/link.$accessKey.tsx`) and unit tests (`app/models/analytics.server.test.ts`, `app/routes/api.analytics.$linkId.test.ts`) to use the new structure.
    *   Updated seed script (`prisma/seed.ts`) to remove references to old models.
    *   Updated documentation (`.env.example`, `systemPatterns.md`, `techContext.md`).
*   **Branding Implementation (Pro Feature):**
    *   Integrated branding settings (logo upload, color pickers) into a collapsible section within `app/routes/dashboard.tsx`.
    *   Added backend logic (`update-branding-colors`, `save-logo-url`, `remove-logo` intents) to the dashboard action function.
    *   Created `/presign-logo-upload` route to handle secure logo uploads to S3 with image validation, size limits, and `public-read` ACL.
    *   Updated `/link/:accessKey` route to fetch and display the owner's logo and apply brand colors (primary color as top border and button background, text color on button) for Pro users.
    *   Fixed associated bugs: invalid URL error on save, infinite loop after upload/removal, S3 permissions (`403 Forbidden` on GET and POST), and public link page layout issues.
    *   Removed the unused `/dashboard/branding` route file.

*   **Feature Gating Implementation:**
    *   Implemented link limit for free users (maximum of 5 active links).
    *   Added backend check in `create-link-record` action to prevent free users from exceeding the limit.
    *   Created a modal that appears when a free user tries to upload a 6th file, with options to upgrade or manage existing links.
    *   Restricted detailed analytics access for free users by showing an upgrade overlay in the analytics modal.
    *   Fixed analytics modal sizing issues to ensure the upgrade message is fully visible without scrolling.
    *   Removed "Error:" prefix from error messages for a cleaner user experience.
    *   Ensured both features provide clear upgrade paths to encourage Pro plan subscriptions.

*   **Stripe Integration (Checkout & Billing Portal):**
    *   Configured Stripe Product ("SmartLynx Pro") and Price ($15/month).
    *   Set up production and local webhook endpoints (`/api/stripe/webhooks`) for subscription events.
    *   Added required Stripe environment variables (`STRIPE_SECRET_KEY`, `STRIPE_PUBLIC_KEY`, `STRIPE_PRO_PRICE_ID`, `STRIPE_WEBHOOK_SECRET`) locally and in production (Vercel).
    *   Implemented backend logic in `app/routes/dashboard.tsx` action to create Stripe Checkout sessions (for upgrades) and Billing Portal sessions (for management).
    *   Added conditional UI buttons ("Upgrade to Pro", "Manage Billing") to `app/routes/dashboard.tsx` based on user plan fetched in the loader.
    *   Debugged and fixed webhook handler (`app/routes/api.stripe.webhooks.ts`) to correctly process `checkout.session.completed` events (robust ID handling, fixed 308 redirect issue by updating endpoint URL in Stripe, configured Customer Portal settings in Stripe).
*   **Legal Pages:**
    *   Created `app/routes/privacy.tsx` with template Privacy Policy content.
    *   Created `app/routes/terms-of-service.tsx` with template Terms of Service content.
*   **UI/UX Improvements:**
    *   Added a consistent site-wide footer component to `app/root.tsx` with links to legal pages and copyright info. Implemented sticky footer layout.
    *   Corrected post-authentication redirect in `app/routes/callback.tsx` to target `/dashboard`.
    *   Fixed footer layout inconsistency on landing page (`app/routes/_index.tsx`) by removing nested `<main>` tag.
*   **Documentation:** Updated `productContext.md` with the decided Pro plan price.
*   **(Previous Session):** Improved Landing Page Mobile Responsiveness, Added Subtle Background Color, Improved Dashboard Mobile Responsiveness, Implemented Analytics Display (Modal), Implemented Analytics Event Recording (MVP), Fixed SSR Error & Bolstered Test Coverage, Completed Email Service Integration (SendGrid), Fixed Dashboard Test Assertion, Fixed File Upload Bugs, Completed Link Management Enhancements, Fixed Unit Test Failures.

*   **Improved Dashboard Mobile Responsiveness:** Adjusted Tailwind classes in `app/routes/dashboard.tsx` to improve layout on smaller viewports (header stacking, link item stacking, action button wrapping/stacking).

*   **Implemented Analytics Display (Modal):**
    *   Added `getAnalyticsEventsForLink` function to `app/models/analytics.server.ts` for fetching paginated events.
    *   Created resource route `app/routes/api.analytics.$linkId.ts` to serve analytics data.
    *   Added state management, fetcher logic, and the `AnalyticsModal` component to `app/routes/dashboard.tsx`.
    *   Made the "Views/Downloads" count clickable to trigger the modal.
    *   Modal displays a paginated table of 'VIEW'/'DOWNLOAD' events with timestamps.
    *   Fixed related TypeScript/ESLint issues during implementation.

*   **Implemented Analytics Event Recording (MVP):**
    *   Added `AnalyticsEvent` model to `prisma/schema.prisma` to store 'VIEW' and 'DOWNLOAD' events.
    *   Created migration `20250418000957_add_analytics_event_model` and updated Prisma Client.
    *   Created `app/models/analytics.server.ts` with `recordLinkViewEvent` function for safe event recording.
    *   Integrated event recording into `app/routes/link.$accessKey.tsx`:
        *   'VIEW' events recorded in the `loader`.
        *   'DOWNLOAD' events recorded in the `action`.
    *   Corrected related TypeScript/ESLint issues during implementation.

*   **Fixed SSR Error & Bolstered Test Coverage (This Session):**
    *   Resolved `ReferenceError: window is not defined` on dashboard refresh by removing client-side `window.location.origin` access during SSR in `app/routes/dashboard.tsx`.
    *   Added unit tests for `update-expiry`, `update-description`, and `share-link` actions in `app/routes/dashboard.test.tsx`.
    *   Enhanced E2E test (`cypress/e2e/core-flow.cy.ts`) to cover editing description, setting/clearing expiry, and sharing via email UI interactions. Updated test to correctly capture the public link URL via clipboard stubbing after the removal of the `data-link-url` attribute.
*   **Completed Email Service Integration (SendGrid) (Previous Session):**
    *   Successfully integrated `app/email.server.ts` utility into the dashboard.
    *   Confirmed end-to-end functionality via manual testing: sending emails, receiving them, accessing links, downloading files, and verifying revoked link behavior.
*   **Fixed Dashboard Test Assertion:** Corrected assertion in `app/routes/dashboard.test.tsx` for the `revoke` action response. (Previous session)
*   **Fixed File Upload Bugs (Local & Production):**
    *   Corrected AWS IAM policy for `smartlynx-app-user` to grant permissions to the correct S3 bucket (`smartlynx1` instead of `smartlynx-app`).
    *   Updated S3 bucket (`smartlynx1`) CORS configuration to include the `https://www.smartlynx.app` origin, resolving production upload failures.
    *   Fixed `app/routes/dashboard.tsx` action logic to correctly handle the `create-link-record` intent without requiring a `linkId`.
    *   Resolved a potential infinite loop in the `app/routes/dashboard.tsx` `useEffect` hook that handles upload success by adding a state flag (`hasProcessedUpload`).
    *   Verified AWS credentials and bucket name are correctly configured in local `.env` and production environment variables.
*   **Completed Link Management Enhancements (Dashboard - `app/routes/dashboard.tsx`):**
    *   Implemented setting/updating link expiry (UI + `update-expiry` action).
    *   Implemented editing link description (UI + `update-description` action).
    *   Implemented "Copy Link" button functionality (client-side JS).
    *   Added `formatDateTimeLocal` utility function (`app/utils.ts`).
*   **(Previous Session):** Fixed Unit Test Failures (Details omitted for brevity, see previous context).
    *   **`app/routes/login.test.tsx`:** Fixed redirect handling assertions (checking returned `Response` instead of expecting throws) and resolved `vi.mock` hoisting issues by defining mocks inside the factory. Fixed ESLint import order.
    *   **`app/routes/signup.test.tsx`:** Fixed redirect handling assertions and resolved `vi.mock` hoisting issues similarly to `login.test.tsx`. Fixed ESLint import order.
    *   **`app/routes/link.$accessKey.test.tsx`:** Fixed assertions for thrown `Response` objects using `try...catch` blocks to avoid internal comparison errors.
    *   **`app/s3.server.ts`:** Moved the `AWS_S3_BUCKET_NAME` invariant check from the module level into the functions (`uploadFileToS3`, `getSignedDownloadUrl`) to prevent errors during test setup before environment variables are loaded.
*   *(Previous changes from prior sessions remain relevant)*
    *   Fixed `_index.tsx` Animation TypeScript Issue.
    *   Implemented CSRF Protection (State Parameter).
    *   Implemented dashboard link display.
    *   Implemented public link access page (`/link/:accessKey`).
    *   Implemented link revocation on dashboard.
    *   Added "Copy Link" button stub.
    *   Completed baseline testing coverage phase.
    *   Installed `@aws-sdk/s3-request-presigner`.
    *   Large File Upload Refactoring Completed (Direct-to-S3).
    *   Landing Page Enhancements Completed (Static Version).

## 3. Next Steps (Immediate)

*   **Address Critical Test Coverage Gaps:**
    *   Implement missing unit/integration tests for Stripe and Branding action intents in `app/routes/dashboard.test.tsx`.
    *   Implement missing unit/integration tests for the loader's filter logic in `app/routes/dashboard.test.tsx`.
    *   Implement missing tests for the `action` function in `app/routes/link.$accessKey.test.tsx`.
    *   Update `cypress/e2e/core-flow.cy.ts` for current UI (upload flow) and implement a robust user cleanup strategy.
    *   Review and potentially enhance other E2E tests (`stripe.cy.ts`, `upload.cy.ts`).
*   **UI Enhancement Plan Implementation:**
    *   **Phase 1 (In Progress):** Set up Tailwind theme extension, implement dark mode with ThemeContext, and update global component styling.
    *   **Phase 2 (Next):** Enhance core UI components including header, dashboard layout, link items, and modals.
    *   **Phase 3 (Future):** Redesign landing page with improved hero section, feature showcase, and call-to-action.
    *   **Phase 4 (1-2 days):** Polish public link page and add micro-interactions throughout the app.
*   **Refinement:** Consider adding legal page links to Auth0 Universal Login pages if possible.
*   **(Deferred Task) Major Prisma Upgrade:** Address Prisma v5.22.0 to v6.7.0 upgrade.

## 4. Active Decisions & Considerations

*   **Prisma Upgrade (v5.x to v6.x):** Decided to defer the major Prisma upgrade. This will be handled as a separate, dedicated task due to its potential complexity and need for thorough testing.
*   **Stripe Flow:** Using Stripe Checkout (hosted page) for upgrades and Stripe Billing Portal for management. This is simpler for initial implementation. Embedded elements can be considered later if needed.
*   **Legal Content:** Template content used for Privacy Policy and Terms of Service with actual contact information added. **Requires review by a legal professional.**
*   **Auth0 Setup:** Production credentials now in place for all connections, including social logins.
*   **Testing:** Core Stripe flows (upgrade, manage button) tested manually and now covered by E2E tests (`cypress/e2e/stripe.cy.ts`) including simulated webhook effects. Webhook processing confirmed working after fixes. Analytics unit tests updated for the new dual-database architecture. Branding feature tested manually.
*   **Landing Page:** Animations remain deferred.
*   **Error Handling:** Significantly improved through recent iterative process (Global Boundary, Server-Side `try...catch`, Client Feedback, API Standardization). Structured logging deferred.
*   **UI:** Footer added. Post-auth redirect fixed. Layout consistency improved. Public link page layout adjusted to better handle content height and footer visibility.
*   **UI Enhancement Plan:** Comprehensive approach with four phases: (1) Foundation & Design System with dark mode, (2) Core UI Components, (3) Landing Page Enhancement, and (4) Public Link Page & Polish. Will implement dark mode using Tailwind's 'class' strategy with localStorage persistence and system preference detection. Will create reusable components for cards, buttons, and form elements to ensure consistency.
*   **Branding Implementation:** Decided to use a collapsible section on the dashboard instead of a nested route for better UX. Requires `s3:PutObjectAcl` IAM permission for logo uploads to set `public-read` ACL. Public link page applies branding via top border and button colors.
