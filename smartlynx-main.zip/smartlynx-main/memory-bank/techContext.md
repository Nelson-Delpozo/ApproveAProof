# Technical Context: SmartLynx

## 1. Core Technologies

*   **Web Framework:** Remix (`remix.config.cjs`)
*   **Runtime:** Node.js (Version specified in `package.json` or `.nvmrc` if present - *check required*)
*   **Language:** TypeScript (`tsconfig.json`)
*   **Database ORM:** Prisma (v5.22.0 - Two clients: `@prisma/client`, `@prisma/analytics-client`. Note: Major upgrade to v6.7.0 pending, see `progress.md`.)
*   **Databases:**
    *   **Main:** PostgreSQL (hosted on Neon)
    *   **Analytics:** PostgreSQL (hosted on Neon)
 *   **Authentication:** Auth0 (using `auth0` Node SDK)
 *   **Styling:** Tailwind CSS (`tailwind.config.ts`, `app/tailwind.css`), utilizing the `@tailwindcss/typography` plugin for prose styling.
 *   **UI Library:** React (Implicit via Remix)
 *   **Payment Processing:** Stripe (using `stripe` Node SDK)
 *   **Date/Time Handling:** `date-fns` and `date-fns-tz` (for robust timezone-aware operations)

## 2. Development Environment

*   **Package Manager:** npm (`package.json`, `package-lock.json`, `.npmrc`)
*   **Code Formatting:** Prettier (`prettier.config.js`, `.prettierignore`)
 *   **Linting:** ESLint (`.eslintrc.cjs`)
 *   **Type Checking:** TypeScript Compiler (`tsc`)
 *   **Local Databases:** Docker Compose (`docker-compose.yml`) manages local PostgreSQL instances for development and testing.
 *   **Development Server:** `npm run dev` (Standard Remix command, inferred from `package.json` likely)

## 3. Testing

*   **Unit/Integration Testing:** Vitest (`vitest.config.ts`)
    *   Dev Dependencies: `vitest-mock-extended` (for Prisma mocking), `dotenv` (for test env vars), `@types/uuid`.
*   **End-to-End Testing:** Cypress (`cypress.config.ts`, `cypress/`)
*   **Test Setup:** `test/setup-test-env.ts` (Configured for Prisma mocking and loading test env vars).
*   **Test Environment:** Uses `.env.test` for test-specific environment variables.

## 4. Key Configuration Files

*   `package.json`: Project dependencies, scripts.
*   `remix.config.cjs`: Remix framework configuration.
*   `tsconfig.json`: TypeScript compiler options.
 *   `prisma/schema.prisma`: **Main** database schema definition.
 *   `prisma/analytics.schema.prisma`: **Analytics** database schema definition.
 *   `tailwind.config.ts`: Tailwind CSS configuration.
 *   `.env`, `.env.example`: Environment variables (DATABASE_URL, ANALYTICS_DATABASE_URL, SESSION_SECRET, AWS keys, SendGrid key, FROM_EMAIL, Auth0 credentials, Stripe keys/IDs).

## 5. Dependencies & Services

 *   **Databases:**
     *   **Local Development/Testing:** PostgreSQL instances (Main: `smartlynx_dev`, Analytics: `smartlynx_analytics_dev`) managed by Docker Compose (`docker-compose.yml`). Connection strings in local `.env` and `.env.test` point to `localhost:5432` and `localhost:5433` respectively. Use `npx prisma studio --schema=...` to view local data.
     *   **Preview/Production:** PostgreSQL instances hosted on Neon. Connection strings (`DATABASE_URL`, `ANALYTICS_DATABASE_URL`) configured via Vercel environment variables, pointing to appropriate Neon branches (`develop-*` for Preview, `main-*` for Production).
 *   **Authentication:** Auth0. Requires Domain, Client ID, Client Secret, Callback URL, etc., configured via environment variables (local `.env` for dev, Vercel for Preview/Production) and integration using an Auth0 SDK.
     *   **Environment URLs:** `AUTH0_CALLBACK_URL` and `AUTH0_LOGOUT_URL` require environment-specific values. Configure these in Vercel using Preview/Production scopes (recommend using `https://${VERCEL_URL}/callback` and `https://${VERCEL_URL}` for Preview). Corresponding URLs (e.g., preview domain patterns) must also be added to the "Allowed Callback URLs" and "Allowed Logout URLs" lists in the Auth0 Application settings.
     *   **Production Keys Implemented:** The Auth0 tenant now uses proper production keys for all connections (including social logins). These have been obtained by registering the application with each provider (e.g., Google, Facebook) and are fully configured for the production environment. (Updated 2025-04-18)
 *   **Email Service:** SendGrid. Requires SendGrid API Key and a verified `FROM_EMAIL` address configured via environment variables. Integration uses `@sendgrid/mail`.
 *   **File Storage:** AWS S3. Requires AWS credentials (Access Key ID, Secret Access Key, Bucket Name, Region) in `.env` and integration using AWS SDK (`@aws-sdk/client-s3`, `@aws-sdk/s3-request-presigner`).
     *   **Configuration Note:** Ensure the IAM policy for the provided credentials allows `s3:PutObject` on the correct `AWS_S3_BUCKET_NAME` resource ARN. For logo uploads (which use `/presign-logo-upload`), the policy **must also** include `s3:PutObjectAcl` permission to allow setting the `public-read` ACL via the presigned POST.
     *   **Configuration Note:** Ensure the S3 bucket's CORS policy allows `POST` requests from all required application origins (local and production, including `www` variants if applicable).
 *   **Payment Processing:** Stripe. Requires API Keys (Secret, Public), Pro Price ID, and Webhook Signing Secret in `.env`. Integration uses `stripe` Node SDK. Requires webhook endpoint configuration and Customer Portal configuration in Stripe dashboard.
 *   **Date/Time Library:** `date-fns` and `date-fns-tz`. Used for reliable date parsing, formatting, and timezone conversions, particularly for the link expiry feature.

 ## 6. Technical Constraints

*   Requires Node.js environment.
*   Browser compatibility targets defined by Remix/project needs.
*   Dependencies must be managed via npm.

## 7. Deployment (Potential)

*   **Platform:** Fly.io (`fly.toml`) seems likely.
*   **Build Process:** `npm run build` (Standard Remix command).
*   **Server Start:** `start.sh` script likely used in deployment environment.
*   **Dockerfile:** Provided for containerized deployment (`Dockerfile`, `.dockerignore`).
*   **Gitpod:** Configuration exists for cloud development environment (`.gitpod.yml`, `.gitpod.Dockerfile`).
