import type { PrismaClient as AnalyticsPrismaClient } from "@prisma/analytics-client";
import type { PrismaClient } from "@prisma/client";
import { installGlobals } from "@remix-run/node";
import * as dotenv from "dotenv"; // Moved dotenv import down
import "@testing-library/jest-dom/vitest";
import { vi } from "vitest";
import { mockDeep, mockReset } from "vitest-mock-extended";

import { prisma } from "~/db.server"; // Import the actual prisma instance
import { prismaAnalytics } from "~/analytics.db.server"; // Import the actual prismaAnalytics instance

// Load environment variables from .env.test FIRST
dotenv.config({ path: ".env.test" });

// Mock the prisma client module
vi.mock("~/db.server", () => ({
  // Use mockDeep to create a deep mock of the PrismaClient type
  prisma: mockDeep<PrismaClient>(),
}));

// Mock the prismaAnalytics client module
vi.mock("~/analytics.db.server", () => ({
  // Use mockDeep to create a deep mock of the AnalyticsPrismaClient type
  prismaAnalytics: mockDeep<AnalyticsPrismaClient>(),
}));

// Reset mocks before each test
beforeEach(() => {
  mockReset(prisma);
  mockReset(prismaAnalytics);
});

installGlobals();
