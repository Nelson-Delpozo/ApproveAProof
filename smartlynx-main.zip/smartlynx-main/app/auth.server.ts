import { AuthenticationClient } from "auth0"; // Re-add Auth0 client import
import invariant from "tiny-invariant"; // Re-add invariant import

import type { User } from "~/models/user.server"; // Add User type import
// findOrCreateUserByAuthProfile is still relevant for the callback
import { findOrCreateUserByAuthProfile } from "~/models/user.server";
import { sessionStorage } from "~/session.server"; // Keep for storing session data after login

// SESSION_SECRET is needed for Remix sessions which might be initialized early
invariant(process.env.SESSION_SECRET, "SESSION_SECRET must be set");


// Function to get the Auth0 Authentication Client, checking env vars on demand
export function getAuth0AuthenticationClient() {
  // Ensure environment variables are set when the client is needed
  invariant(process.env.AUTH0_DOMAIN, "AUTH0_DOMAIN must be set");
  invariant(process.env.AUTH0_CLIENT_ID, "AUTH0_CLIENT_ID must be set");
  invariant(process.env.AUTH0_CLIENT_SECRET, "AUTH0_CLIENT_SECRET must be set");
  // CALLBACK_URL is primarily used in routes generating the auth URL,
  // but check it here for consistency if the client itself needs it later.
  invariant(process.env.AUTH0_CALLBACK_URL, "AUTH0_CALLBACK_URL must be set");

  // Initialize the Auth0 Authentication Client
  // Used for login, token exchange, userinfo endpoint etc.
  return new AuthenticationClient({
    domain: process.env.AUTH0_DOMAIN,
    clientId: process.env.AUTH0_CLIENT_ID,
    clientSecret: process.env.AUTH0_CLIENT_SECRET,
  });
}


// Initialize the Auth0 Management Client (Optional but often useful)


// --- Session Management Functions ---

// Example structure for storing user info in the session (adapt as needed)
const AUTH0_SESSION_KEY = "auth0User";

// Sets user data in the session
export async function setAuthSession(request: Request, user: User) {
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));
  // Store relevant user info
  session.set(AUTH0_SESSION_KEY, {
    userId: user.id, // Use user.id here
    email: user.email,
    auth0Sub: user.auth0Sub,
    // Storing id_token or access_token in session cookie has security implications.
    // Consider alternatives like server-side storage if sensitive operations are needed.
  });
  return session;
}

// Retrieves user data from the session
export async function getAuthSession(request: Request): Promise<Pick<User, 'id' | 'email' | 'auth0Sub'> | null> {
   const session = await sessionStorage.getSession(request.headers.get("Cookie"));
   const authData = session.get(AUTH0_SESSION_KEY);
   // Correctly check for 'userId' based on how it's set in setAuthSession
   if (!authData || typeof authData.userId !== 'string') { // Check userId existence and type
     return null;
   }
   // Return only the relevant fields stored in the session
   return {
     id: authData.userId, // Map userId back to id
     email: authData.email,
     auth0Sub: authData.auth0Sub,
   };
}

// Destroys the user session
export async function destroyAuthSession(request: Request) {
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));
  return sessionStorage.destroySession(session);
  // Note: This only destroys the Remix session. Actual Auth0 logout needs separate handling.
}

// Re-export findOrCreateUserByAuthProfile for use in callback route
export { findOrCreateUserByAuthProfile };
