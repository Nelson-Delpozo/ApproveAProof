import type { PrismaClient, User } from "@prisma/client"; // Moved type import up
import type { Session } from "@remix-run/node"; // Import Session type
import { describe, it, expect, beforeEach, vi } from "vitest"; // Added vi
import { mockDeep, mock } from "vitest-mock-extended"; // Added mock

// Import functions to test
import {
  findOrCreateUserByAuthProfile,
  setAuthSession,
  getAuthSession,
  destroyAuthSession,
} from "~/auth.server";
import { prisma } from "~/db.server"; // This will be the mocked instance
import { sessionStorage } from "~/session.server"; // Import sessionStorage to mock

// Mock the sessionStorage
vi.mock("~/session.server", () => ({
  sessionStorage: mockDeep<typeof sessionStorage>(),
}));

// Mock the Prisma client instance specifically for this test file
// (Alternatively, rely solely on the global mock in setup-test-env.ts)
const prismaMock = prisma as unknown as ReturnType<typeof mockDeep<PrismaClient>>;

// Sample data for testing
const testEmail = "test@example.com";
const testAuth0Sub = "auth0|123456";
const existingUser: User = {
  id: "user-1",
  email: testEmail,
  auth0Sub: testAuth0Sub,
  createdAt: new Date(),
  updatedAt: new Date(),
};
const existingUserDifferentEmail: User = {
  id: "user-2",
  email: "different@example.com",
  auth0Sub: testAuth0Sub, // Same auth0Sub
  createdAt: new Date(),
  updatedAt: new Date(),
};
const existingUserNoAuthSub: User = {
    id: "user-3",
    email: testEmail, // Same email
    auth0Sub: null,
    createdAt: new Date(),
    updatedAt: new Date(),
};


describe("findOrCreateUserByAuthProfile", () => {
  beforeEach(() => {
    // Reset mocks defined in setup-test-env.ts if relying on global mock
    // If using local mock (prismaMock), reset it here: mockReset(prismaMock);
  });

  it("should return existing user if found by auth0Sub", async () => {
    prismaMock.user.findUnique.mockResolvedValueOnce(existingUser);

    const user = await findOrCreateUserByAuthProfile(testEmail, testAuth0Sub);

    expect(user).toEqual(existingUser);
    expect(prismaMock.user.findUnique).toHaveBeenCalledWith({
      where: { auth0Sub: testAuth0Sub },
    });
    expect(prismaMock.user.update).not.toHaveBeenCalled();
    expect(prismaMock.user.create).not.toHaveBeenCalled();
  });

  it("should update email if user found by auth0Sub has different email", async () => {
    // Simulate finding user by auth0Sub but with an old email
    prismaMock.user.findUnique.mockResolvedValueOnce(existingUserDifferentEmail);
    // Mock the update call
    const updatedUser = { ...existingUserDifferentEmail, email: testEmail };
    prismaMock.user.update.mockResolvedValueOnce(updatedUser);

    const user = await findOrCreateUserByAuthProfile(testEmail, testAuth0Sub);

    expect(user).toEqual(updatedUser);
    expect(prismaMock.user.findUnique).toHaveBeenCalledWith({
      where: { auth0Sub: testAuth0Sub },
    });
    expect(prismaMock.user.update).toHaveBeenCalledWith({
        where: { id: existingUserDifferentEmail.id },
        data: { email: testEmail },
    });
    expect(prismaMock.user.create).not.toHaveBeenCalled();
  });


  it("should return and update existing user if found by email but not auth0Sub", async () => {
    // Simulate not finding by auth0Sub, then finding by email
    prismaMock.user.findUnique
      .mockResolvedValueOnce(null) // First call (by auth0Sub)
      .mockResolvedValueOnce(existingUserNoAuthSub); // Second call (by email)

    // Mock the update call to add auth0Sub
    const updatedUser = { ...existingUserNoAuthSub, auth0Sub: testAuth0Sub };
    prismaMock.user.update.mockResolvedValueOnce(updatedUser);

    const user = await findOrCreateUserByAuthProfile(testEmail, testAuth0Sub);

    expect(user).toEqual(updatedUser);
    expect(prismaMock.user.findUnique).toHaveBeenCalledTimes(2);
    expect(prismaMock.user.findUnique).toHaveBeenNthCalledWith(1, { where: { auth0Sub: testAuth0Sub } });
    expect(prismaMock.user.findUnique).toHaveBeenNthCalledWith(2, { where: { email: testEmail } });
    expect(prismaMock.user.update).toHaveBeenCalledWith({
      where: { id: existingUserNoAuthSub.id },
      data: { auth0Sub: testAuth0Sub },
    });
    expect(prismaMock.user.create).not.toHaveBeenCalled();
  });

  it("should create a new user if not found by auth0Sub or email", async () => {
    // Simulate not finding by auth0Sub or email
    prismaMock.user.findUnique.mockResolvedValue(null);

    // Mock the create call
    const newUser = { ...existingUser, id: "new-user-id" }; // Simulate DB generating ID
    prismaMock.user.create.mockResolvedValueOnce(newUser);

    const user = await findOrCreateUserByAuthProfile(testEmail, testAuth0Sub);

    expect(user).toEqual(newUser);
    expect(prismaMock.user.findUnique).toHaveBeenCalledTimes(2);
     expect(prismaMock.user.findUnique).toHaveBeenNthCalledWith(1, { where: { auth0Sub: testAuth0Sub } });
    expect(prismaMock.user.findUnique).toHaveBeenNthCalledWith(2, { where: { email: testEmail } });
    expect(prismaMock.user.update).not.toHaveBeenCalled();
    expect(prismaMock.user.create).toHaveBeenCalledWith({
      data: {
        email: testEmail,
        auth0Sub: testAuth0Sub,
      },
    });
  });
});

// --- Session Function Tests ---

const AUTH0_SESSION_KEY = "auth0User"; // Match the key used in auth.server.ts

const testUser: User = {
  id: "user-test-session",
  email: "session@example.com",
  auth0Sub: "auth0|session123",
  createdAt: new Date(),
  updatedAt: new Date(),
};

// Create a mock Request object
const createMockRequest = (cookieHeader?: string): Request => {
  const headers = new Headers();
  if (cookieHeader) {
    headers.set("Cookie", cookieHeader);
  }
  // Using a placeholder URL, the important part is the headers
  return new Request("http://localhost/", { headers });
};

describe("Session Management Functions", () => {
  let mockSession: Session;

  beforeEach(() => {
    // Reset mocks before each test
    vi.resetAllMocks();

    // Create a fresh mock session for each test
    mockSession = mock<Session>();

    // Mock sessionStorage.getSession to return our mockSession
    (sessionStorage.getSession as ReturnType<typeof vi.fn>).mockResolvedValue(mockSession);
    // Mock sessionStorage.destroySession
    (sessionStorage.destroySession as ReturnType<typeof vi.fn>).mockResolvedValue("mock-destroyed-cookie");
  });

  describe("setAuthSession", () => {
    it("should get session, set user data, and return the session", async () => {
      const request = createMockRequest("test-cookie=123");
      const resultSession = await setAuthSession(request, testUser);

      expect(sessionStorage.getSession).toHaveBeenCalledWith("test-cookie=123");
      expect(mockSession.set).toHaveBeenCalledWith(AUTH0_SESSION_KEY, {
        userId: testUser.id,
        email: testUser.email,
        auth0Sub: testUser.auth0Sub,
      });
      expect(resultSession).toBe(mockSession); // Should return the session object itself
    });
  });

  describe("getAuthSession", () => {
    it("should return user data if session key exists", async () => {
      const request = createMockRequest("test-cookie=abc");
      // Define the expected data structure returned by getAuthSession
      const expectedReturnedData = {
        id: testUser.id, // Use 'id' here to match the function's return type
        email: testUser.email,
        auth0Sub: testUser.auth0Sub,
      };
      // Mock session.get to return the data as it's stored *in* the session
      const dataStoredInSession = {
        userId: testUser.id, // This is how it's stored by setAuthSession
        email: testUser.email,
        auth0Sub: testUser.auth0Sub,
      };
      (mockSession.get as ReturnType<typeof vi.fn>).mockReturnValue(dataStoredInSession);

      const user = await getAuthSession(request);

      expect(sessionStorage.getSession).toHaveBeenCalledWith("test-cookie=abc");
      expect(mockSession.get).toHaveBeenCalledWith(AUTH0_SESSION_KEY);
      expect(user).toEqual(expectedReturnedData); // Assert against the expected *returned* structure
    });

    it("should return null if session key does not exist", async () => {
      // Setup: Create request and mock session.get to return undefined
      const request = createMockRequest("test-cookie=def");
      (mockSession.get as ReturnType<typeof vi.fn>).mockReturnValue(undefined);

      // Act: Call the function under test
      const user = await getAuthSession(request);

      // Assert: Check mocks and result
      expect(sessionStorage.getSession).toHaveBeenCalledWith("test-cookie=def");
      expect(mockSession.get).toHaveBeenCalledWith(AUTH0_SESSION_KEY);
      expect(user).toBeNull();
    });

     it("should return null if session data is invalid (missing userId)", async () => {
      const request = createMockRequest("test-cookie=ghi");
      const invalidData = { email: testUser.email }; // Missing userId
      (mockSession.get as ReturnType<typeof vi.fn>).mockReturnValue(invalidData);

      const user = await getAuthSession(request);

      expect(sessionStorage.getSession).toHaveBeenCalledWith("test-cookie=ghi");
      expect(mockSession.get).toHaveBeenCalledWith(AUTH0_SESSION_KEY);
      expect(user).toBeNull();
    });
  });

  describe("destroyAuthSession", () => {
    it("should get session and call destroySession", async () => {
      const request = createMockRequest("test-cookie=xyz");
      const destroyResult = await destroyAuthSession(request);

      expect(sessionStorage.getSession).toHaveBeenCalledWith("test-cookie=xyz");
      expect(sessionStorage.destroySession).toHaveBeenCalledWith(mockSession);
      expect(destroyResult).toBe("mock-destroyed-cookie"); // Should return the result of destroySession
    });
  });
});
