import { useMatches } from "@remix-run/react";
import { format } from 'date-fns'; // Removed unused 'parse' import
import { fromZonedTime } from 'date-fns-tz'; // Correct import: fromZonedTime
import { useMemo } from "react";


import type { User } from "~/models/user.server";

const DEFAULT_REDIRECT = "/";

/**
 * This should be used any time the redirect path is user-provided
 * (Like the query string on our login/signup pages). This avoids
 * open-redirect vulnerabilities.
 * @param {string} to The redirect destination
 * @param {string} defaultRedirect The redirect to use if the to is unsafe.
 */
export function safeRedirect(
  to: FormDataEntryValue | string | null | undefined,
  defaultRedirect: string = DEFAULT_REDIRECT,
) {
  if (!to || typeof to !== "string") {
    return defaultRedirect;
  }

  if (!to.startsWith("/") || to.startsWith("//")) {
    return defaultRedirect;
  }

  return to;
}

/**
 * This base hook is used in other hooks to quickly search for specific data
 * across all loader data using useMatches.
 * @param {string} id The route id
 * @returns {JSON|undefined} The router data or undefined if not found
 */
export function useMatchesData(
  id: string,
): Record<string, unknown> | undefined {
  const matchingRoutes = useMatches();
  const route = useMemo(
    () => matchingRoutes.find((route) => route.id === id),
    [matchingRoutes, id],
  );
  return route?.data as Record<string, unknown>;
}

function isUser(user: unknown): user is User {
  return (
    user != null &&
    typeof user === "object" &&
    "email" in user &&
    typeof user.email === "string"
  );
}

export function useOptionalUser(): User | undefined {
  const data = useMatchesData("root");
  if (!data || !isUser(data.user)) {
    return undefined;
  }
  return data.user;
}

export function useUser(): User {
  const maybeUser = useOptionalUser();
  if (!maybeUser) {
    throw new Error(
      "No user found in root loader, but user is required by useUser. If user is optional, try useOptionalUser instead.",
    );
  }
  return maybeUser;
}

export function validateEmail(email: unknown): email is string {
  return typeof email === "string" && email.length > 3 && email.includes("@");
}

/**
 * Formats a Date object into the `YYYY-MM-DDTHH:mm` format required
 * by datetime-local input fields, ensuring correct timezone handling.
 * 
 * @param date The Date object to format (could be in any timezone format)
 * @returns The formatted date string in local timezone (YYYY-MM-DDTHH:mm) for the input field
 */
export function formatDateTimeLocal(date: Date): string {
  // Ensure we're working with a valid date
  if (!(date instanceof Date) || isNaN(date.getTime())) {
    return "";
  }

  // Use date-fns format. 'yyyy-MM-dd\'T\'HH:mm' is the required format
  // for datetime-local inputs. This function inherently uses the local timezone
  // of the environment it runs in (client's browser).
  try {
    return format(date, "yyyy-MM-dd'T'HH:mm");
  } catch { // Remove unused 'error' variable
    return ""; // Return empty string on error
  }
}

/**
 * Parses a local datetime string (YYYY-MM-DDTHH:mm) from a datetime-local input,
 * considering the provided client timezone, and returns a Date object representing
 * the equivalent UTC time.
 * 
 * @param dateTimeString The datetime string from the input (representing local time in clientTimezone).
 * @param clientTimezone The IANA timezone name of the client (e.g., "America/New_York").
 * @returns A Date object representing the correct point in time (internally UTC).
 */
export function parseLocalDateTime(dateTimeString: string, clientTimezone: string): Date {
  if (!dateTimeString || !clientTimezone) {
    return new Date(NaN); 
  }

  try {
    // Use fromZonedTime to directly convert the local time string from the specified timezone to a UTC Date object
    const utcDate = fromZonedTime(dateTimeString, clientTimezone);

    // Basic validation after creation
    if (isNaN(utcDate.getTime())) {
      throw new Error(`fromZonedTime failed for: ${dateTimeString} in timezone ${clientTimezone}`);
    }
    
    // Return the Date object representing the correct point in time (UTC).
    return utcDate; 
  } catch { // Remove unused 'error' variable
    return new Date(NaN); // Return invalid date on error
  }
}
