import { Readable } from "stream";

import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3"; // Added GetObjectCommand
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import invariant from "tiny-invariant";

// Helper function to initialize S3 client and check env vars
function getS3Client() {
  // Ensure required environment variables are set *when the client is needed*
  invariant(process.env.AWS_ACCESS_KEY_ID, "AWS_ACCESS_KEY_ID must be set");
  invariant(process.env.AWS_SECRET_ACCESS_KEY, "AWS_SECRET_ACCESS_KEY must be set");
  invariant(process.env.AWS_REGION, "AWS_REGION must be set");

  return new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
  });
}

// Removed top-level BUCKET_NAME check. It will be checked within functions.


interface UploadFileOptions {
  key: string; // The desired key (path/filename) in the S3 bucket
  body: Buffer | Uint8Array | Blob | string | Readable; // File content
  contentType: string; // MIME type of the file (e.g., 'image/jpeg')
}

/**
 * Uploads a file to the configured S3 bucket.
 * @param options - Upload options including key, body, and contentType.
 * @returns The S3 object key if successful.
 * @throws Error if upload fails.
 */
export async function uploadFileToS3({ key, body, contentType }: UploadFileOptions): Promise<string> {
  const s3Client = getS3Client(); // Get client instance here
  // Check for bucket name inside the function
  invariant(process.env.AWS_S3_BUCKET_NAME, "AWS_S3_BUCKET_NAME must be set for upload");
  const bucketName = process.env.AWS_S3_BUCKET_NAME;

  const command = new PutObjectCommand({
    Bucket: bucketName, // Use variable checked inside function
    Key: key,
    Body: body,
    ContentType: contentType,
    // ACL: 'public-read', // Optional: Set if you want objects to be publicly readable by default (consider security implications)
    // Consider adding Cache-Control headers if appropriate
  });

  try {
    await s3Client.send(command);
    console.log(`Successfully uploaded ${key} to ${bucketName}`);
    return key; // Return the key on success
  } catch (error) {
    console.error(`Failed to upload ${key} to ${bucketName}:`, error);
    // Rethrow or handle the error appropriately
    throw new Error(`S3 upload failed for key ${key}.`);
  }
}

/**
 * Generates a pre-signed URL for downloading an object from S3.
 * @param key - The S3 object key.
 * @param expiresIn - URL validity duration in seconds (default: 900 = 15 minutes).
 * @returns The pre-signed URL string.
 * @throws Error if URL generation fails.
 */
export async function getSignedDownloadUrl(key: string, expiresIn = 900): Promise<string> {
  const s3Client = getS3Client(); // Get client instance here
  // Check for bucket name inside the function
  invariant(process.env.AWS_S3_BUCKET_NAME, "AWS_S3_BUCKET_NAME must be set for signed URL");
  const bucketName = process.env.AWS_S3_BUCKET_NAME;

  const command = new GetObjectCommand({
    Bucket: bucketName, // Use variable checked inside function
    Key: key,
    // You can add ResponseContentDisposition: 'attachment; filename="your_desired_filename.ext"'
    // if you want to suggest a filename to the browser when the link is clicked.
    // You might need the original filename for this.
  });

  try {
    const url = await getSignedUrl(s3Client, command, { expiresIn });
    console.log(`Successfully generated signed URL for ${key}`);
    return url;
  } catch (error) {
    console.error(`Failed to generate signed URL for ${key}:`, error);
    throw new Error(`S3 signed URL generation failed for key ${key}.`);
  }
}

// Optional: Add functions for deleting files, etc. later
