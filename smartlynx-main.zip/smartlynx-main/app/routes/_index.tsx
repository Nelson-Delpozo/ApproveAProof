import type { MetaFunction } from "@remix-run/node";
import { Link } from "@remix-run/react";
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { motion } from "framer-motion";

import { useOptionalUser } from "~/utils"; // Hook to check if user is logged in

export const meta: MetaFunction = () => [
  { title: "SmartLynx - Secure Link Sharing" },
];

export default function Index() {
  const user = useOptionalUser(); // Get user data if logged in

  const listVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  return (
    // Remove the outermost div, let content render directly in root's main element
    <>
      {/* Container for max-width */}
      <div className="relative mx-auto max-w-7xl">
        {/* Inner container */}
        <div>
          <div className="relative shadow-xl sm:overflow-hidden sm:rounded-2xl bg-card-background-light dark:bg-neutral-800">
            {/* Enhanced Gradient Background */}
            {/* Using a slightly darker gradient for dark mode, or could be a solid color */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary-200 via-purple-100 to-cyan-200 dark:from-primary-700 dark:via-purple-900 dark:to-cyan-800" />
            {/* End Background */}

            {/* Adjust padding for different screen sizes - simplify now that outer padding exists */}
            <div className="relative px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
              <h1
                className="text-center text-5xl font-extrabold tracking-tight sm:text-6xl md:text-8xl lg:text-9xl" // Smaller on mobile
              >
                <motion.span

                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1, duration: 0.6 }}
                  // Remove redundant classes, outer h1 handles styling
                >
                  <span className="block uppercase text-primary-600 dark:text-primary-400 drop-shadow-md">
                    SmartLynx
                  </span>
                </motion.span>
              </h1>

              <p
                className="mx-auto mt-4 max-w-lg text-center text-base text-neutral-700 dark:text-neutral-300 sm:max-w-3xl md:mt-6 md:text-xl" // Smaller on mobile
              >
                Share documents with confidence. SmartLynx lets you control
                every link—set expirations, revoke access anytime, and track
                every view and download.
              </p>

              
              {/* End Marketing Bullets */}
              <div
                className="mx-auto mt-6 max-w-3xl px-4 md:mt-8"
              >
                <motion.ul
                  className="list-disc space-y-2 text-left text-base text-neutral-600 dark:text-neutral-400 marker:text-primary-500 dark:marker:text-primary-400 md:text-lg"
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  variants={listVariants}
                >
                  <motion.li variants={itemVariants}>
                    <span className="font-semibold text-neutral-800 dark:text-neutral-100">
                      Full Control, Always:
                    </span>{" "}
                    Set auto-expiring links or revoke access anytime—you're in charge.
                  </motion.li>

                  <motion.li variants={itemVariants}>
                    <span className="font-semibold text-neutral-800 dark:text-neutral-100">
                      Know Who Engages:
                    </span>{" "}
                    Track views, downloads, and shares with real-time analytics.
                  </motion.li>

                  <motion.li variants={itemVariants}>
                    <span className="font-semibold text-neutral-800 dark:text-neutral-100">
                      Look Polished:
                    </span>{" "}
                    Customize download pages with your brand's logo and
                    colors (PRO feature).
                  </motion.li>

                  <motion.li variants={itemVariants}>
                    <span className="font-semibold text-neutral-800 dark:text-neutral-100">
                      Secure by Design:
                    </span>{" "}
                    Trust that your files are protected with AWS, with private
                    links sent directly to your clients via email.
                  </motion.li>

                  <motion.li variants={itemVariants}>
                    <span className="font-semibold text-neutral-800 dark:text-neutral-100">
                      Start Free:
                    </span>{" "}
                    Go
                    <span className="text-md ml-2 inline-block rounded bg-primary-200 dark:bg-primary-700 px-2 py-0.5 font-semibold text-primary-700 dark:text-primary-200">
                      PRO
                    </span>{" "}
                    at anytime for unlimited links, branded download pages, and
                    deeper insights.
                  </motion.li>
                </motion.ul>
              </div>

              {/* Adjust margin and ensure centering on all screens */}
              <div
                className="mx-auto mt-8 flex max-w-sm justify-center sm:max-w-none md:mt-10" // Changed sm:flex sm:justify-center to flex justify-center
              >
                {user ? (
                  // User is logged in - link to dashboard
                  <Link
                    to="/dashboard" // Link to the future dashboard
                    className="flex items-center justify-center rounded-md border border-transparent bg-primary-600 px-8 py-3 text-base font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 sm:px-10"
                  >
                    Go to Dashboard ({user.email})
                  </Link>
                ) : (
                  // User is logged out - show Sign Up button (Log In removed)
                  // Remove grid classes, rely on parent's justify-center
                  <div className="">
                    {" "}
                    {/* Removed space-y-4 sm:mx-auto sm:inline-grid sm:grid-cols-2 sm:gap-5 sm:space-y-0 */}
                    {/* Adjust padding and text size */}
                    <Link
                      to="/signup" // Correct signup route
                      className="flex items-center justify-center rounded-md border border-transparent bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm transition-colors duration-150 hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 sm:px-8 sm:py-3 sm:text-base" // Smaller padding/text on mobile
                    >
                      Get Started Free
                    </Link>
                    {/* Adjust padding and text size */}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer text - move outside the main content block */}
        <div className="mt-8 text-center">
          <p className="text-sm text-neutral-500 dark:text-neutral-400">
            Built for Creative Professionals
          </p>
        </div>
        {/* End Optional Logos Section */}
      </div>
    </> // Close the fragment
  );
}
