import { S3Client } from "@aws-sdk/client-s3"; // AWS SDK imports first
import { createPresignedPost } from "@aws-sdk/s3-presigned-post";
import { ActionFunctionArgs, json } from "@remix-run/node"; // Remix imports next
import invariant from "tiny-invariant"; // Other packages
import { v4 as uuidv4 } from "uuid";
// Remove dotenv import

// Remove dotenv.config() call

import { getAuthSession } from "~/auth.server"; // Local app imports last

// Define constants (can stay at module level if only used inside action)
const MAX_FILE_SIZE_MB = 250; // Example: Set max file size (e.g., 100MB)
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;


export const action = async ({ request }: ActionFunctionArgs) => {
  // --- Move Env Var Access, Checks, and Client Instantiation INSIDE action ---
  const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME;
  const REGION = process.env.AWS_REGION;
  const ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
  const SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;

  // Ensure required environment variables are set inside the action
  invariant(ACCESS_KEY_ID, "AWS_ACCESS_KEY_ID must be set");
  invariant(SECRET_ACCESS_KEY, "AWS_SECRET_ACCESS_KEY must be set");
  invariant(BUCKET_NAME, "AWS_S3_BUCKET_NAME must be set");
  invariant(REGION, "AWS_REGION must be set");

  // Instantiate S3 Client inside the action
  const s3Client = new S3Client({
    region: REGION,
    credentials: {
      accessKeyId: ACCESS_KEY_ID,
      secretAccessKey: SECRET_ACCESS_KEY,
    },
  });
  // --- End Moved Code ---

  const authSession = await getAuthSession(request); // Get user session data
  if (!authSession?.id) { // Check for 'id' instead of 'userId'
    // User is not authenticated
    return json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = authSession.id; // Use 'id' from the auth session object

  const formData = await request.formData();
  const filename = formData.get("filename");
  const contentType = formData.get("contentType");

  if (typeof filename !== "string" || filename.length === 0) {
    return json({ error: "Filename is required." }, { status: 400 });
  }
  if (typeof contentType !== "string" || contentType.length === 0) {
    return json({ error: "Content type is required." }, { status: 400 });
  }

  // Generate a unique key for S3 to prevent overwrites
  // Example: user-uploads/{userId}/{uuid}-{originalFilename}
  const uniqueKey = `user-uploads/${userId}/${uuidv4()}-${filename}`;

  try {
    // Use the locally instantiated s3Client
    const { url, fields } = await createPresignedPost(s3Client, {
      Bucket: BUCKET_NAME,
      Key: uniqueKey,
      Conditions: [
        ["content-length-range", 0, MAX_FILE_SIZE_BYTES], // Max file size condition
        ["starts-with", "$Content-Type", contentType], // Ensure content type matches
      ],
      Fields: {
        "Content-Type": contentType,
        // Add any other fields you want S3 to receive, like ACL if needed
        // acl: "private", // Example: if you want files to be private by default
      },
      Expires: 600, // Presigned URL expires in 600 seconds (10 minutes)
    });

    console.log(`Generated presigned POST for key: ${uniqueKey}, user: ${userId}`);
    // Return the URL and fields needed for the client-side form POST
    return json({ url, fields, key: uniqueKey });

  } catch (error) {
    console.error("Error creating presigned POST URL:", error);
    return json({ error: "Failed to prepare upload." }, { status: 500 });
  }
};

// You might want a loader function here if you plan to render a UI for this route,
// but for an API-only action route, it's not strictly necessary.
// export const loader = () => { return null; }
