import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node"; // Add ActionFunctionArgs
import { json, redirect } from "@remix-run/node"; // Use json for responses, add redirect
import { useLoaderData, Link, Form } from "@remix-run/react"; // Add Form
import invariant from "tiny-invariant";

import { LocalTime } from "~/components/LocalTime"; // Import LocalTime
import { prisma } from "~/db.server";
import {
  recordLinkViewEvent,
  recordLinkDownloadEvent, // Import the new function
} from "~/models/analytics.server";
import { getSignedDownloadUrl } from "~/s3.server";

// Helper function to check if a date is in the past
// This function ensures consistent timezone handling
function isExpired(date: Date | null): boolean {
  if (!date) return false;
  
  // Create a new Date object for the current time in UTC
  const now = new Date();
  
  // Compare the timestamps
  return date.getTime() < now.getTime();
}

export async function loader({ params }: LoaderFunctionArgs) {
  invariant(params.accessKey, "Missing accessKey param");
  const { accessKey } = params;

  let link;
  try {
    link = await prisma.sharedLink.findUnique({
      where: { accessKey },
      // Select fields needed for display and potential download URL generation later
    select: {
      id: true, // Needed for creating AnalyticsEvent
      userId: true, // Needed for creating AnalyticsEvent
      originalFileName: true,
      description: true,
      storageKey: true,
      revoked: true,
      expiresAt: true,
      // Include the user relation to fetch branding
      user: { // Correct relation name is 'user'
        select: {
          plan: true, // Check if user is Pro
          brandingLogoUrl: true,
          brandingColorPrimary: true,
          brandingColorText: true,
        }
        }
      }
    });
  } catch (error) {
    console.error(`Database error fetching link ${accessKey} in loader:`, error);
    throw new Response("Error accessing link data.", { status: 500 });
  }

  // Handle link not found
  if (!link) {
    throw new Response("Link not found", { status: 404 });
  }

  // Handle revoked link
  if (link.revoked) {
    return json({
      status: "revoked",
      originalFileName: link.originalFileName,
    } as const); // Use 'as const' for stricter type checking in component
  }

  // Handle expired link
  if (isExpired(link.expiresAt)) {
    return json({
      status: "expired",
      originalFileName: link.originalFileName,
      expiresAt: link.expiresAt?.toISOString(), // Pass expiry date as string
    } as const);
  }

  // --- Record Analytics Event ---
  // Call the dedicated function. It handles its own errors and runs async.
  // We don't await it because analytics recording shouldn't block page load.
  recordLinkViewEvent(link.id); // Pass only linkId
  // --- End Record Analytics Event ---

  // If link is valid, return necessary data for the page
  // No need to generate download URL here anymore, action will do it
  return json({
    status: "valid",
    originalFileName: link.originalFileName,
    description: link.description,
    // Include user branding info only if they are Pro
    ownerBranding: link.user?.plan === 'PRO' ? { // Use link.user here
      logoUrl: link.user.brandingLogoUrl,
      colorPrimary: link.user.brandingColorPrimary,
      colorText: link.user.brandingColorText,
    } : null,
   } as const);
 }

 export async function action({ params }: ActionFunctionArgs) {
   invariant(params.accessKey, "Missing accessKey param");
   const { accessKey } = params;

  // Find the link to verify it exists and get its ID, userId and storage key
  let link;
  try {
    link = await prisma.sharedLink.findUnique({
      where: { accessKey },
      select: { id: true, userId: true, storageKey: true, revoked: true, expiresAt: true }, // Select needed fields including userId
    });
  } catch (error) {
    console.error(`Database error fetching link ${accessKey} in action:`, error);
    throw new Response("Error accessing link data.", { status: 500 });
  }

  if (!link) {
    throw new Response("Link not found", { status: 404 });
  }

  // Prevent tracking/download if link is invalid
  if (link.revoked || isExpired(link.expiresAt)) {
     // 410 Gone might be more appropriate than 403 Forbidden here
     throw new Response("Link is invalid", { status: 410 });
  }

  // --- Track Download Event ---
   // Fire-and-forget using the dedicated function.
   recordLinkDownloadEvent(link.id);
  // --- End Track Download Event ---

  // Generate a fresh signed URL for the actual download
  try {
    // Use a shorter expiry for the direct download link for added security
    const downloadUrl = await getSignedDownloadUrl(link.storageKey, 60); // e.g., 60 seconds expiry
    // Redirect the user to the S3 URL to start the download
    return redirect(downloadUrl);
  } catch (error) {
    console.error("Failed to get signed URL for download tracking:", accessKey, error);
    // Throw a generic server error if URL generation fails
    throw new Response("Could not initiate download", { status: 500 });
  }
}


export default function PublicLinkPage() {
  const data = useLoaderData<typeof loader>();

  // Determine branding styles, using defaults if not set or user is not Pro
  const primaryColor = data.status === 'valid' && data.ownerBranding?.colorPrimary ? data.ownerBranding.colorPrimary : '#4F46E5'; // Default: indigo-600
  const textColor = data.status === 'valid' && data.ownerBranding?.colorText ? data.ownerBranding.colorText : '#FFFFFF'; // Default: white

  return (
    // Make this div a flex container that grows and centers its content vertically and horizontally
    // Parent div already has theme-aware background from root.tsx
    <div className="flex flex-col flex-grow items-center justify-center px-4 py-8">
      {/* Add inline style for top border */}
      {/* Remove mx-auto as parent flex container handles centering */}
      <div
        className="w-full max-w-md rounded-lg bg-card-background-light dark:bg-card-background-dark p-8 shadow-md text-center" // Apply themed card background
        style={{ borderTop: data.status === 'valid' && data.ownerBranding?.colorPrimary ? `4px solid ${primaryColor}` : 'none' }}
      >

        {/* Conditionally display logo */}
        {data.status === 'valid' && data.ownerBranding?.logoUrl ? <div className="mb-6 flex justify-center">
            <img
              src={data.ownerBranding.logoUrl}
              alt="Logo"
              className="max-h-16 object-contain" // Limit logo height
            />
          </div> : null}

        {/* Apply flex and min-w-0 to h1 to allow span to truncate correctly */}
        <h1 className="text-2xl font-bold mb-4 flex items-baseline space-x-2 min-w-0 text-neutral-800 dark:text-neutral-100">
          {/* Adjust heading based on status */}
          {data.status === "valid" ? <>
            <span>Download:</span>
            <span className="truncate inline-block">{data.originalFileName}</span>
          </> : null}
          {data.status === "revoked" ? <>
            <span>Link Revoked:</span>
            <span className="truncate inline-block">{data.originalFileName}</span>
          </> : null}
          {data.status === "expired" ? <>
            <span>Link Expired:</span>
            <span className="truncate inline-block">{data.originalFileName}</span>
          </> : null}
        </h1>


        {data.status === "valid" ? <>
            {data.description ? <p className="text-neutral-600 dark:text-neutral-300 mb-6">{data.description}</p> : null}
            {/* Change link to a form submitting to the action */}
            <Form method="post">
              {/* No hidden inputs needed as accessKey is in URL params */}
              <button
                type="submit"
                className="inline-block rounded px-6 py-3 text-lg font-medium shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
                // Apply dynamic styles for branding
                style={{
                  backgroundColor: primaryColor,
                  color: textColor,
                  // Dynamically set focus ring color based on primary color
                  '--tw-ring-color': primaryColor // Use CSS variable for focus ring
                } as React.CSSProperties} // Cast to CSSProperties for type safety
              >
                Download File
              </button>
            </Form>
            <p className="mt-4 text-xs text-neutral-500 dark:text-neutral-400">
              Clicking download will initiate the process.
            </p>
          </> : null}

        {data.status === "revoked" ? <p className="text-red-600 dark:text-red-400">
            This sharing link has been revoked by the owner and is no longer active.
          </p> : null}

        {data.status === "expired" ? <p className="text-orange-600 dark:text-orange-400">
            {/* Ensure expiresAt exists before formatting */}
            This sharing link expired on {data.expiresAt ? <LocalTime iso={data.expiresAt} /> : 'an unknown date'} and is no longer active.
          </p> : null}

        <div className="mt-8 border-t border-border-light dark:border-border-dark pt-4">
           <Link to="/" className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
             Go to Homepage
           </Link>
        </div>
      </div>
    </div>
  );
}
