// No need for json import here
import { redirect, type ActionFunctionArgs } from "@remix-run/node"; // Import redirect and ActionFunctionArgs
import { describe, it, expect, vi, beforeEach, afterEach, type Mock } from "vitest"; // Add afterEach

import { prisma } from "~/db.server"; // Import the mocked prisma instance
import { getSignedDownloadUrl } from "~/s3.server"; // Import the function to mock
import { recordLinkDownloadEvent } from "~/models/analytics.server"; // Import for mocking

import { loader, action } from "./link.$accessKey"; // Import loader and action

// Mock the db.server module (already done in setup, but good practice to be aware)
// vi.mock("~/db.server");

// Mock the s3.server module
vi.mock("~/s3.server");
const mockedGetSignedDownloadUrl = vi.mocked(getSignedDownloadUrl);

// Mock the analytics.server module for recordLinkDownloadEvent
vi.mock("~/models/analytics.server", async (importOriginal) => {
  const actual = await importOriginal<typeof import("~/models/analytics.server")>();
  return {
    ...actual, // Keep other exports like getAnalyticsEventsForLink if any, though not used here
    recordLinkDownloadEvent: vi.fn(),
  };
});
const mockedRecordLinkDownloadEvent = vi.mocked(recordLinkDownloadEvent);

// Mock environment variables needed by s3.server.ts
const mockEnv = {
  AWS_S3_BUCKET_NAME: "test-bucket",
  AWS_REGION: "test-region",
  AWS_ACCESS_KEY_ID: "test-key-id",
  AWS_SECRET_ACCESS_KEY: "test-secret-key",
};


// Mock link data variations
const baseMockLink = {
  id: "link-123",
  userId: "user-abc",
  originalFileName: "test-document.pdf",
  storageKey: "s3-key-for-pdf",
  accessKey: "validAccessKey123",
  createdAt: new Date(),
  updatedAt: new Date(),
  fileType: "application/pdf",
  fileSizeBytes: 10240,
  description: "A test document",
  expiresAt: null,
  revoked: false,
};

const revokedMockLink = {
  ...baseMockLink,
  accessKey: "revokedAccessKey",
  revoked: true,
};

const expiredMockLink = {
  ...baseMockLink,
  accessKey: "expiredAccessKey",
  expiresAt: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
};

const validMockLink = {
  ...baseMockLink,
  accessKey: "validAccessKey123",
};

describe("Public Link Route Loader", () => {
  let originalEnv: NodeJS.ProcessEnv; // To store original env

  beforeEach(() => {
    // Reset mocks before each test
    vi.resetAllMocks();
    // Store original env and set mock env
    originalEnv = process.env;
    process.env = { ...originalEnv, ...mockEnv };
  });

  afterEach(() => {
    // Restore original env
    process.env = originalEnv;
  });


  it("should throw 404 if accessKey param is missing", async () => {
    // Arrange
    const request = new Request("http://localhost/link/"); // No access key

    // Act & Assert
    // invariant throws an Error
    await expect(loader({ request, params: {}, context: {} })).rejects.toThrow(
      "Missing accessKey param"
    );
  });

   it("should throw 404 if link is not found", async () => {
    // Arrange
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null); // Link not found
    const request = new Request("http://localhost/link/notFoundKey");
    const params = { accessKey: "notFoundKey" };

    // Act & Assert using try/catch
    try {
      await loader({ request, params, context: {} });
      expect.fail("Loader should have thrown an error");
    } catch (errorResponse) {
      expect(errorResponse).toBeInstanceOf(Response);
      const response = errorResponse as Response;
      expect(response.status).toBe(404);
      expect(await response.text()).toBe("Link not found");
    }
    // Update assertion to include the select clause
    expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
      where: { accessKey: "notFoundKey" },
      select: {
        id: true,
        userId: true,
        originalFileName: true,
        description: true,
        storageKey: true,
        revoked: true,
        expiresAt: true,
        user: {
          select: {
            plan: true,
            brandingLogoUrl: true,
            brandingColorPrimary: true,
            brandingColorText: true,
          }
        }
      },
    });
  });

  it("should return 'revoked' status if link is revoked", async () => {
    // Arrange
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(revokedMockLink);
    const request = new Request("http://localhost/link/revokedAccessKey");
    const params = { accessKey: "revokedAccessKey" };

    // Act
    const response = await loader({ request, params, context: {} });
    const data = await response.json();

    // Assert
    expect(response.status).toBe(200);
    expect(data).toEqual({
      status: "revoked",
      originalFileName: revokedMockLink.originalFileName,
    });
    // Update assertion to include the select clause
    expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
      where: { accessKey: "revokedAccessKey" },
      select: {
        id: true,
        userId: true,
        originalFileName: true,
        description: true,
        storageKey: true,
        revoked: true,
        expiresAt: true,
        user: {
          select: {
            plan: true,
            brandingLogoUrl: true,
            brandingColorPrimary: true,
            brandingColorText: true,
          }
        }
      },
    });
    // Ensure signed URL function was NOT called
    expect(mockedGetSignedDownloadUrl).not.toHaveBeenCalled();
  });

  it("should return 'expired' status if link is expired", async () => {
    // Arrange
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(expiredMockLink);
    const request = new Request("http://localhost/link/expiredAccessKey");
    const params = { accessKey: "expiredAccessKey" };

    // Act
    const response = await loader({ request, params, context: {} });
    const data = await response.json();

    // Assert
    expect(response.status).toBe(200);
    expect(data).toEqual({
      status: "expired",
      originalFileName: expiredMockLink.originalFileName,
      expiresAt: expiredMockLink.expiresAt?.toISOString(),
    });
    // Update assertion to include the select clause
     expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
      where: { accessKey: "expiredAccessKey" },
      select: {
        id: true,
        userId: true,
        originalFileName: true,
        description: true,
        storageKey: true,
        revoked: true,
        expiresAt: true,
        user: {
          select: {
            plan: true,
            brandingLogoUrl: true,
            brandingColorPrimary: true,
            brandingColorText: true,
          }
        }
      },
    });
    expect(mockedGetSignedDownloadUrl).not.toHaveBeenCalled();
  });

  it("should return 'valid' status with download URL if link is valid", async () => {
    // Arrange
    const mockSignedUrl = "https://s3.signed.url/for/s3-key-for-pdf?sig=123";
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(validMockLink);
    mockedGetSignedDownloadUrl.mockResolvedValue(mockSignedUrl);
    const request = new Request("http://localhost/link/validAccessKey123");
    const params = { accessKey: "validAccessKey123" };

    // Act
    const response = await loader({ request, params, context: {} });
    const data = await response.json();

    // Assert
    expect(response.status).toBe(200);
    // Update assertion: loader no longer returns downloadUrl
    expect(data).toEqual({
      status: "valid",
      originalFileName: validMockLink.originalFileName,
      description: validMockLink.description,
      ownerBranding: null, // Include the ownerBranding field
      // downloadUrl: mockSignedUrl, // Removed expectation
    });
    // Update assertion to include the select clause
    expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
      where: { accessKey: "validAccessKey123" },
      select: {
        id: true,
        userId: true,
        originalFileName: true,
        description: true,
        storageKey: true,
        revoked: true,
        expiresAt: true,
        user: {
          select: {
            plan: true,
            brandingLogoUrl: true,
            brandingColorPrimary: true,
            brandingColorText: true,
          }
        }
      },
    });
    // Loader no longer calls this
    expect(mockedGetSignedDownloadUrl).not.toHaveBeenCalled();
  });

   // Remove this test as the loader no longer generates the signed URL
   // it("should throw 500 if generating signed URL fails", async () => { ... });
});

describe("Public Link Route Action", () => {
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    vi.resetAllMocks();
    originalEnv = process.env;
    process.env = { ...originalEnv, ...mockEnv };
  });

  afterEach(() => {
    process.env = originalEnv;
  });

  const createActionArgs = (accessKey?: string): ActionFunctionArgs => {
    const request = new Request(`http://localhost/link/${accessKey || 'testKey'}`, {
      method: "POST", // Action is triggered by POST
    });
    return { request, params: { accessKey: accessKey || 'testKey' }, context: {} };
  };

  it("should throw if accessKey param is missing", async () => {
    const args = createActionArgs();
    // Simulate params being empty for this specific test
    args.params = {}; 
    await expect(action(args)).rejects.toThrow("Missing accessKey param");
  });

  it("should throw 404 Response if link is not found", async () => {
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null);
    const args = createActionArgs("notFoundKey");
    try {
      await action(args);
      expect.fail("Action should have thrown");
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      expect((response as Response).status).toBe(404);
      expect(await (response as Response).text()).toBe("Link not found");
    }
  });

  it("should throw 410 Response if link is revoked", async () => {
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(revokedMockLink);
    const args = createActionArgs(revokedMockLink.accessKey);
    try {
      await action(args);
      expect.fail("Action should have thrown");
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      expect((response as Response).status).toBe(410);
      expect(await (response as Response).text()).toBe("Link is invalid");
    }
  });

  it("should throw 410 Response if link is expired", async () => {
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(expiredMockLink);
    const args = createActionArgs(expiredMockLink.accessKey);
    try {
      await action(args);
      expect.fail("Action should have thrown");
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      expect((response as Response).status).toBe(410);
      expect(await (response as Response).text()).toBe("Link is invalid");
    }
  });

  it("should redirect to signed URL and record download event on success", async () => {
    const mockSignedUrl = "https://s3.example.com/signed-download-url";
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(validMockLink);
    mockedRecordLinkDownloadEvent.mockResolvedValue(undefined); // Does not return anything
    mockedGetSignedDownloadUrl.mockResolvedValue(mockSignedUrl);

    const args = createActionArgs(validMockLink.accessKey);
    const response = await action(args);

    expect(response).toBeInstanceOf(Response);
    expect(response.status).toBe(302); // Should be a redirect
    expect(response.headers.get("Location")).toBe(mockSignedUrl);

    expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
      where: { accessKey: validMockLink.accessKey },
      select: { id: true, userId: true, storageKey: true, revoked: true, expiresAt: true },
    });
    expect(mockedRecordLinkDownloadEvent).toHaveBeenCalledWith(validMockLink.id);
    expect(mockedGetSignedDownloadUrl).toHaveBeenCalledWith(validMockLink.storageKey, 60);
  });

  it("should throw 500 Response if getSignedDownloadUrl fails", async () => {
    (prisma.sharedLink.findUnique as Mock).mockResolvedValue(validMockLink);
    const s3Error = new Error("S3 SDK Error");
    mockedGetSignedDownloadUrl.mockRejectedValue(s3Error);
    
    const args = createActionArgs(validMockLink.accessKey);
    try {
      await action(args);
      expect.fail("Action should have thrown");
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      expect((response as Response).status).toBe(500);
      expect(await (response as Response).text()).toBe("Could not initiate download");
    }
  });
});
