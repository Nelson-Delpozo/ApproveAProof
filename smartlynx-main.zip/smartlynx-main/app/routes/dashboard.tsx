import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node"; // Remix types first (add SerializeFrom)
import { json, redirect } from "@remix-run/node";
import {
  Form,
  Link, // Import Link (will remove later if unused)
  useLoaderData,
  // Outlet, // Removed Outlet
  useFetcher,
  useRevalidator,
  useSubmit,
} from "@remix-run/react"; // Remix hooks/components
import { useState, useRef, ChangeEvent, useEffect, useCallback } from "react";
import invariant from "tiny-invariant";

// Local utilities/server functions
import { getAuthSession } from "~/auth.server";
import { LocalTime } from "~/components/LocalTime"; // Import LocalTime
import { prisma } from "~/db.server";
import { sendEmail } from "~/email.server";
import {
  recordLinkShareEvent,
  getAnalyticsEventCountsForLink, // Import the new count function
  type GetAnalyticsEventsResult,
} from "~/models/analytics.server";
import { stripe } from "~/stripe.server"; // Added Stripe client import - Removed .ts extension
// Type imports last
// Import the correct function from utils
import { formatDateTimeLocal, parseLocalDateTime } from "~/utils"; 

// Loader: Ensure user is logged in and pass user data to the component
export async function loader({ request }: LoaderFunctionArgs) {
  const user = await getAuthSession(request);
  if (!user) {
    // If not logged in, redirect to login, asking to be redirected back here after login
    const params = new URLSearchParams([
      ["redirectTo", new URL(request.url).pathname],
    ]);
    return redirect(`/login?${params.toString()}`);
  }

  // --- Add Filter Logic ---
  const url = new URL(request.url);
  const filterParam = url.searchParams.get("filter");
  const currentFilter = filterParam === "revoked" ? "revoked" : "active"; // Default to 'active'
  const filterStatus = currentFilter === "revoked"; // boolean: true if revoked, false if active
  // --- End Filter Logic ---

  // Fetch shared links for the logged-in user, applying the filter
  const links = await prisma.sharedLink.findMany({
    where: {
      userId: user.id,
      revoked: filterStatus, // Apply filter status here
    },
    orderBy: { createdAt: "desc" }, // Show newest first
  });

  // Fetch analytics counts for each link using the new function
  const linksWithCounts = await Promise.all(
    links.map(async (link) => {
      // Fetch counts from the analytics database
      const counts = await getAnalyticsEventCountsForLink(link.id);
      return {
        ...link,
        ...counts, // Spread the { viewCount, downloadCount, shareCount } object
      };
    }),
  );

  // Fetch the full user data including plan and subscription status
  const fullUser = await prisma.user.findUnique({
    where: { id: user.id },
    select: {
      id: true,
      email: true,
      auth0Sub: true,
      plan: true,
      stripeSubscriptionStatus: true,
      // Add branding fields
      brandingLogoUrl: true,
      brandingColorPrimary: true,
      brandingColorText: true,
    },
  });

  if (!fullUser) {
    throw new Response("User not found in database.", { status: 404 });
  }

  // For free users, count active links to check against the limit
  let activeLinksCount = null;
  if (fullUser.plan !== "PRO") {
    activeLinksCount = await prisma.sharedLink.count({
      where: {
        userId: user.id,
        revoked: false, // Always count non-revoked for the limit check
      },
    });
  }

  // Pass full user data, filtered links with counts, active links count, limit, and current filter
  return json({
    user: fullUser,
    links: linksWithCounts, // This list is now filtered
    activeLinksCount: activeLinksCount,
    linkLimit: fullUser.plan === "PRO" ? null : 5,
    currentFilter: currentFilter, // Pass the active filter to the component
  });
}

// Action: Handle form submissions (e.g., revoking links)
export async function action({ request }: ActionFunctionArgs) {
  const user = await getAuthSession(request);
  // Ensure user is logged in to perform actions
  if (!user) {
    throw new Response("Unauthorized", { status: 401 });
  }

  const formData = await request.formData();
  const intent = formData.get("intent");
  const linkId = formData.get("linkId");

  // Moved invariant check into relevant cases below

  // Removed redundant isProUser check here; checks are done within specific branding cases

  switch (intent) {
    // --- New Case for Stripe Checkout ---
    case "create-checkout-session": {
      invariant(
        process.env.STRIPE_PRO_PRICE_ID,
        "STRIPE_PRO_PRICE_ID must be set",
      );

      try {
        // Ensure the user session has the auth0Sub property before querying
        invariant(user.auth0Sub, "User session is missing Auth0 subject ID.");

        // Fetch the internal user record using the Auth0 subject from the session
        const dbUser = await prisma.user.findUnique({
          where: { auth0Sub: user.auth0Sub }, // Now guaranteed to be a string
        });

        if (!dbUser) {
          // This should ideally not happen if the user is authenticated via Auth0
          // and a corresponding DB record exists.
          throw new Response("User database record not found.", { status: 500 });
        }

        let stripeCustomerId = dbUser.stripeCustomerId;

        // If the user doesn't have a Stripe Customer ID yet, create one
        if (!stripeCustomerId) {
          const customer = await stripe.customers.create({
            email: dbUser.email,
            // Add other details like name if available and desired
            // name: user.name, // Example if name is available in Auth0 profile
            metadata: {
              // Link the Stripe customer to your internal user ID
              userId: dbUser.id,
            },
          });

          // Update the user record in your database with the new Stripe Customer ID
          await prisma.user.update({
            where: { id: dbUser.id },
            data: { stripeCustomerId: customer.id },
          });
          stripeCustomerId = customer.id;
        }

        // Define success and cancel URLs
        const origin = new URL(request.url).origin;
        const successUrl = `${origin}/dashboard?stripe=success`; // Add query param for feedback
        const cancelUrl = `${origin}/dashboard?stripe=cancel`; // Add query param for feedback

        // Create the Stripe Checkout session
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          mode: "subscription",
        customer: stripeCustomerId,
        line_items: [
          {
            price: process.env.STRIPE_PRO_PRICE_ID,
            quantity: 1,
          },
        ],
        success_url: successUrl,
        cancel_url: cancelUrl,
        // Optionally allow promotion codes
          // allow_promotion_codes: true,
        });

        // Ensure the session URL exists
        invariant(session.url, "Could not create Stripe Checkout session URL.");

        // Redirect the user to the Stripe Checkout page
        return redirect(session.url);
      } catch (error) {
        console.error("Error creating Stripe Checkout session:", error);
        throw new Response("Could not initiate checkout. Please try again later.", { status: 500 });
      }
    }
    // --- End New Case ---

    // --- New Case for Stripe Billing Portal ---
    case "create-billing-portal-session": {
      try {
        // Ensure the user session has the auth0Sub property before querying
        invariant(user.auth0Sub, "User session is missing Auth0 subject ID.");

        // Fetch the user's Stripe Customer ID
        const dbUser = await prisma.user.findUnique({
          where: { auth0Sub: user.auth0Sub },
          select: { stripeCustomerId: true }, // Only need the customer ID
        });

        // Ensure the user exists in DB and has a Stripe Customer ID
        invariant(dbUser, "User database record not found.");
        invariant(
          dbUser.stripeCustomerId,
          "User does not have a Stripe customer ID.",
        );

        // Define the return URL after the portal session
        const origin = new URL(request.url).origin;
        const returnUrl = `${origin}/dashboard`; // Return to dashboard

        // Create the Billing Portal session
        const portalSession = await stripe.billingPortal.sessions.create({
          customer: dbUser.stripeCustomerId,
          return_url: returnUrl,
        });

        // Ensure the session URL exists
        invariant(
          portalSession.url,
          "Could not create Stripe Billing Portal session URL.",
        );

        // Redirect the user to the Stripe Billing Portal
        return redirect(portalSession.url);
      } catch (error) {
        console.error("Error creating Stripe Billing Portal session:", error);
        throw new Response("Could not open billing portal. Please try again later.", { status: 500 });
      }
    }
    // --- End New Case ---

    case "revoke": {
      invariant(typeof linkId === "string", "Missing linkId"); // Check linkId here
      // Find the link first to ensure it belongs to the user
      const linkToRevoke = await prisma.sharedLink.findUnique({
        where: { id: linkId },
        select: { userId: true }, // Only select userId for verification
      });

      if (!linkToRevoke) {
        throw new Response("Link not found", { status: 404 });
      }

      // IMPORTANT: Verify the link belongs to the logged-in user
      if (linkToRevoke.userId !== user.id) {
        throw new Response("Forbidden: You do not own this link", {
          status: 403,
        });
      }

      // Perform the update
      try {
        await prisma.sharedLink.update({
          where: { id: linkId },
          data: { revoked: true },
        });
        // Return success - Remix will re-run the loader automatically
        return json({ ok: true, intent: "revoke" }); // Add intent for clarity
      } catch (error) {
        console.error(`Failed to revoke link ${linkId}:`, error);
        return json(
          {
            ok: false,
            error: "Failed to revoke link. Please try again.",
            intent: "revoke",
            linkId,
          },
          { status: 500 },
        );
      }
    }
    // --- New Case for Updating Expiry ---
    case "update-expiry": {
      invariant(typeof linkId === "string", "Missing linkId"); // Check linkId here
      const clearAction = formData.get("_action"); // Check for clear action
      const expiresAtStr = formData.get("expiresAt");

      // Find the link first to ensure it belongs to the user
      const linkToUpdate = await prisma.sharedLink.findUnique({
        where: { id: linkId },
        select: { userId: true },
      });

      if (!linkToUpdate) {
        throw new Response("Link not found", { status: 404 });
      }
      if (linkToUpdate.userId !== user.id) {
        throw new Response("Forbidden: You do not own this link", {
          status: 403,
        });
      }

      let expiresAt: Date | null = null;
      // If clear action is present, set to null. Otherwise, parse the date string.
      if (clearAction === "clearExpiry") {
        expiresAt = null;
      } else {
        // Only validate expiresAtStr if not clearing
        invariant(typeof expiresAtStr === "string", "Missing expiresAt value when not clearing");
        if (expiresAtStr) {
          try {
            // Get client timezone from form data
            const clientTimezone = formData.get("clientTimezone");
            invariant(typeof clientTimezone === "string" && clientTimezone, "Missing clientTimezone");

            // Use our new parseLocalDateTime function, passing the timezone
            // No longer need dynamic import as it's imported at the top now
            expiresAt = parseLocalDateTime(expiresAtStr, clientTimezone);
            
            // Basic validation if date is provided (parseLocalDateTime now returns Date(NaN) on failure)
            if (isNaN(expiresAt.getTime())) {
              return json(
                {
                  ok: false,
                  error: "Invalid date format provided.",
                  intent: "update-expiry",
                  linkId,
                },
                { status: 400 },
              );
            }
          } catch (error) {
            // Handle any errors from parseLocalDateTime
            console.error("Error parsing date:", error);
            return json(
              {
                ok: false,
                error: "Invalid date format provided.",
                intent: "update-expiry",
                linkId,
              },
              { status: 400 },
            );
          }
        } else {
          // If not clearing and expiresAtStr is empty, it's an invalid state unless handled differently
          // Depending on desired behavior, could return error or just not update.
          // Let's return an error for clarity if Save is clicked with empty input.
           return json(
             {
               ok: false,
               error: "Please select a date or use the Clear button.",
               intent: "update-expiry",
               linkId,
             },
             { status: 400 },
           );
        }
      }

      // Perform the update
      try {
        await prisma.sharedLink.update({
          where: { id: linkId },
          data: { expiresAt: expiresAt },
        });
        // Include linkId and cleared status in success response
        return json({ ok: true, intent: "update-expiry", linkId, cleared: expiresAt === null });
      } catch (error) {
         console.error(`Failed to update expiry for link ${linkId}:`, error);
         return json(
           {
             ok: false,
             error: "Failed to update link expiry. Please try again.",
             intent: "update-expiry",
             linkId,
           },
           { status: 500 },
         );
      }
    }
    // --- End New Case ---
    // --- New Case for Updating Description ---
    case "update-description": {
      invariant(typeof linkId === "string", "Missing linkId"); // Check linkId here
      const description = formData.get("description");
      invariant(typeof description === "string", "Missing description"); // Allow empty string

      // Find the link first to ensure it belongs to the user
      const linkToUpdate = await prisma.sharedLink.findUnique({
        where: { id: linkId },
        select: { userId: true },
      });

      if (!linkToUpdate) {
        throw new Response("Link not found", { status: 404 });
      }
      if (linkToUpdate.userId !== user.id) {
        throw new Response("Forbidden: You do not own this link", {
          status: 403,
        });
      }

      // Perform the update
      try {
        await prisma.sharedLink.update({
          where: { id: linkId },
          data: { description: description.trim() }, // Trim whitespace
        });
        // Include linkId in success response
        return json({ ok: true, intent: "update-description", linkId });
      } catch (error) {
         console.error(`Failed to update description for link ${linkId}:`, error);
         return json(
           {
             ok: false,
             error: "Failed to update link description. Please try again.",
             intent: "update-description",
             linkId,
           },
           { status: 500 },
         );
      }
    }
    // --- End New Case ---
    // --- New Case for Creating Link Record ---
    case "create-link-record": {
      const s3Key = formData.get("s3Key");
      const originalFilename = formData.get("originalFilename");
      const contentType = formData.get("contentType");
      const fileSizeStr = formData.get("fileSize");

      // Basic validation
      invariant(typeof s3Key === "string", "Missing s3Key");
      invariant(
        typeof originalFilename === "string",
        "Missing originalFilename",
      );
      invariant(typeof contentType === "string", "Missing contentType");
      invariant(typeof fileSizeStr === "string", "Missing fileSize");

      const fileSize = parseInt(fileSizeStr, 10);
      invariant(!isNaN(fileSize), "Invalid fileSize");

      // Get the user's plan from the database
      const dbUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { plan: true },
      });

      // Check if the user is on the FREE plan and at their link limit
      if (dbUser?.plan !== "PRO") {
        // Count active (not revoked) links for this user
        const activeLinksCount = await prisma.sharedLink.count({
          where: {
            userId: user.id,
            revoked: false,
          },
        });

        // Free users are limited to 5 active links
        if (activeLinksCount >= 5) {
          return json(
            {
              ok: false,
              error:
                "You've reached the maximum of 5 active links on the Free plan. Upgrade to Pro for unlimited links.",
              intent: "create-link-record",
            },
            { status: 403 },
          );
        }
      }

      // Create the SharedLink record
      try {
        await prisma.sharedLink.create({
          data: {
            userId: user.id,
            storageKey: s3Key, // Use correct schema field 'storageKey'
          originalFileName: originalFilename,
          fileType: contentType, // Use correct schema field 'fileType'
          fileSizeBytes: fileSize,
          // accessKey: generate unique access key logic here (e.g., nanoid)
          // description: optional, maybe add later
            // expiresAt: optional, maybe add later
          },
        });

        // Return success - useFetcher state will update, loader revalidates
        return json({ ok: true, intent: "create-link-record" });
      } catch (error) {
        console.error("Failed to create link record in database:", error);
        // Return a specific error for database failure during creation
        return json(
          {
            ok: false,
            error: "Failed to save link details to the database. Please try again.",
            intent: "create-link-record",
          },
          { status: 500 },
        );
      }
    }
    // --- End New Case ---
    // --- New Case for Sharing Link via Email ---
    case "share-link": {
      invariant(typeof linkId === "string", "Missing linkId");
      const recipientEmail = formData.get("recipientEmail");
      const message = formData.get("message"); // Optional message

      invariant(
        typeof recipientEmail === "string" && recipientEmail.trim() !== "",
        "Missing or invalid recipientEmail",
      );
      invariant(typeof message === "string", "Invalid message type"); // Allow empty string

      // Find the link to ensure it belongs to the user and get accessKey
      const linkToShare = await prisma.sharedLink.findUnique({
        where: { id: linkId },
        select: {
          userId: true,
          accessKey: true,
          originalFileName: true,
          revoked: true,
          expiresAt: true,
        },
      });

      if (!linkToShare) {
        throw new Response("Link not found", { status: 404 });
      }
      if (linkToShare.userId !== user.id) {
        throw new Response("Forbidden: You do not own this link", {
          status: 403,
        });
      }
      if (linkToShare.revoked) {
        return json(
          {
            ok: false,
            error: "Cannot share a revoked link.",
            intent: "share-link",
          },
          { status: 400 },
        );
      }
      if (
        linkToShare.expiresAt &&
        new Date(linkToShare.expiresAt) < new Date()
      ) {
        return json(
          {
            ok: false,
            error: "Cannot share an expired link.",
            intent: "share-link",
          },
          { status: 400 },
        );
      }

      // Basic email validation (could be more robust)
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail)) {
        return json(
          {
            ok: false,
            error: "Invalid recipient email format.",
            intent: "share-link",
          },
          { status: 400 },
        );
      }

      // Construct the public link URL
      const origin = new URL(request.url).origin;
      const publicLinkUrl = `${origin}/link/${linkToShare.accessKey}`;

      // Prepare email content
      const subject = `${user.email || "Someone"} shared a file with you via SmartLynx`;
      const textBody = `
        Hello,

        ${user.email || "Someone"} has shared the file "${linkToShare.originalFileName}" with you using SmartLynx.

        ${message ? `Message from sender:\n${message}\n\n` : ""}
        You can access the file here: ${publicLinkUrl}

        ${linkToShare.expiresAt ? `Note: This link expires on ${new Date(linkToShare.expiresAt).toUTCString()}.` : ""}

        Thanks,
        The SmartLynx Team
      `;
      // Consider an HTML version too for better formatting
      const htmlBody = `
        <p>Hello,</p>
        <p>${user.email || "Someone"} has shared the file "<strong>${linkToShare.originalFileName}</strong>" with you using SmartLynx.</p>
        ${message ? `<p><strong>Message from sender:</strong></p><p>${message.replace(/\n/g, "<br>")}</p>` : ""}
        <p>You can access the file here: <a href="${publicLinkUrl}">${publicLinkUrl}</a></p>
        ${linkToShare.expiresAt ? `<p><em>Note: This link expires on ${new Date(linkToShare.expiresAt).toUTCString()}.</em></p>` : ""}
        <p>Thanks,<br>The SmartLynx Team</p>
      `;

      const fromEmail = process.env.FROM_EMAIL;
      if (!fromEmail) {
        console.error("FROM_EMAIL environment variable is not set.");
        return json(
          {
            ok: false,
            error: "Server configuration error: Unable to send email.",
            intent: "share-link",
          },
          { status: 500 },
        );
      }

      try {
        await sendEmail({
          from: fromEmail, // Add the 'from' address
          to: recipientEmail,
          subject: subject,
          text: textBody,
          html: htmlBody,
        });

        // Record the share event (fire-and-forget, don't await or block response)
        // Use the updated function signature (linkId, recipientEmail)
        recordLinkShareEvent(linkId, recipientEmail);

        // Include linkId in the success response
        return json({ ok: true, intent: "share-link", linkId });
      } catch (error) {
        console.error("Failed to send share email:", error);
        // Don't expose detailed error messages to the client
        // Include linkId in the error response
        return json(
          {
            ok: false,
            error: "Failed to send email. Please try again later.",
            intent: "share-link",
            linkId,
          },
          { status: 500 },
        );
      }
    }
    // --- End New Case ---

    // --- Branding Actions ---
    case "update-branding-colors": {
      // Fetch user plan specifically for this action
      const dbUser = await prisma.user.findUnique({ where: { id: user.id }, select: { plan: true } });
      if (dbUser?.plan !== 'PRO') {
        return json({ ok: false, intent: "update-branding-colors", error: "Branding customization is a Pro feature." }, { status: 403 });
      }
      const colorPrimary = formData.get("brandingColorPrimary");
      const colorText = formData.get("brandingColorText");

      const hexRegex = /^#[0-9A-F]{6}$/i;
      invariant(typeof colorPrimary === "string", "Invalid primary color type");
      invariant(typeof colorText === "string", "Invalid text color type");

      if (colorPrimary && !hexRegex.test(colorPrimary)) {
        return json({ ok: false, intent: "update-branding-colors", error: "Invalid primary hex color format (e.g., #RRGGBB)." }, { status: 400 });
      }
      if (colorText && !hexRegex.test(colorText)) {
        return json({ ok: false, intent: "update-branding-colors", error: "Invalid text hex color format (e.g., #RRGGBB)." }, { status: 400 });
      }

      try {
        await prisma.user.update({
          where: { id: user.id }, // Use user.id from action scope
          data: {
            brandingColorPrimary: colorPrimary || null,
            brandingColorText: colorText || null,
          },
        });
        return json({ ok: true, intent: "update-branding-colors", error: null });
      } catch (error) {
         console.error(`Failed to update branding colors for user ${user.id}:`, error);
         return json(
           {
             ok: false,
             error: "Failed to save branding colors. Please try again.",
             intent: "update-branding-colors",
           },
           { status: 500 },
         );
      }
    }
    case "save-logo-url": {
       // Fetch user plan specifically for this action
       const dbUser = await prisma.user.findUnique({ where: { id: user.id }, select: { plan: true } });
       if (dbUser?.plan !== 'PRO') {
         return json({ ok: false, intent: "save-logo-url", error: "Branding customization is a Pro feature." }, { status: 403 });
       }
      const logoUrl = formData.get("logoUrl");
      invariant(typeof logoUrl === "string" && logoUrl.length > 0, "Missing logoUrl");

      if (!logoUrl.startsWith('http')) {
         return json({ ok: false, intent: "save-logo-url", error: "Invalid logo URL provided." }, { status: 400 });
      }

      try {
        await prisma.user.update({
          where: { id: user.id }, // Use user.id from action scope
          data: { brandingLogoUrl: logoUrl },
        });
         return json({ ok: true, intent: "save-logo-url", error: null });
      } catch (error) {
         console.error(`Failed to save logo URL for user ${user.id}:`, error);
         return json(
           {
             ok: false,
             error: "Failed to save logo URL. Please try again.",
             intent: "save-logo-url",
           },
           { status: 500 },
         );
      }
    }
    case "remove-logo": {
       // Fetch user plan specifically for this action
       const dbUser = await prisma.user.findUnique({ where: { id: user.id }, select: { plan: true } });
       if (dbUser?.plan !== 'PRO') {
         return json({ ok: false, intent: "remove-logo", error: "Branding customization is a Pro feature." }, { status: 403 });
       }
      // TODO: Optionally delete from S3 here if desired
      try {
        await prisma.user.update({
          where: { id: user.id }, // Use user.id from action scope
          data: { brandingLogoUrl: null },
        });
         return json({ ok: true, intent: "remove-logo", error: null });
      } catch (error) {
         console.error(`Failed to remove logo for user ${user.id}:`, error);
         return json(
           {
             ok: false,
             error: "Failed to remove logo. Please try again.",
             intent: "remove-logo",
           },
           { status: 500 },
         );
      }
    }
    // --- End Branding Actions ---

    default: {
      throw new Response(`Invalid intent: ${intent}`, { status: 400 });
    }
  }
}

// Define the expected return type from the branding actions
interface BrandingActionData {
  ok: boolean;
  intent: string;
  error: string | null;
}

// Basic Dashboard Component
export default function Dashboard() {
  // Use SerializeFrom to get the correct type after JSON serialization (handles Date -> string)
  // Destructure the full user object from the loader data
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const {
    user,
    links,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    activeLinksCount,
    linkLimit,
    currentFilter,
  } = useLoaderData<SerializeFrom<typeof loader>>(); // Add currentFilter
  // Now 'user' contains id, email, auth0Sub, plan, stripeSubscriptionStatus

  // State for the link limit modal
  const [isLinkLimitModalOpen, setIsLinkLimitModalOpen] = useState(false);
  // State for branding section visibility
  const [isBrandingOpen, setIsBrandingOpen] = useState(false);

  // Fetchers
  const createRecordFetcher = useFetcher<{
    ok: boolean;
    intent: string;
    error?: string;
  }>();
  // Fetcher for link-specific actions (revoke, expiry, share) - Add linkId? and cleared? to type
  const linkActionFetcher = useFetcher<{
    ok: boolean;
    intent: string;
    error?: string;
    linkId?: string;
    cleared?: boolean; // Add optional cleared flag
  }>();
  // Branding Fetchers - Use the explicit type
  const colorFetcher = useFetcher<BrandingActionData>();
  const logoUrlFetcher = useFetcher<BrandingActionData>(); // For saving/removing URL
  const removeLogoFetcher = useFetcher<BrandingActionData>(); // Separate fetcher for remove intent

  const revalidator = useRevalidator(); // To refresh loader data after successful upload/updates
  // const submit = useSubmit(); // Removed unused hook assignment

  // State for file upload
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<
    "idle" | "presigning" | "uploading" | "saving" | "success" | "error"
  >("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0); // State for upload progress (0-100)
  const fileInputRef = useRef<HTMLInputElement>(null); // Ref for file input
  const [copiedLinkId, setCopiedLinkId] = useState<string | null>(null); // State for copy feedback
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null); // State for description editing
  const [sharingLinkId, setSharingLinkId] = useState<string | null>(null); // State for email sharing form visibility
  const [hasProcessedUpload, setHasProcessedUpload] = useState(false); // State to prevent revalidation loop
  const [hasProcessedLogoSave, setHasProcessedLogoSave] = useState(false); // Flag for logo save effect
  const [hasProcessedLogoRemoval, setHasProcessedLogoRemoval] = useState(false); // Flag for logo removal effect
  const [isMounted, setIsMounted] = useState(false); // State to track client-side mount
  const [clientTimezone, setClientTimezone] = useState<string>(""); // State for client timezone
  const shareFormRef = useRef<HTMLFormElement>(null); // Ref for the share form
  const [lastProcessedExpiryActionId, setLastProcessedExpiryActionId] = useState<string | null>(null); // RE-ADD: State to prevent effect loop

  // State for logo upload process
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoUploadStatus, setLogoUploadStatus] = useState<"idle" | "presigning" | "uploading" | "saving" | "success" | "error">("idle");
  const [logoErrorMessage, setLogoErrorMessage] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // --- State for Analytics Modal ---
  const [viewingAnalyticsFor, setViewingAnalyticsFor] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const [analyticsPage, setAnalyticsPage] = useState(1);
  const analyticsFetcher =
    useFetcher<SerializeFrom<GetAnalyticsEventsResult>>();
  // --- End State for Analytics Modal ---

  // Set mounted state and get client timezone only on the client
  useEffect(() => {
    setIsMounted(true);
    // Get IANA timezone name
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      setClientTimezone(tz);
    } catch (e) {
      console.warn("Could not determine client timezone:", e);
      // Fallback or default timezone could be set here if needed
      setClientTimezone("UTC"); // Fallback to UTC if detection fails
    }
  }, []);

  // --- Handlers ---
  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => { // For regular file uploads
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setUploadStatus("idle"); // Reset status if a new file is selected
      setErrorMessage(null);
    }
  };

  const handleUpload = async () => { // For regular file uploads
    if (!selectedFile) return;

    setUploadStatus("presigning");
    setUploadProgress(0); // Reset progress on new upload
    setErrorMessage(null);
    setHasProcessedUpload(false); // Reset flag on new upload attempt

    // 1. Fetch presigned POST data from our backend action
    const presignFormData = new FormData();
    // Add null check for selectedFile before accessing properties
    if (!selectedFile) {
      setErrorMessage("No file selected.");
      setUploadStatus("error");
      return;
    }
    presignFormData.append("filename", selectedFile.name);
    presignFormData.append("contentType", selectedFile.type);
    // presignFetcher.submit(presignFormData, { method: "post", action: "/presign-upload" }); // Remove fetcher submit

    // --- Use direct fetch instead ---
    try {
      const presignResponse = await fetch("/presign-upload", {
        method: "POST",
        body: presignFormData,
        credentials: "include", // Ensure cookies are sent
      });

      if (!presignResponse.ok) {
        const errorData = await presignResponse
          .json()
          .catch(() => ({ error: "Failed to parse presign error response." }));
        throw new Error(
          errorData.error ||
            `Failed to prepare upload: ${presignResponse.statusText}`,
        );
      }

      const presignData = await presignResponse.json();
      const { url, fields, key } = presignData;

      if (!url || !fields || !key) {
        throw new Error("Incomplete presign data received.");
      }

      // --- Proceed with S3 upload ---
      setUploadStatus("uploading");
      const s3FormData = new FormData(); // Remove duplicate declaration
      Object.entries(fields).forEach(([field, value]) => {
        s3FormData.append(field, value as string); // Assume fields values are strings
      });
      // Add null check for selectedFile before appending
      if (!selectedFile) {
         throw new Error("File selection lost during upload process.");
      }
      s3FormData.append("file", selectedFile); // IMPORTANT: File must be the last field

      // --- Use XMLHttpRequest for S3 upload with progress ---
      const xhr = new XMLHttpRequest();

      // Progress listener
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percentComplete = Math.round((event.loaded / event.total) * 100);
          setUploadProgress(percentComplete);
        }
      };

      // Success listener
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          // S3 success (e.g., 204 No Content)
          console.log("S3 Upload successful via XHR");
          setUploadStatus("saving");
          setUploadProgress(100); // Ensure progress hits 100 on success

          // 3. Notify backend to create the database record
          const recordFormData = new FormData();
          recordFormData.append("intent", "create-link-record");
          recordFormData.append("s3Key", key);
          // Add null check for selectedFile before accessing properties
          if (!selectedFile) {
            // This case should be unlikely if upload succeeded, but handle defensively
            setUploadStatus("error");
            setErrorMessage("File selection lost after successful upload.");
            return;
          }
          recordFormData.append("originalFilename", selectedFile.name);
          recordFormData.append("contentType", selectedFile.type);
          recordFormData.append("fileSize", selectedFile.size.toString());
          createRecordFetcher.submit(recordFormData, { method: "post" }); // POST to current route's action
        } else {
          // Handle S3 error response
          console.error("S3 Upload Error Response (XHR):", xhr.responseText || xhr.statusText);
          setUploadStatus("error");
          setErrorMessage(`S3 upload failed: ${xhr.statusText || `Status ${xhr.status}`}`);
        }
      };

      // Error listener
      xhr.onerror = () => {
        console.error("S3 Upload Network Error (XHR)");
        setUploadStatus("error");
        setErrorMessage("Network error during S3 upload.");
      };

      // Abort listener (optional)
      xhr.onabort = () => {
        console.log("S3 Upload Aborted (XHR)");
        setUploadStatus("idle"); // Or 'error' depending on desired behavior
        setErrorMessage("Upload aborted.");
      };

      // Send the request
      xhr.open("POST", url, true);
      // Note: Do not set Content-Type header manually for FormData with XHR,
      // the browser sets it correctly including the boundary.
      xhr.send(s3FormData);
      // --- End XMLHttpRequest ---

    } catch (error: unknown) { // Catch errors from the presign fetch part
      console.error("Upload process error (presign stage):", error);
      setUploadStatus("error");
      const message =
        error instanceof Error
          ? error.message
          : "An unknown error occurred during upload preparation.";
      setErrorMessage(message);
    }
  };

  // Logo Upload Handlers
  const handleLogoFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        setLogoErrorMessage("Please select an image file.");
        return;
      }
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
         setLogoErrorMessage("Logo file size should not exceed 2MB.");
         return;
      }
      setLogoFile(file);
      setLogoErrorMessage(null);
      setLogoUploadStatus("idle");
    }
  };

  const handleLogoUpload = async () => {
    if (!logoFile || user.plan !== 'PRO') return; // Ensure user is Pro

    setLogoUploadStatus("presigning");
    setLogoErrorMessage(null);
    setHasProcessedLogoSave(false); // Reset flag before starting upload/save process

    try {
      // 1. Fetch presigned URL (needs a new route: /presign-logo-upload)
      const presignFormData = new FormData();
      presignFormData.append("filename", logoFile.name);
      presignFormData.append("contentType", logoFile.type);

      // IMPORTANT: Replace "/presign-logo-upload" if the route is named differently
      const presignResponse = await fetch("/presign-logo-upload", {
        method: "POST",
        body: presignFormData,
        credentials: "include",
      });

      if (!presignResponse.ok) {
        const errorData = await presignResponse.json().catch(() => ({ error: "Failed to parse presign error response." }));
        throw new Error(errorData.error || `Failed to prepare logo upload: ${presignResponse.statusText}`);
      }

      const presignData = await presignResponse.json();
      // Destructure all expected fields, including finalLogoUrl
      const { url, fields, key, finalLogoUrl } = presignData;

      if (!url || !fields || !key || !finalLogoUrl) { // Check for finalLogoUrl too
        throw new Error("Incomplete presign data received for logo.");
      }

      // 2. Upload logo directly to S3
      setLogoUploadStatus("uploading");
      const s3FormData = new FormData();
      Object.entries(fields).forEach(([field, value]) => {
        s3FormData.append(field, value as string);
      });
      s3FormData.append("file", logoFile);

      const s3Response = await fetch(url, {
        method: "POST",
        body: s3FormData,
      });

      if (!s3Response.ok) {
        const errorText = await s3Response.text().catch(() => `S3 logo upload failed with status ${s3Response.status}`);
        console.error("S3 Logo Upload Error Response:", errorText);
        throw new Error(`S3 logo upload failed: ${s3Response.statusText}`);
      }

      // 3. Save the S3 URL/Key to our database via action
      setLogoUploadStatus("saving");
      // Construct the public URL - **Placeholder, adjust as needed**
      // const bucketName = process.env.NEXT_PUBLIC_AWS_S3_BUCKET_NAME; // Removed unused variable
      // const region = process.env.NEXT_PUBLIC_AWS_REGION; // Removed unused variable
      // If env vars aren't available client-side, fetch them in loader or hardcode if static
      // For now, assuming they might be available or we construct differently
      // Let's assume for now the key itself is enough or the URL is constructed server-side/returned differently
      // Using a simplified approach: save the key, construct URL on display if needed
      // Or better: construct the final URL here if possible
      // Example: const finalLogoUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${key}`;
      // **Using the key directly for now, assuming URL construction happens elsewhere or key is URL**
      // **Update: Let's try constructing it here, assuming env vars are somehow available or passed via loader**
      // **Revisiting: Best practice is likely to construct the URL server-side or return it from presign.
      // For now, we'll just save the key and assume display logic handles it, OR pass the full URL if the key IS the URL.**
      // Let's assume `key` returned from presign IS the full public URL for simplicity here.
      // const finalLogoUrl = key; // REMOVED - Use the one from presignData

      const saveUrlFormData = new FormData();
      saveUrlFormData.append("intent", "save-logo-url");
      // Use the finalLogoUrl returned from the presign route
      saveUrlFormData.append("logoUrl", finalLogoUrl);
      logoUrlFetcher.submit(saveUrlFormData, { method: "post" }); // Submit to dashboard action

      // Reset file input after starting save
      setLogoFile(null);
      if (logoInputRef.current) logoInputRef.current.value = "";

    } catch (error: unknown) {
      console.error("Logo upload process error:", error);
      setLogoUploadStatus("error");
      const message = error instanceof Error ? error.message : "An unknown error occurred during logo upload.";
      setLogoErrorMessage(message);
    }
  };

  // --- Effects ---

  // Effect to handle the response from the create record fetcher (for regular file uploads)
  useEffect(() => {
    if (
      createRecordFetcher.state === "idle" &&
      createRecordFetcher.data?.intent === "create-link-record"
    ) {
      if (createRecordFetcher.data.ok) {
        // Only process success once per upload attempt
        if (!hasProcessedUpload) {
          setUploadStatus("success");
          setSelectedFile(null); // Clear selection
          if (fileInputRef.current) fileInputRef.current.value = ""; // Clear file input visually
          revalidator.revalidate(); // Re-run the loader to show the new link
          setHasProcessedUpload(true); // Mark as processed
          // Optionally reset status after a delay
          setTimeout(() => setUploadStatus("idle"), 3000);
        }
      } else if (createRecordFetcher.data.error) { // Check specifically if an error message exists
        // Handle error case
        setUploadStatus("error");
        // Display the specific error message returned from the action
        setErrorMessage(createRecordFetcher.data.error);
        setHasProcessedUpload(true); // Also mark as processed on error to stop loops if any

        // Check if the error is specifically about the link limit
        if (
          createRecordFetcher.data.error?.includes("maximum of 5 active links")
        ) {
          // Show the link limit modal
          setIsLinkLimitModalOpen(true);
        }
      }
    }
  }, [
    createRecordFetcher.state,
    createRecordFetcher.data,
    revalidator,
    hasProcessedUpload,
  ]); // Add hasProcessedUpload to dependencies

  // Effect to handle logo URL save response
  useEffect(() => {
     if (logoUrlFetcher.state === 'idle' && logoUrlFetcher.data) {
       // Only process if the flag is not set
       if (logoUrlFetcher.data.ok && !hasProcessedLogoSave) {
         setLogoUploadStatus("success");
         revalidator.revalidate(); // Revalidate to show new logo
         setHasProcessedLogoSave(true); // Set flag after revalidation starts
         setTimeout(() => setLogoUploadStatus("idle"), 3000);
       } else if (!logoUrlFetcher.data.ok) { // Process error regardless of flag? Or add flag check here too? Let's process error always for now.
         setLogoUploadStatus("error");
         setLogoErrorMessage(logoUrlFetcher.data.error ?? "Failed to save logo URL.");
         // Consider setting hasProcessedLogoSave(true) on error too if needed to prevent loops
       }
     }
     // Add hasProcessedLogoSave to dependency array
  }, [logoUrlFetcher.state, logoUrlFetcher.data, revalidator, hasProcessedLogoSave]);

   // Effect to handle logo removal response
   useEffect(() => {
     // Only process if the flag is not set
     if (removeLogoFetcher.state === 'idle' && removeLogoFetcher.data?.ok && !hasProcessedLogoRemoval) {
       // Optionally show a success message briefly
       revalidator.revalidate(); // Revalidate to show logo removed
       setHasProcessedLogoRemoval(true); // Set flag after revalidation starts
     }
     // Handle error case if needed (process error always for now)
     else if (removeLogoFetcher.state === 'idle' && removeLogoFetcher.data?.ok === false) {
        // Handle potential removal errors if necessary
     }
     // Add hasProcessedLogoRemoval to dependency array
   }, [removeLogoFetcher.state, removeLogoFetcher.data, revalidator, hasProcessedLogoRemoval]);


  // --- Copy Link Handler ---
  const handleCopyLink = useCallback((accessKey: string, linkId: string) => {
    const urlToCopy = `${window.location.origin}/link/${accessKey}`;
    navigator.clipboard
      .writeText(urlToCopy)
      .then(() => {
        setCopiedLinkId(linkId); // Set the ID of the link whose button was clicked
        // Reset the "Copied!" state after a short delay
        setTimeout(() => setCopiedLinkId(null), 2000);
      })
      .catch((err) => {
        console.error("Failed to copy link: ", err);
        // Optionally show an error message to the user
      });
  }, []); // Empty dependency array as it doesn't depend on component state/props that change

  // --- Effect to load analytics data when modal opens or page changes ---
  useEffect(() => {
    if (viewingAnalyticsFor) {
      const apiUrl = `/api/analytics/${viewingAnalyticsFor.id}?page=${analyticsPage}`;
      analyticsFetcher.load(apiUrl);
    }
    // We only want this effect to run when the link ID or page changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewingAnalyticsFor, analyticsPage]);
  // --- End Effect ---

  // --- Effect to reset share form on success ---
  useEffect(() => {
    if (
      linkActionFetcher.state === "idle" &&
      linkActionFetcher.data?.ok === true &&
      linkActionFetcher.data?.intent === "share-link" &&
      shareFormRef.current
    ) {
      shareFormRef.current.reset();
      // Optional: Keep the success message visible a bit longer if needed,
      // but the form closing logic might handle this.
    }
  }, [linkActionFetcher.state, linkActionFetcher.data]);
  // --- End Effect ---

  // --- Effect to handle expiry update success (revalidate) ---
  useEffect(() => {
    const { state, data } = linkActionFetcher; // Destructure for stability
    if (
      state === "idle" &&
      data?.ok === true &&
      data?.intent === "update-expiry" &&
      data?.linkId &&
      data.linkId !== lastProcessedExpiryActionId // RE-ADD: Check if this action ID has already been processed
    ) {
      // Manual clearing removed, key prop handles re-mount
      // if (data.cleared === true) {
      //   const formRef = expiryFormRefs.current[data.linkId];
      //   if (formRef) {
      //     const inputElement = formRef.querySelector<HTMLInputElement>('input[name="expiresAt"]');
      //     if (inputElement) {
      //       inputElement.value = "";
      //     } else {
      //        console.warn(`Could not find expiresAt input for link ${data.linkId} to clear visually.`);
      //     }
      //   }
      // }

      // Revalidate after a successful expiry update (save or clear)
      // Delay revalidation slightly if clearing, to potentially help visual updates settle, though key prop is main mechanism.
      if (data.cleared === true) {
        setTimeout(() => {
          revalidator.revalidate();
          // RE-ADD: Mark this action ID as processed *after* revalidation starts for clear actions
          setLastProcessedExpiryActionId(data.linkId ?? null); // Handle potential undefined
        }, 10); // Small delay (10ms)
      } else {
        // Revalidate immediately for save actions
        revalidator.revalidate();
        // RE-ADD: Mark this action ID as processed immediately for save actions
        setLastProcessedExpiryActionId(data.linkId ?? null); // Handle potential undefined
      }
    }
    // RE-ADD: Depend on the fetcher object, revalidator, and the tracking state
  }, [linkActionFetcher, revalidator, lastProcessedExpiryActionId]);
  // --- End Effect ---


  const isUploading = ["presigning", "uploading", "saving"].includes(uploadStatus);
  const isLogoUploading = ["presigning", "uploading", "saving"].includes(logoUploadStatus);
  const isPro = user.plan === 'PRO'; // Determine if user is Pro

  return (
    // Add overflow-x-hidden to prevent potential horizontal scroll on small screens if needed
    // Apply page background and text colors from theme
    <div className="container mx-auto overflow-x-hidden p-4 text-text-light dark:text-text-dark">
      {/* Header: Stack on small, row on medium+ */}
      <header className="mb-6 flex flex-col items-start gap-2 md:flex-row md:items-center md:justify-between">
        <h1 className="text-3xl font-bold text-neutral-800 dark:text-neutral-100">Control Center</h1>
        {/* Welcome message and logout button group */}
        <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:gap-4">
          <span className="truncate text-neutral-700 dark:text-neutral-300">Logged in as: {user.email}</span>{" "}
          {/* Add truncate for long emails */}
          {/* Removed Branding Link */}
        </div>
      </header>

      <div className="space-y-4">
        {/* <p>Create, Share, Control, and Track Document Links</p> */}

        {/* --- Billing/Upgrade Section --- */}
        <div className="my-6 rounded-md border border-border-light dark:border-border-dark bg-neutral-50 dark:bg-neutral-800 p-4">
          <h2 className="mb-3 text-lg font-semibold text-neutral-800 dark:text-neutral-100">Account Plan</h2>
          {user.plan === "PRO" ? (
            // User is on PRO plan
            // Keep items-start for mobile stacking
            <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-neutral-700 dark:text-neutral-300">
                You are currently on the <strong className="text-neutral-900 dark:text-neutral-100">SmartLynx Pro</strong> plan.
              </p>
              {/* Make Form a flex container, center content on mobile, revert on sm+ */}
              <Form
                method="post"
                className="flex w-full justify-center sm:w-auto sm:justify-start"
              >
                <input
                  type="hidden"
                  name="intent"
                  value="create-billing-portal-session"
                />
                <button
                  type="submit"
                  className="inline-flex items-center rounded-md border border-transparent bg-neutral-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-neutral-700 dark:bg-neutral-500 dark:hover:bg-neutral-600 focus:outline-none focus:ring-2 focus:ring-neutral-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
                >
                  Manage Billing & Subscription
                </button>
              </Form>
            </div>
          ) : (
            // User is on FREE plan (or any non-PRO plan)
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-neutral-700 dark:text-neutral-300">
                You are currently on the <strong className="text-neutral-900 dark:text-neutral-100">Free</strong> plan.
              </p>
              <Form method="post">
                <input
                  type="hidden"
                  name="intent"
                  value="create-checkout-session"
                />
                <button
                  type="submit"
                  className="inline-flex items-center rounded-md border border-transparent bg-green-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
                >
                  Upgrade to Pro ($15/month)
                </button>
              </Form>
            </div>
          )}

          {/* Display feedback from Stripe redirect */}
          {/* TODO: Enhance this feedback based on query params */}
          {/* <p className="mt-2 text-sm text-green-600">Stripe Success!</p> */}
          {/* <p className="mt-2 text-sm text-red-600">Stripe Cancelled.</p> */}
        </div>
        {/* --- End Billing/Upgrade Section --- */}

        {/* List of Shared Links */}
        <div className="mt-8">
          <h2 className="mb-4 text-xl font-semibold text-neutral-800 dark:text-neutral-100">
            Manage Your Shareable Links
          </h2>
                  {/* --- Collapsible Branding Section --- */}
        <div className="my-6 overflow-hidden rounded-md border border-border-light dark:border-border-dark bg-card-background-light dark:bg-card-background-dark shadow-sm">
          {/* Use a button for accessibility */}
          <button
            type="button" // Explicitly set type
            className="flex w-full cursor-pointer items-center justify-between bg-neutral-50 dark:bg-neutral-800 p-4 text-left hover:bg-neutral-100 dark:hover:bg-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-inset" // Add focus styles, text-left, w-full
            onClick={() => setIsBrandingOpen(!isBrandingOpen)}
            aria-expanded={isBrandingOpen}
            aria-controls="branding-content"
          >
            <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100">Branding</h2>
            {/* Chevron Icon */}
            <svg
              className={`h-5 w-5 transform text-neutral-500 dark:text-neutral-400 transition-transform duration-200 ${
                isBrandingOpen ? "rotate-180" : ""
              }`}
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </button>

          {/* Collapsible Content */}
          {isBrandingOpen ? <div id="branding-content" className="relative border-t border-border-light dark:border-border-dark p-6">
              {/* Upgrade Overlay for Free Users */}
              {!isPro ? <div className="absolute inset-0 z-10 flex flex-col items-center justify-center rounded-b-md bg-neutral-100 dark:bg-neutral-800 bg-opacity-80 dark:bg-opacity-90 p-6 text-center">
                  <h3 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100">
                    Upgrade to Pro
                  </h3>
                  <p className="my-2 text-sm text-neutral-600 dark:text-neutral-300">
                    Customize your link pages with your logo and brand colors
                    by upgrading to SmartLynx Pro
                  </p>
                  {/* Use the existing Stripe form logic */}
                  <Form method="post">
                     <input type="hidden" name="intent" value="create-checkout-session" />
                     <button
                       type="submit"
                       className="rounded-md bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
                     >
                       Upgrade Now ($15/month)
                     </button>
                   </Form>
                </div> : null}

              {/* Branding Form Fields (Disabled for Free Users via fieldset) */}
              <fieldset disabled={!isPro} className="space-y-6">
                {/* Logo Section */}
                <div>
                  <h3 className="text-lg font-medium leading-6 text-neutral-900 dark:text-neutral-100">
                    Logo
                  </h3>
                  <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
                    Upload your company logo (Recommended: PNG/JPG/SVG, max
                    2MB).
                  </p>
                  <div className="mt-4 flex flex-wrap items-center gap-4"> {/* Use flex-wrap and gap */}
                    <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-border-light dark:border-border-dark bg-neutral-100 dark:bg-neutral-700">
                      {user.brandingLogoUrl ? (
                        <img
                          src={user.brandingLogoUrl}
                          alt="Current Logo"
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <span className="flex h-full w-full items-center justify-center text-xs text-neutral-400 dark:text-neutral-500">
                          No Logo
                        </span>
                      )}
                    </div>
                    <input
                      ref={logoInputRef}
                      type="file"
                      accept="image/png, image/jpeg, image/gif, image/svg+xml"
                      onChange={handleLogoFileChange}
                      className="block w-auto flex-grow text-sm text-neutral-500 dark:text-neutral-400 file:mr-4 file:rounded-full file:border-0 file:bg-primary-50 dark:file:bg-primary-800 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-primary-700 dark:file:text-primary-200 hover:file:bg-primary-100 dark:hover:file:bg-primary-700 disabled:cursor-not-allowed disabled:opacity-50" // Adjust width
                    />
                    <div className="flex gap-2"> {/* Group buttons */}
                      <button
                        type="button"
                        onClick={handleLogoUpload}
                        disabled={!logoFile || isLogoUploading || !isPro}
                        className="inline-flex items-center rounded-md border border-transparent bg-primary-600 px-3 py-1.5 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {isLogoUploading ? "Uploading..." : "Upload Logo"}
                      </button>
                      {user.brandingLogoUrl ? (
                        <removeLogoFetcher.Form
                          method="post"
                          onSubmit={() => {
                            setHasProcessedLogoRemoval(false); // Reset flag on submit
                          }}
                        >
                          <input type="hidden" name="intent" value="remove-logo" />
                          <button
                            type="submit"
                            disabled={removeLogoFetcher.state !== 'idle' || !isPro}
                            className="rounded-md border border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 px-3 py-1.5 text-sm font-medium text-neutral-700 dark:text-neutral-200 shadow-sm hover:bg-neutral-50 dark:hover:bg-neutral-600 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            Remove Logo
                          </button>
                        </removeLogoFetcher.Form>
                      ) : null}
                    </div>
                  </div>
                  {/* Logo Status/Error Messages */}
                  {logoUploadStatus === "success" ? <p className="mt-2 text-sm text-green-600 dark:text-green-400">Logo uploaded successfully!</p> : null}
                  {logoUploadStatus === "error" ? <p className="mt-2 text-sm text-red-600 dark:text-red-400">{logoErrorMessage || "Logo upload failed."}</p> : null}
                  {removeLogoFetcher.data?.ok && removeLogoFetcher.data?.intent === 'remove-logo' ? <p className="mt-2 text-sm text-green-600 dark:text-green-400">Logo removed.</p> : null}
                  {removeLogoFetcher.data?.ok === false && removeLogoFetcher.data?.error ? <p className="mt-2 text-sm text-red-600 dark:text-red-400">{removeLogoFetcher.data.error}</p> : null}
                </div>

                {/* Color Section */}
                <colorFetcher.Form method="post" className="space-y-4 border-t border-border-light dark:border-border-dark pt-6">
                  <input type="hidden" name="intent" value="update-branding-colors" />
                  <h3 className="text-lg font-medium leading-6 text-neutral-900 dark:text-neutral-100">
                    Brand Colors
                  </h3>
                  <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
                    Choose colors for your public link pages.
                  </p>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="colorPrimary" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300">
                        Primary Color
                      </label>
                      <div className="mt-1 flex items-center space-x-2">
                        <input
                          type="color"
                          name="brandingColorPrimary"
                          id="colorPrimary"
                          defaultValue={user.brandingColorPrimary ?? "#6366F1"} // Default to indigo-500
                          className="h-8 w-10 rounded border-border-light dark:border-border-dark p-0 disabled:cursor-not-allowed disabled:opacity-50"
                        />
                        <input
                          type="text"
                          name="brandingColorPrimary" // Use same name to override color picker if typed
                          defaultValue={user.brandingColorPrimary ?? "#6366F1"}
                          placeholder="#RRGGBB"
                          pattern="^#[0-9A-Fa-f]{6}$"
                          title="Enter a valid 6-digit hex color code (e.g., #6366F1)"
                          className="block w-full max-w-xs rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm disabled:cursor-not-allowed disabled:opacity-50"
                          // Add JS later if needed to sync color picker <-> text input
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="colorText" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300">
                        Text Color (on Primary)
                      </label>
                      <div className="mt-1 flex items-center space-x-2">
                        <input
                          type="color"
                          name="brandingColorText"
                          id="colorText"
                          defaultValue={user.brandingColorText ?? "#FFFFFF"} // Default to white
                          className="h-8 w-10 rounded border-border-light dark:border-border-dark p-0 disabled:cursor-not-allowed disabled:opacity-50"
                        />
                        <input
                          type="text"
                          name="brandingColorText" // Use same name
                          defaultValue={user.brandingColorText ?? "#FFFFFF"}
                          placeholder="#RRGGBB"
                          pattern="^#[0-9A-Fa-f]{6}$"
                          title="Enter a valid 6-digit hex color code (e.g., #FFFFFF)"
                          className="block w-full max-w-xs rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm disabled:cursor-not-allowed disabled:opacity-50"
                           // Add JS later if needed to sync color picker <-> text input
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end pt-4"> {/* Add padding top */}
                    <button
                      type="submit"
                      disabled={colorFetcher.state !== 'idle' || !isPro}
                      className="rounded-md border border-transparent bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {colorFetcher.state !== 'idle' ? "Saving..." : "Save Colors"}
                    </button>
                  </div>
                  {/* Color Save Status/Error Messages */}
                  {colorFetcher.data?.ok === true && colorFetcher.data?.intent === 'update-branding-colors' ? <p className="mt-2 text-sm text-green-600 dark:text-green-400">Colors saved successfully!</p> : null}
                  {colorFetcher.data?.ok === false && colorFetcher.data?.error ? <p className="mt-2 text-sm text-red-600 dark:text-red-400">{colorFetcher.data.error}</p> : null}
                </colorFetcher.Form>
              </fieldset>
            </div> : null}
        </div>
        {/* --- End Collapsible Branding Section --- */}

          {/* --- New Upload Section --- */}
          <div className="my-6 rounded-md border border-border-light dark:border-border-dark bg-neutral-50 dark:bg-neutral-800 p-4">
            <h2 className="mb-3 text-lg font-semibold text-neutral-800 dark:text-neutral-100">
              Create a Shareable Link
            </h2>

            {/* Warning banner removed - will use modal instead */}

            {/* Upload controls: Stack on small, row on medium+ */}
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <input
                ref={fileInputRef}
                type="file"
                // Ensure input takes full width on small screens
                onChange={handleFileChange}
                disabled={isUploading}
                className="block w-full flex-grow text-sm text-neutral-500 dark:text-neutral-400 file:mr-4 file:rounded-full file:border-0 file:bg-primary-50 dark:file:bg-primary-800 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-primary-700 dark:file:text-primary-200 hover:file:bg-primary-100 dark:hover:file:bg-primary-700 disabled:cursor-not-allowed disabled:opacity-50" // Add flex-grow for larger screens
              />
              <button
                type="button"
                onClick={handleUpload}
                // Ensure button takes reasonable space
                disabled={!selectedFile || isUploading}
                className="inline-flex items-center rounded-md border border-transparent bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isUploading ? "Uploading..." : "Upload"}
              </button>
            </div>
            {/* Status Messages */}
            {uploadStatus === "presigning" ? (
              <p className="mt-2 text-sm text-blue-600 dark:text-blue-400">Preparing upload...</p>
            ) : null}
            {/* --- Add Progress Bar --- */}
            {uploadStatus === "uploading" ? (
              <div className="mt-2 w-full">
                <p className="mb-1 text-sm text-blue-600 dark:text-blue-400">
                  Uploading to storage... {uploadProgress}%
                </p>
                <div className="h-2 w-full overflow-hidden rounded-full bg-neutral-200 dark:bg-neutral-700">
                  <div
                    className="h-full rounded-full bg-primary-600 dark:bg-primary-500 transition-all duration-150 ease-out" // Added transition
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            ) : null}
            {/* --- End Progress Bar --- */}
            {uploadStatus === "saving" ? (
              <p className="mt-2 text-sm text-blue-600 dark:text-blue-400">
                Saving link details... (Upload Complete)
              </p>
            ) : null}
            {uploadStatus === "success" ? (
              <p className="mt-2 text-sm text-green-600 dark:text-green-400">Upload successful!</p>
            ) : null}
            {uploadStatus === "error" ? (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                {errorMessage || "Upload failed."}
              </p>
            ) : null}
          </div>
          {/* --- End Upload Section --- */}
          {/* --- Filter Tabs --- */}
          <div className="mb-4 border-b border-border-light dark:border-border-dark">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
              <Link
                to="/dashboard?filter=active"
                prefetch="intent" // Prefetch data on hover/focus
                className={`${
                  currentFilter === "active"
                    ? "border-primary-500 text-primary-600 dark:border-primary-400 dark:text-primary-400"
                    : "border-transparent text-neutral-500 dark:text-neutral-400 hover:border-neutral-300 dark:hover:border-neutral-600 hover:text-neutral-700 dark:hover:text-neutral-200"
                } whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium`}
              >
                Active Links
              </Link>
              <Link
                to="/dashboard?filter=revoked"
                prefetch="intent"
                className={`${
                  currentFilter === "revoked"
                    ? "border-primary-500 text-primary-600 dark:border-primary-400 dark:text-primary-400"
                    : "border-transparent text-neutral-500 dark:text-neutral-400 hover:border-neutral-300 dark:hover:border-neutral-600 hover:text-neutral-700 dark:hover:text-neutral-200"
                } whitespace-nowrap border-b-2 px-1 py-4 text-sm font-medium`}
              >
                Revoked Links
              </Link>
            </nav>
          </div>
          {/* --- End Filter Tabs --- */}

          {links.length === 0 ? (
            <p className="text-neutral-500 dark:text-neutral-400">You have no {currentFilter} links.</p>
          ) : (
            <ul className="space-y-3">
              {/* Remove explicit SharedLink type; useLoaderData provides the correct JSONified type */}
              {links.map((link) => {
                // --- DIAGNOSTIC LOG REMOVED ---
                // console.log('Dashboard Render - Link Expiry Check:', link.id, 'expiresAt:', link.expiresAt);
                return (
                // Link Item: Stack on small, row on medium+
                <li
                  key={link.id}
                  className={`flex flex-col gap-4 rounded-md border border-border-light dark:border-border-dark p-4 shadow-sm md:flex-row md:items-center md:justify-between ${link.revoked ? "bg-neutral-100 dark:bg-neutral-800 opacity-70 dark:opacity-60" : "bg-card-background-light dark:bg-card-background-dark"}`}
                >
                  {/* Link Details Section - Added overflow-hidden for truncate */}
                  <div
                    className={`flex-grow ${link.revoked ? "line-through" : ""} overflow-hidden`}
                  >
                    {/* Added truncate and block/w-full for proper truncation */}
                    <span className="mb-1 block w-full truncate font-medium text-neutral-800 dark:text-neutral-100">
                      {link.originalFileName}
                    </span>
                    {/* Description - Editable */}
                    {editingLinkId === link.id ? (
                      <linkActionFetcher.Form
                        method="post"
                        className="mt-1"
                        onSubmit={() => setEditingLinkId(null)}
                      >
                        <input
                          type="hidden"
                          name="intent"
                          value="update-description"
                        />
                        <input type="hidden" name="linkId" value={link.id} />
                        <textarea
                          name="description"
                          defaultValue={link.description || ""}
                          rows={2}
                          className="block w-full rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 p-1 text-xs shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                          placeholder="Enter description..."
                        />
                        <div className="mt-1 flex gap-1">
                          <button
                            type="submit"
                            className="rounded bg-green-500 px-2 py-1 text-xs font-medium text-white hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingLinkId(null)}
                            className="rounded bg-neutral-400 px-2 py-1 text-xs font-medium text-white hover:bg-neutral-500 dark:bg-neutral-600 dark:hover:bg-neutral-700"
                          >
                            Cancel
                          </button>
                        </div>
                        {/* Display fetcher errors specifically for description update */}
                        {linkActionFetcher.state !== "idle" &&
                        linkActionFetcher.formData?.get("intent") ===
                          "update-description" &&
                        linkActionFetcher.formData?.get("linkId") === link.id &&
                        linkActionFetcher.data?.error ? (
                          <p className="mt-1 text-xs text-red-500 dark:text-red-400">
                            {linkActionFetcher.data.error}
                          </p>
                        ) : null}
                      </linkActionFetcher.Form>
                    ) : (
                      <div className="mt-1 flex items-center gap-2">
                        <p className="flex-grow text-sm text-neutral-600 dark:text-neutral-300">
                          {link.description || (
                            <span className="italic text-neutral-400 dark:text-neutral-500">
                              No description
                            </span>
                          )}
                        </p>
                        {!link.revoked ? (
                          <button
                            type="button"
                            onClick={() => setEditingLinkId(link.id)}
                            className="rounded bg-yellow-500 px-2 py-1 text-xs font-medium text-white hover:bg-yellow-600 dark:bg-yellow-600 dark:hover:bg-yellow-700"
                            title="Edit description"
                          >
                            Edit
                          </button>
                        ) : null}
                      </div>
                    )}
                    <p className="mt-1 text-xs text-neutral-400 dark:text-neutral-500">
                      Created: <LocalTime iso={link.createdAt} />
                    </p>
                    {/* Display Expiry Date */}
                    <p className="text-xs text-neutral-400 dark:text-neutral-500">
                      Expires:{" "}
                      {link.expiresAt
                        ? <LocalTime iso={link.expiresAt} />
                        : "Never"}
                    </p>
                    {/* Display Analytics Counts */}
                    <p className="mt-2 text-xs text-neutral-400 dark:text-neutral-500">
                      {" "}
                      {/* Add margin-top */}
                      {/* Make counts clickable */}
                      <button
                        type="button"
                        onClick={() => {
                          setAnalyticsPage(1); // Reset to page 1 when opening
                          setViewingAnalyticsFor({
                            id: link.id,
                            name: link.originalFileName,
                          });
                        }}
                        className="text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300 hover:underline disabled:cursor-not-allowed disabled:no-underline disabled:opacity-50"
                        // Update disabled logic to include shareCount
                        disabled={
                          link.revoked ||
                          (link.viewCount ?? 0) +
                            (link.downloadCount ?? 0) +
                            (link.shareCount ?? 0) ===
                            0
                        }
                        title="View detailed analytics"
                      >
                        {/* Update text to include shareCount */}
                        Views: {link.viewCount ?? 0} | Downloads:{" "}
                        {link.downloadCount ?? 0} | Shares:{" "}
                        {link.shareCount ?? 0}
                      </button>
                    </p>
                  </div>

                  {/* Link Actions Column: Align start on small, end on medium+ */}
                  <div className="flex flex-shrink-0 flex-col items-stretch gap-2 md:items-end">
                    {" "}
                    {/* Add flex-shrink-0 */}
                    {/* Row 1: Copy, Share & Revoke - Wrap on small screens */}
                    <div className="flex flex-wrap items-center justify-start gap-2 md:justify-end">
                      {/* Copy Link Button */}
                      <button
                        type="button"
                        // Basic styling, adjust as needed
                        className={`rounded px-3 py-1 text-xs font-medium text-white transition-colors duration-150 ${
                          copiedLinkId === link.id
                            ? "bg-green-500 hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700" // Green when copied
                            : "bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700" // Blue otherwise
                        } disabled:cursor-not-allowed disabled:opacity-50`}
                        // Add data attribute for Cypress to grab the URL - Removed to fix SSR error
                        // Disable if revoked
                        disabled={link.revoked || copiedLinkId === link.id} // Also disable briefly after copying
                        onClick={() => handleCopyLink(link.accessKey, link.id)} // Attach handler
                        title="Copy public link URL"
                      >
                        {copiedLinkId === link.id ? "Copied!" : "Copy Link"}
                      </button>
                      {/* Share Button */}
                      {!link.revoked ? (
                        <button
                          type="button"
                          onClick={() =>
                            setSharingLinkId(
                              sharingLinkId === link.id ? null : link.id,
                            )
                          } // Toggle form visibility
                          className="rounded bg-purple-500 px-3 py-1 text-xs font-medium text-white hover:bg-purple-600 dark:bg-purple-600 dark:hover:bg-purple-700 disabled:opacity-50"
                          title="Share link via email"
                        >
                          Share
                        </button>
                      ) : null}
                      {/* Revoke Form */}
                      <Form
                        method="post"
                        onSubmit={() => {
                          // Remove unused 'e' parameter
                          // Use fetcher for revoke to avoid full page reload if needed,
                          // though default Form behavior is fine too.
                          // Example using fetcher:
                          // e.preventDefault();
                          // linkActionFetcher.submit(e.currentTarget);
                        }}
                      >
                        {/* Hidden inputs to identify action and link */}
                        <input type="hidden" name="intent" value="revoke" />
                        <input type="hidden" name="linkId" value={link.id} />
                        <button
                          type="submit"
                          className="rounded bg-red-600 px-3 py-1 text-xs font-medium text-white hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-800 disabled:cursor-not-allowed disabled:opacity-50"
                          // Disable button if link is already revoked
                          disabled={link.revoked}
                        >
                          {link.revoked ? "Revoked" : "Revoke"}
                        </button>
                      </Form>
                    </div>
                    {/* Row 2: Expiry Form - Stack label/input on small, row on medium+ */}
                    {!link.revoked ? (
                      <linkActionFetcher.Form
                        // Add a key that changes when expiresAt becomes null or gets a value
                        key={`${link.id}-${link.expiresAt === null ? 'no-expiry' : 'has-expiry'}`}
                        // ref no longer needed
                        method="post"
                        className="flex flex-col items-stretch gap-1 sm:flex-row sm:items-center"
                        // Remove onChange auto-submit
                      >
                        <input
                          type="hidden"
                          name="intent"
                          value="update-expiry"
                        />
                        <input type="hidden" name="linkId" value={link.id} />
                        {/* Add hidden input for client timezone */}
                        <input type="hidden" name="clientTimezone" value={clientTimezone} />
                        <label
                          htmlFor={`expires-${link.id}`}
                          className="mb-1 whitespace-nowrap text-xs text-neutral-500 dark:text-neutral-400 sm:mb-0"
                        >
                          Set Expiry:
                        </label>{" "}
                        {/* Adjust margin */}
                        <input
                          type="datetime-local"
                          id={`expires-${link.id}`}
                          // Make input take available space
                          name="expiresAt"
                          // Format existing date for input, or empty if null
                          defaultValue={
                            link.expiresAt
                              ? formatDateTimeLocal(new Date(link.expiresAt))
                              : ""
                          }
                          className="block w-full rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 p-1 text-xs shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-xs"
                          // Add min attribute only on the client to prevent SSR issues
                          min={
                            isMounted
                              ? formatDateTimeLocal(new Date())
                              : undefined
                          }
                        />
                        {/* Add Save button */}
                        <button
                          type="submit"
                          className="rounded bg-green-500 px-2 py-1 text-xs font-medium text-white hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700"
                          title="Save expiry date"
                        >
                          Save
                        </button>
                        {/* Clear button */}
                        {link.expiresAt ? (
                          <button
                            type="submit" // Submits the form with clear action
                            name="_action" // Use specific name for the action
                            value="clearExpiry" // Value indicates the action
                            className="rounded bg-neutral-400 px-2 py-1 text-xs font-medium text-white hover:bg-neutral-500 dark:bg-neutral-600 dark:hover:bg-neutral-700"
                            title="Clear expiry date"
                          >
                            Clear
                          </button>
                        ) : null}
                      </linkActionFetcher.Form>
                    ) : null}
                    {/* Display success message for email sharing */}
                    {linkActionFetcher.state === "idle" &&
                    linkActionFetcher.data?.ok === true && // Check for explicit success
                    linkActionFetcher.data?.intent === "share-link" &&
                    linkActionFetcher.data?.linkId === link.id ? (
                      <p className="mt-1 text-xs text-green-500 dark:text-green-400">
                        Email sent successfully!
                      </p>
                    ) : null}
                    {/* Display ANY error returned by linkActionFetcher for this specific link */}
                    {linkActionFetcher.data?.ok === false && // Check for explicit failure
                    linkActionFetcher.data?.linkId === link.id &&
                    linkActionFetcher.data?.error ? (
                       <p className="mt-1 text-xs text-red-500 dark:text-red-400">
                         {linkActionFetcher.data.error}
                       </p>
                    ) : null}
                  </div>

                  {/* Email Sharing Form (Conditional) */}
                  {sharingLinkId === link.id && !link.revoked ? (
                    <linkActionFetcher.Form
                      ref={shareFormRef} // Attach the ref here
                      method="post"
                      className="mt-3 rounded-b-md border-t border-border-light dark:border-border-dark bg-neutral-50 dark:bg-neutral-800 p-3"
                      onSubmit={() => {
                        // Optionally clear form or keep it open on submit start
                        // setSharingLinkId(null); // Close form immediately
                      }}
                      onTransitionEnd={() => {
                        // Close form on successful submission after transition
                        if (
                          linkActionFetcher.state === "idle" &&
                          linkActionFetcher.data?.ok &&
                          linkActionFetcher.data?.intent === "share-link"
                        ) {
                          setSharingLinkId(null);
                        }
                      }}
                    >
                      <input type="hidden" name="intent" value="share-link" />
                      <input type="hidden" name="linkId" value={link.id} />
                      <h4 className="mb-2 text-sm font-medium text-neutral-800 dark:text-neutral-100">
                        Share via Email
                      </h4>
                      <div className="mb-2">
                        <label
                          htmlFor={`email-${link.id}`}
                          className="mb-1 block text-xs font-medium text-neutral-700 dark:text-neutral-300"
                        >
                          Recipient Email:
                        </label>
                        <input
                          type="email"
                          id={`email-${link.id}`}
                          name="recipientEmail"
                          required
                          className="block w-full rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 p-1 text-xs shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                          placeholder="recipient@example.com"
                        />
                      </div>
                      <div className="mb-2">
                        <label
                          htmlFor={`message-${link.id}`}
                          className="mb-1 block text-xs font-medium text-neutral-700 dark:text-neutral-300"
                        >
                          Optional Message:
                        </label>
                        <textarea
                          id={`message-${link.id}`}
                          name="message"
                          rows={3}
                          className="block w-full rounded-md border-border-light dark:border-border-dark bg-card-background-light dark:bg-neutral-700 p-1 text-xs shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                          placeholder="Add a personal note..."
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="submit"
                          disabled={linkActionFetcher.state !== "idle"}
                          className="rounded bg-primary-600 px-3 py-1 text-xs font-medium text-white hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 disabled:opacity-50"
                        >
                          {linkActionFetcher.state !== "idle" &&
                          linkActionFetcher.formData?.get("intent") ===
                            "share-link" &&
                          linkActionFetcher.formData?.get("linkId") === link.id
                            ? "Sending..."
                            : "Send Email"}
                        </button>
                        <button
                          type="button"
                          onClick={() => setSharingLinkId(null)}
                          className="rounded bg-neutral-400 px-3 py-1 text-xs font-medium text-white hover:bg-neutral-500 dark:bg-neutral-600 dark:hover:bg-neutral-700"
                        >
                          Cancel
                        </button>
                      </div>
                      {/* Error display moved outside the form, handled by the general check above */}
                    </linkActionFetcher.Form>
                  ) : null}
                </li>
                ); // End return for map callback
              })}
            </ul>
          )}
        </div>

        {/* TODO: Add analytics overview here */}
      </div>

      {/* --- Analytics Modal --- */}
      {viewingAnalyticsFor ? (
        <AnalyticsModal
          linkName={viewingAnalyticsFor.name}
          fetcher={analyticsFetcher}
          currentPage={analyticsPage}
          onClose={() => setViewingAnalyticsFor(null)}
          onPageChange={setAnalyticsPage}
        />
      ) : null}
      {/* --- End Analytics Modal --- */}

      {/* --- Link Limit Modal --- */}
      {isLinkLimitModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="relative w-full max-w-md rounded-lg bg-card-background-light dark:bg-card-background-dark p-6 shadow-xl">
            <div className="mb-4 flex items-start justify-between">
              <h3 className="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
                Link Limit Reached
              </h3>
              <button
                type="button"
                className="ml-auto inline-flex items-center rounded-lg bg-transparent p-1.5 text-sm text-neutral-400 dark:text-neutral-500 hover:bg-neutral-200 dark:hover:bg-neutral-700 hover:text-neutral-900 dark:hover:text-neutral-100"
                onClick={() => setIsLinkLimitModalOpen(false)}
                aria-label="Close modal"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  ></path>
                </svg>
              </button>
            </div>

            <div className="mb-6">
              <div className="mb-4 flex justify-center">
                <div className="rounded-full bg-yellow-100 dark:bg-yellow-900 p-3">
                  <svg
                    className="h-10 w-10 text-yellow-600 dark:text-yellow-400"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    />
                  </svg>
                </div>
              </div>

              <p className="mb-4 text-center text-neutral-700 dark:text-neutral-300">
                You've reached the maximum of {linkLimit} active links on
                the Free plan.
              </p>

              <p className="mb-6 text-center text-neutral-600 dark:text-neutral-400">
                To create more links, either revoke some existing links or
                upgrade to Pro for unlimited links.
              </p>

              <div className="flex flex-col gap-3">
                <Form method="post">
                  <input
                    type="hidden"
                    name="intent"
                    value="create-checkout-session"
                  />
                  <button
                    type="submit"
                    className="w-full rounded-md bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
                  >
                    Upgrade to Pro ($15/month)
                  </button>
                </Form>

                <button
                  type="button"
                  onClick={() => setIsLinkLimitModalOpen(false)}
                  className="w-full rounded-md bg-neutral-200 dark:bg-neutral-700 px-4 py-2 text-sm font-medium text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 focus:outline-none focus:ring-2 focus:ring-neutral-400 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
                >
                  Manage Existing Links
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
      {/* --- End Link Limit Modal --- */}
    </div>
  );
}

// --- Analytics Modal Component ---
const ANALYTICS_PAGE_SIZE = 20; // Define page size consistently

interface AnalyticsModalProps {
  // Use interface instead of type
  linkName: string;
  fetcher: ReturnType<
    typeof useFetcher<SerializeFrom<GetAnalyticsEventsResult>>
  >;
  currentPage: number;
  onClose: () => void;
  onPageChange: (newPage: number) => void;
}

function AnalyticsModal({
  linkName,
  fetcher,
  currentPage,
  onClose,
  onPageChange,
}: AnalyticsModalProps) {
  // Get the user data from the loader to check the plan
  const { user } = useLoaderData<SerializeFrom<typeof loader>>();
  const isPro = user.plan === "PRO";

  const analyticsData = fetcher.data;
  const isLoading = fetcher.state === "loading";

  const totalCount = analyticsData?.totalCount ?? 0;
  const totalPages = Math.ceil(totalCount / ANALYTICS_PAGE_SIZE);

  // Function to handle the upgrade button click
  const submit = useSubmit();
  const handleUpgradeClick = () => {
    const form = document.createElement("form");
    form.method = "post";
    form.action = "/dashboard";

    const intentInput = document.createElement("input");
    intentInput.type = "hidden";
    intentInput.name = "intent";
    intentInput.value = "create-checkout-session";

    form.appendChild(intentInput);
    submit(form);
  };

  return (
    // Modal backdrop
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
      {/* Modal container */}
      <div className="relative w-full max-w-2xl rounded-lg bg-card-background-light dark:bg-card-background-dark p-6 shadow-xl">
        {/* Modal header */}
        <div className="mb-4 flex items-start justify-between border-b border-border-light dark:border-border-dark pb-3">
          {/* Add truncate and overflow-hidden to the h3 */}
          <h3 className="truncate overflow-hidden text-xl font-semibold text-neutral-900 dark:text-neutral-100">
            Analytics for: <span className="font-normal">{linkName}</span>
          </h3>
          <button
            type="button"
            className="ml-auto inline-flex items-center rounded-lg bg-transparent p-1.5 text-sm text-neutral-400 dark:text-neutral-500 hover:bg-neutral-200 dark:hover:bg-neutral-700 hover:text-neutral-900 dark:hover:text-neutral-100"
            onClick={onClose}
            aria-label="Close modal"
          >
            {/* Close icon (Heroicons XMark) */}
            <svg
              className="h-5 w-5"
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                clipRule="evenodd"
              ></path>
            </svg>
          </button>
        </div>

        {/* Modal body - Table for Pro users or Upgrade Message for Free users */}
        {!isPro ? (
          // Pro Upgrade Message for Free users - No scrolling needed
          <div className="px-4 py-8 text-center">
            <div className="mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900 p-2">
              <svg
                className="h-8 w-8 text-primary-600 dark:text-primary-400"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <h3 className="mb-1 text-lg font-bold text-neutral-900 dark:text-neutral-100">
              Detailed Analytics
            </h3>
            <p className="mb-4 text-sm text-neutral-600 dark:text-neutral-300">
              See who viewed your links and when! Upgrade to Pro for detailed
              analytics and unlimited links.
            </p>
            <button
              type="button"
              onClick={handleUpgradeClick}
              className="rounded-md bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-neutral-800"
            >
              Upgrade to Pro ($15/month)
            </button>
          </div>
        ) : (
          // Table for Pro users - Scrollable content
          <div className="max-h-[60vh] overflow-y-auto">
            {/* Regular analytics content (visible for Pro users, behind overlay for Free users) */}
            {isLoading ? (
              <p className="text-center text-neutral-500 dark:text-neutral-400">Loading...</p>
            ) : null}
            {!isLoading && !analyticsData?.events?.length ? (
              <p className="text-center text-neutral-500 dark:text-neutral-400">
                No analytics events found for this link.
              </p>
            ) : null}
            {!isLoading && analyticsData?.events?.length ? (
              <table className="min-w-full divide-y divide-border-light dark:divide-border-dark">
                <thead className="bg-neutral-50 dark:bg-neutral-800">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500 dark:text-neutral-400"
                    >
                      Event Type
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500 dark:text-neutral-400"
                    >
                      Timestamp
                    </th>
                    {/* Add Details column */}
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-neutral-500 dark:text-neutral-400"
                    >
                      Details
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-light dark:divide-border-dark bg-card-background-light dark:bg-card-background-dark">
                  {analyticsData.events.map((event) => (
                    <tr key={event.id}>
                      <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-neutral-900 dark:text-neutral-100">
                        {/* Add badge styling for event type */}
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            event.type === "VIEW" // Use event.type
                              ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                              : event.type === "DOWNLOAD" // Use event.type
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                : event.type === "SHARE" // Use event.type
                                  ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
                                  : "bg-neutral-100 text-neutral-800 dark:bg-neutral-700 dark:text-neutral-200" // Default/fallback
                          }`}
                        >
                          {event.type} {/* Use event.type */}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500 dark:text-neutral-400">
                        <LocalTime iso={event.createdAt} /> {/* Use LocalTime here */}
                      </td>
                      {/* Add Details cell */}
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-neutral-500 dark:text-neutral-400">
                        {event.type === "SHARE" && event.recipientEmail ? ( // Use event.type
                          <span>Shared with: {event.recipientEmail}</span>
                        ) : (
                          <span className="text-neutral-400 dark:text-neutral-500">-</span> // Placeholder for non-share events
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : null}
          </div>
        )}

        {/* Modal footer - Pagination (only visible for Pro users) */}
        {isPro && !isLoading && totalPages > 1 ? (
          <div className="mt-4 flex items-center justify-between border-t border-border-light dark:border-border-dark pt-4">
            <button
              type="button"
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage <= 1}
              className="rounded bg-neutral-200 dark:bg-neutral-700 px-4 py-2 text-sm font-medium text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Previous
            </button>
            <span className="text-sm text-neutral-600 dark:text-neutral-400">
              Page {currentPage} of {totalPages} (Total: {totalCount} events)
            </span>
            <button
              type="button"
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className="rounded bg-neutral-200 dark:bg-neutral-700 px-4 py-2 text-sm font-medium text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Next
            </button>
          </div>
        ) : null}
        {/* Close button in footer */}
        <div
          className={`mt-4 flex justify-end ${isPro && totalPages <= 1 ? "border-t border-border-light dark:border-border-dark pt-4" : ""}`}
        >
          <button
            type="button"
            className="rounded bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
// --- End Analytics Modal Component ---
