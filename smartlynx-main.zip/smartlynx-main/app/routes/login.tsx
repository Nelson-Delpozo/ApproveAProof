import { randomBytes } from "node:crypto"; // Import for state generation

import { redirect, type LoaderFunctionArgs } from "@remix-run/node";
import invariant from "tiny-invariant";

import { sessionStorage } from "~/session.server"; // Correct import

// This route doesn't render anything itself, it just initiates the login flow.
// Loader function: Handles GET requests to /login
export async function loader({ request }: LoaderFunctionArgs) {
  invariant(process.env.AUTH0_DOMAIN, "AUTH0_DOMAIN must be set");
  invariant(process.env.AUTH0_CLIENT_ID, "AUTH0_CLIENT_ID must be set");
  invariant(process.env.AUTH0_CALLBACK_URL, "AUTH0_CALLBACK_URL must be set");

  // Get session to store state
  const session = await sessionStorage.getSession(request.headers.get("Cookie")); // Correct usage

  // Generate random state for CSRF protection
  const state = randomBytes(32).toString("hex");
  session.flash("oauth2_state", state); // Store state in flash session

  // Manually construct the Auth0 authorization URL
  const params = new URLSearchParams({
    client_id: process.env.AUTH0_CLIENT_ID,
    redirect_uri: process.env.AUTH0_CALLBACK_URL,
    response_type: "code", // Using Authorization Code Flow
    scope: "openid profile email", // Request basic user info + email
    state: state, // Add generated state to parameters
  });

  const authorizeUrl = `https://${process.env.AUTH0_DOMAIN}/authorize?${params.toString()}`;

  // Redirect the user to the constructed Auth0 Universal Login URL, committing the session with the state
  return redirect(authorizeUrl, {
    status: 302,
    headers: {
      "Set-Cookie": await sessionStorage.commitSession(session), // Correct usage
    },
  });
}

// Action function: Handles POST requests (optional, usually login is GET)
// If you had a login form submitting here, you'd trigger the redirect similarly.
// For now, we primarily rely on the loader for direct access to /login.
export async function action(args: LoaderFunctionArgs) { // Use full args
  // In case someone POSTs here, redirect same as GET
  // Call loader directly, passing the full args object
  return loader(args); // Pass full args
}

// No default export needed as this route only performs redirects.
