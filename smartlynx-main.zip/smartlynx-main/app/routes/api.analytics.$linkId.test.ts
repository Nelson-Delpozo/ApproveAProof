// Import types first
import type { LoaderFunctionArgs } from '@remix-run/node';
// Then testing utilities
import { vi, describe, it, expect, beforeEach } from 'vitest';

// Mock dependencies
vi.mock('~/auth.server', () => ({
  getAuthSession: vi.fn(), // Mock getAuthSession instead
}));
vi.mock('~/models/analytics.server', () => ({
  getAnalyticsEventsForLink: vi.fn(),
}));

// Import the route module *after* mocks
import { getAuthSession } from '~/auth.server'; // Import the correct function
import { getAnalyticsEventsForLink } from '~/models/analytics.server';

import { loader } from './api.analytics.$linkId'; // Import loader last

describe('API Analytics Route Loader', () => {
  const mockUserId = 'test-user-id';
  const mockLinkId = 'test-link-id';
  const mockRequest = new Request(`http://localhost/api/analytics/${mockLinkId}?page=1`);

  beforeEach(() => {
    vi.resetAllMocks(); // Reset mocks before each test

    // Default mock implementations
    vi.mocked(getAuthSession).mockResolvedValue({ id: mockUserId, email: 'test@example.com', auth0Sub: 'auth0|123' }); // Mock logged-in user
    vi.mocked(getAnalyticsEventsForLink).mockResolvedValue({ events: [], totalCount: 0 }); // Default success
  });

  it('should throw 401 if user is not authenticated', async () => {
    vi.mocked(getAuthSession).mockResolvedValue(null); // Mock logged-out user

    try {
      await loader({ request: mockRequest, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
      expect.fail('Loader should have thrown an error for unauthenticated user');
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      const typedResponse = response as Response;
      expect(typedResponse.status).toBe(401);
      expect(await typedResponse.text()).toBe('Unauthorized');
    }
    expect(getAuthSession).toHaveBeenCalledWith(mockRequest);
  });

  it('should return 400 if linkId is missing', async () => {
    try {
      await loader({ request: mockRequest, params: {}, context: {} } as LoaderFunctionArgs); // Missing linkId
      expect.fail('Loader should have thrown an error for missing linkId');
    } catch (error) {
       // Remix loaders throw the actual error/Response, not return it when invariant fails
       expect(error).toBeInstanceOf(Error);
       expect((error as Error).message).toContain('Missing linkId parameter');
    }
  });


  it('should call getAnalyticsEventsForLink with correct parameters', async () => {
    const page = 2;
    const requestWithPage = new Request(`http://localhost/api/analytics/${mockLinkId}?page=${page}`);
    await loader({ request: requestWithPage, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);

    expect(getAnalyticsEventsForLink).toHaveBeenCalledWith(mockUserId, mockLinkId, page, 20); // Default pageSize is 20
  });

   it('should use default page number 1 if not provided', async () => {
     await loader({ request: mockRequest, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs); // No page query param
     expect(getAnalyticsEventsForLink).toHaveBeenCalledWith(mockUserId, mockLinkId, 1, 20); // Check default page 1
   });

  it('should return analytics data on success', async () => {
    const mockData = {
      // Use the updated structure from GetAnalyticsEventsResult
      events: [{ id: 'evt1', type: 'VIEW', createdAt: new Date(), recipientEmail: null }],
      totalCount: 1,
    };
    // Need to cast the mock data slightly because the mock function expects the full return type
    vi.mocked(getAnalyticsEventsForLink).mockResolvedValue(mockData as Awaited<ReturnType<typeof getAnalyticsEventsForLink>>);

    const response = await loader({ request: mockRequest, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
    expect(response.status).toBe(200);
    const responseData = await response.json(); // Use json() helper from Remix
    // Dates need careful comparison - often best to check structure/types
    expect(responseData.events).toHaveLength(1);
    expect(responseData.totalCount).toBe(1);
    expect(responseData.events[0].id).toBe('evt1');
  });

  it('should throw 404 if getAnalyticsEventsForLink returns null (link not found or unauthorized)', async () => {
    vi.mocked(getAnalyticsEventsForLink).mockResolvedValue(null);

    try {
      await loader({ request: mockRequest, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
      expect.fail('Loader should have thrown an error for not found data');
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      const typedResponse = response as Response;
      expect(typedResponse.status).toBe(404);
      expect(await typedResponse.text()).toBe('Analytics data not found or forbidden');
    }
  });


  it('should throw 500 on unexpected errors from getAnalyticsEventsForLink', async () => {
    const testError = new Error('Something went wrong');
    vi.mocked(getAnalyticsEventsForLink).mockRejectedValue(testError);

    // Use try-catch to assert the thrown Response
    try {
       await loader({ request: mockRequest, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
       // If it doesn't throw, fail the test
       expect(true).toBe(false);
    } catch (response) {
       // Loaders should throw errors, not return them directly in this case
       expect(response).toBeInstanceOf(Error);
       expect(response).toEqual(testError); // Should re-throw the original error
    }
  });

  // Add tests for invalid page/pageSize parameters
  it('should throw 400 for invalid page number', async () => {
    const requestWithInvalidPage = new Request(`http://localhost/api/analytics/${mockLinkId}?page=invalid`);
    try {
      await loader({ request: requestWithInvalidPage, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
      expect.fail('Loader should have thrown an error for invalid page');
    } catch (response) {
      expect(response).toBeInstanceOf(Response);
      const typedResponse = response as Response;
      expect(typedResponse.status).toBe(400);
      expect(await typedResponse.text()).toBe('Invalid page number');
    }
  });

  it('should throw 400 for invalid page size', async () => {
     const requestWithInvalidPageSize = new Request(`http://localhost/api/analytics/${mockLinkId}?pageSize=0`);
     try {
       await loader({ request: requestWithInvalidPageSize, params: { linkId: mockLinkId }, context: {} } as LoaderFunctionArgs);
       expect.fail('Loader should have thrown an error for invalid page size');
     } catch (response) {
       expect(response).toBeInstanceOf(Response);
       const typedResponse = response as Response;
       expect(typedResponse.status).toBe(400);
       expect(await typedResponse.text()).toBe('Invalid page size');
     }
   });
});
