import type { LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import { jwtDecode } from "jwt-decode"; // Import jwt-decode
import invariant from "tiny-invariant";

import {
  getAuth0AuthenticationClient, // Import the getter function
  findOrCreateUserByAuthProfile,
  setAuthSession,
} from "~/auth.server";
import { sessionStorage } from "~/session.server"; // Import sessionStorage

// This route handles the redirect back from Auth0 after authentication.
export async function loader({ request }: LoaderFunctionArgs) {
  invariant(process.env.AUTH0_CALLBACK_URL, "AUTH0_CALLBACK_URL must be set");

  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state"); // Get state from URL

  // Get session to retrieve stored state
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));
  const sessionState = session.get("oauth2_state"); // Get state stored in flash session (and remove it)

  if (!code) {
    // Handle error case - no code received
    console.error("Auth0 callback error: No authorization code received.");
    // Redirect to an error page or login page with an error message
    return redirect("/login?error=callback_failed");
  }

  // Validate state for CSRF protection
  if (!state || !sessionState || state !== sessionState) {
    console.error(
      `Auth0 callback state mismatch: URL state='${state}', Session state='${sessionState}'`
    );
    // State mismatch or missing - potential CSRF attack or expired session state
    // Redirect to login with an error. Commit session to clear the invalid state if it existed.
    return redirect("/login?error=invalid_state", {
      headers: {
        "Set-Cookie": await sessionStorage.commitSession(session), // Commit session to clear flash
      },
    });
  }

  // State is valid, proceed with code exchange
  try {
    // Get the Auth0 client instance
    const authClient = getAuth0AuthenticationClient();

    // Exchange the authorization code for tokens
    const tokenResponse = await authClient.oauth.authorizationCodeGrant({ // Use the obtained client instance
      code: code,
      redirect_uri: process.env.AUTH0_CALLBACK_URL,
      // client_id and client_secret are implicitly used from the client initialization
    });

    if (!tokenResponse.data.id_token) {
       throw new Error("ID token missing from Auth0 response.");
    }

    // Decode the ID token to get user profile information
    // Define expected structure of the decoded ID token payload
    interface DecodedIdToken {
      sub: string; // Subject (Auth0 User ID)
      email?: string; // Email (may not always be present depending on scope/config)
      email_verified?: boolean;
      name?: string;
      picture?: string;
      // Add other claims as needed (e.g., nickname, given_name, family_name)
      [key: string]: unknown; // Allow other claims
    }

    const decodedToken = jwtDecode<DecodedIdToken>(tokenResponse.data.id_token);

    // Validate required claims from the decoded token
    if (!decodedToken.sub || !decodedToken.email) {
       console.error("Decoded ID token:", decodedToken);
       throw new Error("Decoded ID token is missing required fields (sub or email).");
    }

    const auth0Sub = decodedToken.sub;
    const email = decodedToken.email;

    // Find or create the user in our local database
    const user = await findOrCreateUserByAuthProfile(email, auth0Sub);

    if (!user) {
      throw new Error("Failed to find or create user in the database during callback.");
    }

    // Create a session for the user in our application
    // setAuthSession gets the session internally based on the request.
    const userSession = await setAuthSession(request, user); // Correct: Call with only request and user

    // Redirect the user to the dashboard after successful login/signup
    // TODO: Implement logic to redirect to original intended URL if stored (e.g., in state or session)
    return redirect("/dashboard", {
      headers: {
        "Set-Cookie": await sessionStorage.commitSession(userSession), // Commit the session returned by setAuthSession
      },
    });

  } catch (error) {
    console.error("Auth0 callback processing failed:", error);
    // Redirect to login with an error message
    // Consider logging the error more robustly
    let errorMessage = "authentication_failed";
    if (error instanceof Error) {
        errorMessage = error.message; // Be cautious about exposing internal errors
    }
     // Basic error handling, redirect back to login
    return redirect(`/login?error=${encodeURIComponent(errorMessage)}`);
  }
}

// No default export or action needed for this callback route.
