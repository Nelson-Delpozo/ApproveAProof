import { redirect } from "@remix-run/node"; // Keep redirect, remove unused json
import { describe, it, expect, vi, beforeEach, type Mock } from "vitest"; // Import Mock type

import { getAuthSession } from "~/auth.server"; // Import the function to mock
import { prisma } from "~/db.server"; // Import the mocked prisma instance
import { sendEmail } from "~/email.server"; // Import the function to mock
import { getAnalyticsEventCountsForLink } from "~/models/analytics.server"; // Import the function to mock
import type { User } from "~/models/user.server"; // + Import User type

// Mock the analytics.server module
vi.mock("~/models/analytics.server");
const mockedGetAnalyticsEventCountsForLink = vi.mocked(getAnalyticsEventCountsForLink);

import { loader, action } from "./dashboard"; // Import loader and action

// Mock the auth.server module
vi.mock("~/auth.server"); // Mock before importing the module that uses it
const mockedGetAuthSession = vi.mocked(getAuthSession);

// Mock the email.server module
vi.mock("~/email.server");
const mockedSendEmail = vi.mocked(sendEmail);

// Mock the stripe.server module
vi.mock("~/stripe.server", () => ({
  stripe: {
    customers: { create: vi.fn() },
    checkout: { sessions: { create: vi.fn() } },
    billingPortal: { sessions: { create: vi.fn() } },
    // Add other Stripe methods used by the action if any
    subscriptions: { retrieve: vi.fn() }, 
  },
}));
// Import after mocking
import { stripe } from "~/stripe.server"; 

// Mock user data - Ensure it matches the expected User type from Prisma/auth.server
const mockUser: User = {
  id: "user-123",
  email: "test@example.com",
  createdAt: new Date(),
  updatedAt: new Date(),
  auth0Sub: "auth0|someid123",
  stripeCustomerId: null,
  stripeSubscriptionId: null,
  stripeSubscriptionStatus: null,
  plan: "FREE",
  brandingLogoUrl: null,
  brandingColorPrimary: null,
  brandingColorText: null,
};

// Mock link data (use ISO strings for dates)
const date1 = new Date();
const date2 = new Date(date1.getTime() - 10000); // Slightly different date

const mockLinks = [
  {
    id: "link-abc",
    userId: mockUser.id,
    originalFileName: "file1.txt",
    storageKey: "key1",
    accessKey: "abc",
    createdAt: date1, // Use Date object here
    updatedAt: date1, // Use Date object here
    fileType: "text/plain",
    fileSizeBytes: 100,
    description: "Test file 1",
    expiresAt: null,
    revoked: false,
  },
  {
    id: "link-def",
    userId: mockUser.id,
    originalFileName: "file2.jpg",
    storageKey: "key2",
    accessKey: "def",
    createdAt: date2, // Use Date object here
    updatedAt: date2, // Use Date object here
    fileType: "image/jpeg",
    fileSizeBytes: 2000,
    description: null,
    expiresAt: null,
    revoked: true,
  },
];

// Expected JSON representation of links (dates as ISO strings)
const expectedJsonLinks = mockLinks.map(link => ({
  ...link,
  createdAt: link.createdAt.toISOString(),
  updatedAt: link.updatedAt.toISOString(),
}));

// Expected JSON representation of user (dates as ISO strings)
const expectedJsonUser = {
    ...mockUser,
    createdAt: mockUser.createdAt.toISOString(),
    updatedAt: mockUser.updatedAt.toISOString(),
    // Ensure all fields from mockUser (now a full User) are here if needed for assertions
    // For example, if branding fields were asserted, they'd be null here.
    // Current tests only assert data.user which is the fullUser from loader,
    // so this expectedJsonUser should match that structure.
    // The loader selects: id, email, auth0Sub, plan, stripeSubscriptionStatus, branding fields.
    // So, expectedJsonUser should reflect these fields from mockUser.
    plan: mockUser.plan,
    stripeSubscriptionStatus: mockUser.stripeSubscriptionStatus,
    brandingLogoUrl: mockUser.brandingLogoUrl,
    brandingColorPrimary: mockUser.brandingColorPrimary,
    brandingColorText: mockUser.brandingColorText,
    // stripeCustomerId and stripeSubscriptionId are not in the loader's user select, so not needed here.
};


describe("Dashboard Route", () => {
  beforeEach(() => {
    // Reset mocks before each test
    vi.resetAllMocks();
  });

  describe("loader", () => {
    it("should redirect to /login if user is not authenticated", async () => {
      // Arrange
      mockedGetAuthSession.mockResolvedValue(null); // Simulate logged out
      const request = new Request("http://localhost/dashboard");
      const expectedRedirect = redirect("/login?redirectTo=%2Fdashboard");

      // Act
      const response = await loader({ request, params: {}, context: {} });

      // Assert
      // Check status, location header, and potentially the body/type if needed
      expect(response.status).toBe(expectedRedirect.status);
      expect(response.headers.get("Location")).toBe(expectedRedirect.headers.get("Location"));
    });

    it("should return user and links if user is authenticated", async () => {
      // Arrange
      mockedGetAuthSession.mockResolvedValue(mockUser); // Simulate logged in
      // Mock prisma response for findMany
      (prisma.sharedLink.findMany as Mock).mockResolvedValue(mockLinks.filter(l => !l.revoked)); // Default filter is active
      // Mock prisma.user.findUnique to return the user
      (prisma.user.findUnique as Mock).mockResolvedValue(mockUser);
      // Mock prisma.sharedLink.count for activeLinksCount
      (prisma.sharedLink.count as Mock).mockResolvedValue(mockLinks.filter(l => !l.revoked).length); // Count of non-revoked links
      const request = new Request("http://localhost/dashboard");

      // Act
      const response = await loader({ request, params: {}, context: {} });
      const data = await response.json(); // This performs JSON.parse

      // Assert
       expect(response.status).toBe(200);
       // Compare against the expected JSON structure with ISO date strings
       expect(data.user).toEqual(expectedJsonUser);

       // Mock the getAnalyticsEventCountsForLink function instead of direct count calls
       // This is now used by the dashboard loader
       const mockAnalyticsCounts = {
         'link-abc': { viewCount: 5, downloadCount: 2, shareCount: 1 },
         'link-def': { viewCount: 10, downloadCount: 0, shareCount: 0 }
       };
       
       // Mock the function to return the appropriate counts based on linkId
       mockedGetAnalyticsEventCountsForLink.mockImplementation(async (linkId: string) => {
         return mockAnalyticsCounts[linkId as keyof typeof mockAnalyticsCounts] || 
                { viewCount: 0, downloadCount: 0, shareCount: 0 };
       });

       // Re-run loader with the count mock implementation in place
       const responseWithCounts = await loader({ request, params: {}, context: {} });
       const dataWithCounts = await responseWithCounts.json();

       // Assert counts are included
       // Filter expectedJsonLinks to only include non-revoked ones for this default test case
       const activeJsonLinks = expectedJsonLinks.filter(link => !link.revoked);
       const expectedLinksWithCounts = activeJsonLinks.map((link) => ({
         ...link,
         // Adjust count expectations based on which links are active
         viewCount: link.id === 'link-abc' ? 5 : 0, 
         downloadCount: link.id === 'link-abc' ? 2 : 0,
         shareCount: link.id === 'link-abc' ? 1 : 0,
       }));
       expect(dataWithCounts.links).toEqual(expectedLinksWithCounts);
       // Assert activeLinksCount and linkLimit for FREE user
       expect(dataWithCounts.activeLinksCount).toBe(mockLinks.filter(l => !l.revoked).length);
       expect(dataWithCounts.linkLimit).toBe(5);

       expect(prisma.sharedLink.findMany).toHaveBeenCalledWith({
         where: { userId: mockUser.id, revoked: false }, // Check for revoked: false
         orderBy: { createdAt: "desc" },
         // Ensure include is NOT used here as we fetch counts separately
         include: undefined, // Or check it's not present
      });
      expect(prisma.sharedLink.count).toHaveBeenCalledWith({
        where: { userId: mockUser.id, revoked: false },
      });
    });

     it("should return user and empty links array if user has no links", async () => {
      // Arrange
      mockedGetAuthSession.mockResolvedValue(mockUser);
      (prisma.sharedLink.findMany as Mock).mockResolvedValue([]); // No links found
      // Mock prisma.user.findUnique to return the user
      (prisma.user.findUnique as Mock).mockResolvedValue(mockUser);
      // Mock prisma.sharedLink.count for activeLinksCount (will be 0)
      (prisma.sharedLink.count as Mock).mockResolvedValue(0);
      const request = new Request("http://localhost/dashboard");

      // Act
      // No need to mock getAnalyticsEventCountsForLink if links array is empty
      const response = await loader({ request, params: {}, context: {} });
      const data = await response.json();

      // Assert
      expect(response.status).toBe(200);
      expect(data.user).toEqual(expectedJsonUser); // Compare against JSON user
      expect(data.links).toEqual([]); // Empty array is fine
      expect(data.activeLinksCount).toBe(0); // Should be 0
      expect(data.linkLimit).toBe(5); // Still 5 for FREE user
      expect(prisma.sharedLink.findMany).toHaveBeenCalledWith({
        where: { userId: mockUser.id, revoked: false }, // Check for revoked: false
        orderBy: { createdAt: "desc" },
      });
    });

    it("should return user and revoked links if filter=revoked is applied", async () => {
      // Arrange
      const revokedLinks = mockLinks.filter(link => link.revoked);
      const expectedJsonRevokedLinks = revokedLinks.map(link => ({
        ...link,
        createdAt: link.createdAt.toISOString(),
        updatedAt: link.updatedAt.toISOString(),
      }));

      mockedGetAuthSession.mockResolvedValue(mockUser);
      (prisma.sharedLink.findMany as Mock).mockResolvedValue(revokedLinks);
      (prisma.user.findUnique as Mock).mockResolvedValue(mockUser);
      
      // Mock analytics counts for these revoked links
      const mockAnalyticsCountsRevoked = {
         'link-def': { viewCount: 10, downloadCount: 0, shareCount: 0 }
       };
      mockedGetAnalyticsEventCountsForLink.mockImplementation(async (linkId: string) => {
        return mockAnalyticsCountsRevoked[linkId as keyof typeof mockAnalyticsCountsRevoked] || 
               { viewCount: 0, downloadCount: 0, shareCount: 0 };
      });

      const request = new Request("http://localhost/dashboard?filter=revoked");

      // Act
      const response = await loader({ request, params: {}, context: {} });
      const data = await response.json();

      // Assert
      expect(response.status).toBe(200);
      expect(data.user).toEqual(expectedJsonUser);
      
      const expectedLinksWithCounts = expectedJsonRevokedLinks.map(link => ({
        ...link,
        // Assuming only link-def is revoked and has these counts in this test setup
        viewCount: link.id === 'link-def' ? 10 : 0, 
        downloadCount: 0,
        shareCount: 0,
      }));
      expect(data.links).toEqual(expectedLinksWithCounts);
      expect(data.currentFilter).toBe("revoked");

      expect(prisma.sharedLink.findMany).toHaveBeenCalledWith({
        where: { userId: mockUser.id, revoked: true }, // Check for revoked: true
        orderBy: { createdAt: "desc" },
      });
    });
  });

  describe("action", () => {
    it("should throw 401 if user is not authenticated", async () => {
       // Arrange
       mockedGetAuthSession.mockResolvedValue(null); // Simulate logged out
       const formData = new FormData();
       formData.append("intent", "revoke");
       formData.append("linkId", "link-abc");
       const request = new Request("http://localhost/dashboard", {
         method: "POST",
         body: formData, // FormData should work directly
       });

       // Act & Assert
       // Actions throw Responses, so catch and check
       try {
         await action({ request, params: {}, context: {} });
         // If it doesn't throw, fail the test
         expect.fail("Action should have thrown an error");
       } catch (errorResponse) {
         expect(errorResponse).toBeInstanceOf(Response);
         const response = errorResponse as Response;
         expect(response.status).toBe(401);
         expect(await response.text()).toBe("Unauthorized");
       }
    });

    it("should throw 400 if intent is invalid", async () => {
      // Arrange
      mockedGetAuthSession.mockResolvedValue(mockUser);
      const formData = new FormData();
      formData.append("intent", "delete"); // Invalid intent
      formData.append("linkId", "link-abc");
      const request = new Request("http://localhost/dashboard", {
        method: "POST",
        body: formData,
      });

      // Act & Assert
      try {
        await action({ request, params: {}, context: {} });
        expect.fail("Action should have thrown an error");
      } catch (errorResponse) {
        expect(errorResponse).toBeInstanceOf(Response);
        const response = errorResponse as Response;
        expect(response.status).toBe(400);
        expect(await response.text()).toBe("Invalid intent: delete");
      }
    });

     it("should throw if linkId is missing", async () => {
      // Arrange
      mockedGetAuthSession.mockResolvedValue(mockUser);
      const formData = new FormData();
      formData.append("intent", "revoke");
      // Missing linkId
      const request = new Request("http://localhost/dashboard", {
        method: "POST",
        body: formData,
      });

      // Act & Assert
      // invariant throws an Error, not a Response, so use rejects.toThrow
      await expect(action({ request, params: {}, context: {} })).rejects.toThrow(
        "Missing linkId"
      );
    });

    describe("revoke intent", () => {
      it("should throw 404 if link to revoke is not found", async () => {
        // Arrange
        mockedGetAuthSession.mockResolvedValue(mockUser);
        (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null); // Link not found
        const formData = new FormData();
        formData.append("intent", "revoke");
        formData.append("linkId", "link-not-found");
        const request = new Request("http://localhost/dashboard", {
          method: "POST",
          body: formData,
        });

        // Act & Assert
        try {
          await action({ request, params: {}, context: {} });
          expect.fail("Action should have thrown an error");
        } catch (errorResponse) {
          expect(errorResponse).toBeInstanceOf(Response);
          const response = errorResponse as Response;
          expect(response.status).toBe(404);
          expect(await response.text()).toBe("Link not found");
        }
        expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
          where: { id: "link-not-found" },
          select: { userId: true },
        });
      });

      it("should throw 403 if link does not belong to the user", async () => {
        // Arrange
        mockedGetAuthSession.mockResolvedValue(mockUser);
        // Link belongs to another user
        (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: "other-user-id" });
        const formData = new FormData();
        formData.append("intent", "revoke");
        formData.append("linkId", "link-other-user");
        const request = new Request("http://localhost/dashboard", {
          method: "POST",
          body: formData,
        });

        // Act & Assert
        try {
          await action({ request, params: {}, context: {} });
          expect.fail("Action should have thrown an error");
        } catch (errorResponse) {
          expect(errorResponse).toBeInstanceOf(Response);
          const response = errorResponse as Response;
          expect(response.status).toBe(403);
          expect(await response.text()).toBe("Forbidden: You do not own this link");
        }
         expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
          where: { id: "link-other-user" },
          select: { userId: true },
        });
      });

      it("should revoke the link and return ok if successful", async () => {
        // Arrange
        mockedGetAuthSession.mockResolvedValue(mockUser);
        // Link belongs to the current user
        (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
        // Mock the update call
        (prisma.sharedLink.update as Mock).mockResolvedValue({ ...mockLinks[0], revoked: true });
        const formData = new FormData();
        formData.append("intent", "revoke");
        formData.append("linkId", "link-abc");
        const request = new Request("http://localhost/dashboard", {
          method: "POST",
          body: formData,
        });

        // Act
        const response = await action({ request, params: {}, context: {} });

        // Assert
        expect(response).toBeInstanceOf(Response); // Should return a Response
        expect(response.status).toBe(200);
        expect(await response.json()).toEqual({ ok: true, intent: "revoke" }); // Check JSON body

        expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
          where: { id: "link-abc" },
          select: { userId: true },
        });
        expect(prisma.sharedLink.update).toHaveBeenCalledWith({
          where: { id: "link-abc" },
          data: { revoked: true },
        });
      });
    });

    // --- Tests for create-link-record intent ---
    describe("create-link-record intent", () => {
      const createFormData = () => {
        const formData = new FormData();
        formData.append("intent", "create-link-record");
        formData.append("s3Key", "user-uploads/user-123/uuid-test.txt");
        formData.append("originalFilename", "test.txt");
        formData.append("contentType", "text/plain");
        formData.append("fileSize", "1234");
        // Need linkId for invariant check at start of action, even if not used by this intent
        formData.append("linkId", "dummy-id-for-invariant");
        return formData;
      };

      it("should create a link record and return ok if successful", async () => {
        // Arrange
        mockedGetAuthSession.mockResolvedValue(mockUser);
        // Mock successful creation
        (prisma.sharedLink.create as Mock).mockResolvedValue({ ...mockLinks[0] }); // Return a mock link
        const formData = createFormData();
        const request = new Request("http://localhost/dashboard", {
          method: "POST",
          body: formData
        });

        // Act
        const response = await action({ request, params: {}, context: {} });

        // Assert
        expect(response).toBeInstanceOf(Response);
        expect(response.status).toBe(200);
        expect(await response.json()).toEqual({ ok: true, intent: "create-link-record" });

        expect(prisma.sharedLink.create).toHaveBeenCalledWith({
          data: expect.objectContaining({ // Use objectContaining for flexibility
            userId: mockUser.id,
            storageKey: "user-uploads/user-123/uuid-test.txt",
            originalFileName: "test.txt",
            fileType: "text/plain",
            fileSizeBytes: 1234,
          }),
        });
      });

      it("should throw if s3Key is missing", async () => {
        mockedGetAuthSession.mockResolvedValue(mockUser);
        const formData = createFormData();
        formData.delete("s3Key");
        const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
        await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing s3Key");
      });

       it("should throw if originalFilename is missing", async () => {
        mockedGetAuthSession.mockResolvedValue(mockUser);
        const formData = createFormData();
        formData.delete("originalFilename");
        const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
        await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing originalFilename");
      });

       it("should throw if contentType is missing", async () => {
        mockedGetAuthSession.mockResolvedValue(mockUser);
        const formData = createFormData();
        formData.delete("contentType");
        const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
        await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing contentType");
      });

       it("should throw if fileSize is missing", async () => {
        mockedGetAuthSession.mockResolvedValue(mockUser);
        const formData = createFormData();
        formData.delete("fileSize");
        const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
        await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing fileSize");
      });

       it("should throw if fileSize is invalid", async () => {
        mockedGetAuthSession.mockResolvedValue(mockUser);
        const formData = createFormData();
        formData.set("fileSize", "not-a-number");
        const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
        await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Invalid fileSize");
       });
     });
     // --- End tests for create-link-record ---

     // --- Tests for update-expiry intent ---
     describe("update-expiry intent", () => {
       const expiryDate = new Date(Date.now() + 86400000); // Tomorrow
       const expiryDateStr = expiryDate.toISOString().slice(0, 16); // Format for datetime-local

       const createExpiryFormData = (expiresAtValue: string | null = expiryDateStr) => {
         const formData = new FormData();
         formData.append("intent", "update-expiry");
         formData.append("linkId", "link-abc");
         if (expiresAtValue !== null) {
           formData.append("expiresAt", expiresAtValue);
         } else {
            // Simulate clearing the date - Remix might send empty string
            formData.append("expiresAt", "");
         }
         formData.append("clientTimezone", "America/Denver"); // Add clientTimezone
         return formData;
       };

       it("should update expiry and return ok if successful", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         (prisma.sharedLink.update as Mock).mockResolvedValue({ ...mockLinks[0], expiresAt: expiryDate });
         const formData = createExpiryFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(200);
         // Updated to include the cleared: false flag
         expect(await response.json()).toEqual({ 
           ok: true, 
           intent: "update-expiry", 
           linkId: "link-abc",
           cleared: false 
         });
         expect(prisma.sharedLink.update).toHaveBeenCalledWith({
           where: { id: "link-abc" },
           // Check that expiresAt is any Date object, avoiding exact instance comparison
           data: { expiresAt: expect.any(Date) },
         });
       });

       it("should clear expiry and return ok if _action is clearExpiry", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         (prisma.sharedLink.update as Mock).mockResolvedValue({ ...mockLinks[0], expiresAt: null });
         
         // Create form data with _action=clearExpiry instead of empty string
         const formData = new FormData();
         formData.append("intent", "update-expiry");
         formData.append("linkId", "link-abc");
         formData.append("expiresAt", expiryDateStr); // Add a valid date
         formData.append("_action", "clearExpiry"); // Add the clear action
         
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(200);
         expect(await response.json()).toEqual({ 
           ok: true, 
           intent: "update-expiry", 
           linkId: "link-abc",
           cleared: true 
         });
         expect(prisma.sharedLink.update).toHaveBeenCalledWith({
           where: { id: "link-abc" },
           data: { expiresAt: null }, // Expect null
         });
       });

       it("should return 400 if date format is invalid", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         const formData = createExpiryFormData("invalid-date");
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(400);
         expect(await response.json()).toEqual({
           ok: false,
           error: "Invalid date format provided.",
           intent: "update-expiry",
           linkId: "link-abc",
         });
       });

       it("should throw 404 if link not found", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null);
         const formData = createExpiryFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(404);
         }
       });

       it("should throw 403 if link does not belong to user", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: "other-user" });
         const formData = createExpiryFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(403);
         }
       });

       it("should throw if expiresAt is missing", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         
         // Create a form without expiresAt but with the other required fields
         const formData = new FormData();
         formData.append("intent", "update-expiry");
         formData.append("linkId", "link-abc");
         // Intentionally not adding expiresAt
         
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
         
         await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing expiresAt value when not clearing");
       });
     });
     // --- End tests for update-expiry ---

      // --- Tests for update-description intent ---
      describe("update-description intent", () => {
         const createDescriptionFormData = (description = "New description") => {
          const formData = new FormData();
          formData.append("intent", "update-description");
          formData.append("linkId", "link-abc");
         formData.append("description", description);
         return formData;
       };

       it("should update description and return ok if successful", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         (prisma.sharedLink.update as Mock).mockResolvedValue({ ...mockLinks[0], description: "New description" });
         const formData = createDescriptionFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(200);
         expect(await response.json()).toEqual({ ok: true, intent: "update-description", linkId: "link-abc" });
         expect(prisma.sharedLink.update).toHaveBeenCalledWith({
           where: { id: "link-abc" },
           data: { description: "New description" },
         });
       });

       it("should update description to empty string and return ok", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: mockUser.id });
         (prisma.sharedLink.update as Mock).mockResolvedValue({ ...mockLinks[0], description: "" });
         const formData = createDescriptionFormData(""); // Empty description
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(200);
         expect(await response.json()).toEqual({ ok: true, intent: "update-description", linkId: "link-abc" });
         expect(prisma.sharedLink.update).toHaveBeenCalledWith({
           where: { id: "link-abc" },
           data: { description: "" },
         });
       });

       it("should throw 404 if link not found", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null);
         const formData = createDescriptionFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(404);
         }
       });

       it("should throw 403 if link does not belong to user", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ userId: "other-user" });
         const formData = createDescriptionFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(403);
         }
       });

       it("should throw if description is missing", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         const formData = createDescriptionFormData();
         formData.delete("description");
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
         await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing description");
       });
     });
     // --- End tests for update-description ---

      // --- Tests for share-link intent ---
      describe("share-link intent", () => {
        const linkToShare = { ...mockLinks[0], revoked: false, expiresAt: null }; // Ensure link is shareable

        const createShareFormData = (recipient = "recipient@test.com", message = "Test message") => {
          const formData = new FormData();
          formData.append("intent", "share-link");
          formData.append("linkId", linkToShare.id);
         formData.append("recipientEmail", recipient);
         formData.append("message", message);
         return formData;
       };

       beforeEach(() => {
         // Mock successful email sending by default
         mockedSendEmail.mockResolvedValue(undefined);
         // Mock finding the link by default
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue(linkToShare);
         // Mock process.env for FROM_EMAIL
         process.env.FROM_EMAIL = "sender@test.com";
       });

       afterEach(() => {
         // Clean up env var
         delete process.env.FROM_EMAIL;
       });


       it("should send email and return ok if successful", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(200);
         expect(await response.json()).toEqual({ ok: true, intent: "share-link", linkId: linkToShare.id });
         expect(prisma.sharedLink.findUnique).toHaveBeenCalledWith({
           where: { id: linkToShare.id },
           select: expect.any(Object), // Check specific fields if needed
         });
         expect(mockedSendEmail).toHaveBeenCalledWith(expect.objectContaining({
           to: "recipient@test.com",
           from: "sender@test.com",
           subject: expect.stringContaining("shared a file with you"),
           text: expect.stringContaining("http://localhost/link/abc"),
           html: expect.stringContaining("http://localhost/link/abc"),
         }));
       });

       it("should return 400 if recipient email is invalid", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         const formData = createShareFormData("invalid-email");
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(400);
         expect(await response.json()).toEqual(expect.objectContaining({ ok: false, error: "Invalid recipient email format." }));
         expect(mockedSendEmail).not.toHaveBeenCalled();
       });

       it("should return 400 if link is revoked", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ ...linkToShare, revoked: true });
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(400);
         expect(await response.json()).toEqual(expect.objectContaining({ ok: false, error: "Cannot share a revoked link." }));
         expect(mockedSendEmail).not.toHaveBeenCalled();
       });

       it("should return 400 if link is expired", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         const pastDate = new Date(Date.now() - 10000);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ ...linkToShare, expiresAt: pastDate });
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(400);
         expect(await response.json()).toEqual(expect.objectContaining({ ok: false, error: "Cannot share an expired link." }));
         expect(mockedSendEmail).not.toHaveBeenCalled();
       });


       it("should return 500 if FROM_EMAIL is not set", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         delete process.env.FROM_EMAIL; // Unset the env var
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(500);
         expect(await response.json()).toEqual(expect.objectContaining({ ok: false, error: "Server configuration error: Unable to send email." }));
         expect(mockedSendEmail).not.toHaveBeenCalled();
       });

       it("should return 500 if sendEmail throws an error", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         mockedSendEmail.mockRejectedValue(new Error("SendGrid failed")); // Simulate email failure
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         const response = await action({ request, params: {}, context: {} });

         expect(response.status).toBe(500);
         expect(await response.json()).toEqual(expect.objectContaining({ ok: false, error: "Failed to send email. Please try again later." }));
         expect(mockedSendEmail).toHaveBeenCalled(); // It was called, but failed
       });

       it("should throw 404 if link not found", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue(null);
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(404);
         }
       });

       it("should throw 403 if link does not belong to user", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         (prisma.sharedLink.findUnique as Mock).mockResolvedValue({ ...linkToShare, userId: "other-user" });
         const formData = createShareFormData();
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

         try {
           await action({ request, params: {}, context: {} });
           expect.fail("Action should have thrown");
         } catch (e) {
           const errorResponse = e as Response;
           expect(errorResponse.status).toBe(403);
         }
       });

       it("should throw if recipientEmail is missing", async () => {
         mockedGetAuthSession.mockResolvedValue(mockUser);
         const formData = createShareFormData();
         formData.delete("recipientEmail");
         const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
         await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing or invalid recipientEmail");
       });

       // Note: Missing 'message' is allowed (defaults to empty string), so no invariant test needed for it.

     });
     // --- End tests for share-link ---

    // --- Tests for Branding intents ---
    describe("Branding intents", () => {
      const mockProUser: User = { ...mockUser, plan: "PRO" as const }; // Ensure plan is 'PRO'

      describe("update-branding-colors intent", () => {
        const createBrandingColorsFormData = (
          colorPrimary = "#112233",
          colorText = "#AABBCC"
        ) => {
          const formData = new FormData();
          formData.append("intent", "update-branding-colors");
          formData.append("brandingColorPrimary", colorPrimary);
          formData.append("brandingColorText", colorText);
          formData.append("linkId", "dummy-link-id"); // linkId is checked at top of action
          return formData;
        };

        it("should update branding colors for a PRO user and return ok", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser); // For plan check
          (prisma.user.update as Mock).mockResolvedValue(mockProUser); // Mock update

          const formData = createBrandingColorsFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(200);
          expect(await response.json()).toEqual({ ok: true, intent: "update-branding-colors", error: null });
          expect(prisma.user.update).toHaveBeenCalledWith({
            where: { id: mockProUser.id },
            data: { brandingColorPrimary: "#112233", brandingColorText: "#AABBCC" },
          });
        });

        it("should return 403 if a FREE user tries to update branding colors", async () => {
          mockedGetAuthSession.mockResolvedValue(mockUser); // mockUser is FREE plan
          (prisma.user.findUnique as Mock).mockResolvedValue(mockUser); // For plan check

          const formData = createBrandingColorsFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(403);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Branding customization is a Pro feature." }));
        });

        it("should return 400 for invalid primary hex color format", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);

          const formData = createBrandingColorsFormData("invalid-hex", "#FFFFFF");
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(400);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Invalid primary hex color format (e.g., #RRGGBB)." }));
        });

        it("should return 400 for invalid text hex color format", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);

          const formData = createBrandingColorsFormData("#112233", "invalid-hex");
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(400);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Invalid text hex color format (e.g., #RRGGBB)." }));
        });
      });

      describe("save-logo-url intent", () => {
        const logoUrl = "https://example.com/logo.png";
        const createSaveLogoFormData = (url = logoUrl) => {
          const formData = new FormData();
          formData.append("intent", "save-logo-url");
          formData.append("logoUrl", url);
          formData.append("linkId", "dummy-link-id"); // linkId is checked at top of action
          return formData;
        };

        it("should save logo URL for a PRO user and return ok", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);
          (prisma.user.update as Mock).mockResolvedValue(mockProUser);

          const formData = createSaveLogoFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(200);
          expect(await response.json()).toEqual({ ok: true, intent: "save-logo-url", error: null });
          expect(prisma.user.update).toHaveBeenCalledWith({
            where: { id: mockProUser.id },
            data: { brandingLogoUrl: logoUrl },
          });
        });

        it("should return 403 if a FREE user tries to save logo URL", async () => {
          mockedGetAuthSession.mockResolvedValue(mockUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockUser);

          const formData = createSaveLogoFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(403);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Branding customization is a Pro feature." }));
        });

        it("should return 400 if logoUrl is missing", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);
          const formData = createSaveLogoFormData(""); // Empty URL
          
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          // Invariant will throw an error, not return a Response
          await expect(action({ request, params: {}, context: {} })).rejects.toThrow("Missing logoUrl");
        });

        it("should return 400 if logoUrl is invalid (not http/https)", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);
          const formData = createSaveLogoFormData("ftp://invalid.com/logo.png");
          
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });
          
          expect(response.status).toBe(400);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Invalid logo URL provided." }));
        });
      });

      describe("remove-logo intent", () => {
        const createRemoveLogoFormData = () => {
          const formData = new FormData();
          formData.append("intent", "remove-logo");
          formData.append("linkId", "dummy-link-id"); // linkId is checked at top of action
          return formData;
        };

        it("should remove logo URL for a PRO user and return ok", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUser);
          (prisma.user.update as Mock).mockResolvedValue(mockProUser);

          const formData = createRemoveLogoFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(200);
          expect(await response.json()).toEqual({ ok: true, intent: "remove-logo", error: null });
          expect(prisma.user.update).toHaveBeenCalledWith({
            where: { id: mockProUser.id },
            data: { brandingLogoUrl: null },
          });
        });

        it("should return 403 if a FREE user tries to remove logo", async () => {
          mockedGetAuthSession.mockResolvedValue(mockUser);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockUser);

          const formData = createRemoveLogoFormData();
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          const response = await action({ request, params: {}, context: {} });

          expect(response.status).toBe(403);
          expect(await response.json()).toEqual(expect.objectContaining({ error: "Branding customization is a Pro feature." }));
        });
      });
    });
    // --- End tests for Branding intents ---

    // --- Tests for Stripe intents ---
    describe("Stripe intents", () => {
      const mockProUserWithStripe: User = {
        id: "user-pro-stripe",
        email: "pro_stripe@example.com",
        createdAt: new Date(),
        updatedAt: new Date(),
        auth0Sub: "auth0|prostripe",
        stripeCustomerId: "cus_test123",
        stripeSubscriptionId: "sub_test123",
        stripeSubscriptionStatus: "active",
        plan: "PRO",
        brandingLogoUrl: null,
        brandingColorPrimary: null,
        brandingColorText: null,
      };
      const mockFreeUserWithStripeCustomerId: User = {
        id: "user-free-stripe",
        email: "free_stripe@example.com",
        createdAt: new Date(),
        updatedAt: new Date(),
        auth0Sub: "auth0|freestripe",
        stripeCustomerId: "cus_test_free123",
        stripeSubscriptionId: null,
        stripeSubscriptionStatus: null,
        plan: "FREE",
        brandingLogoUrl: null,
        brandingColorPrimary: null,
        brandingColorText: null,
      };

      let originalStripeProPriceId: string | undefined;
      let originalStripeSecretKey: string | undefined; // For stripe client init if it checks

      beforeEach(() => {
        originalStripeProPriceId = process.env.STRIPE_PRO_PRICE_ID;
        originalStripeSecretKey = process.env.STRIPE_SECRET_KEY; // Save if stripe client init needs it
        process.env.STRIPE_PRO_PRICE_ID = "price_pro_test123";
        process.env.STRIPE_SECRET_KEY = "sk_test_xxxxxxxxxxxxxx"; // Needed for stripe client
        
        // Mock Stripe SDK methods if not already globally mocked
        // Assuming 'stripe' is imported from '~/stripe.server' and is an initialized client
        // This requires vi.mock('~/stripe.server') at the top of the file.
      });

      afterEach(() => {
        process.env.STRIPE_PRO_PRICE_ID = originalStripeProPriceId;
        process.env.STRIPE_SECRET_KEY = originalStripeSecretKey;
      });
      
      // Ensure stripe is mocked if it's not already (it should be if imported from stripe.server)
      describe("create-checkout-session intent", () => {
        it("should create a Stripe Checkout session and redirect for a FREE user", async () => {
          mockedGetAuthSession.mockResolvedValue(mockUser); // Free user without existing stripeCustomerId
          (prisma.user.findUnique as Mock).mockResolvedValue(mockUser); 
          
          const mockStripeCustomer = { id: "cus_new_test123" };
          vi.mocked(stripe.customers.create).mockResolvedValue(mockStripeCustomer as any); // Cast as any for mock
          (prisma.user.update as Mock).mockResolvedValue({ ...mockUser, stripeCustomerId: mockStripeCustomer.id });
          
          const mockCheckoutSession = { url: "https://checkout.stripe.com/session_123" };
          vi.mocked(stripe.checkout.sessions.create).mockResolvedValue(mockCheckoutSession as any); // Cast as any

          const formData = new FormData();
          formData.append("intent", "create-checkout-session");
          formData.append("linkId", "dummy-link-id");
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          
          const response = await action({ request, params: {}, context: {} });
          expect(response.status).toBe(302);
          expect(response.headers.get("Location")).toBe(mockCheckoutSession.url);
          expect(stripe.customers.create).toHaveBeenCalled();
          expect(prisma.user.update).toHaveBeenCalled();
          expect(stripe.checkout.sessions.create).toHaveBeenCalled();
        });

        // Add more tests: user already has stripeCustomerId, Stripe API errors, etc.
      });

      describe("create-billing-portal-session intent", () => {
        it("should create a Stripe Billing Portal session and redirect for a PRO user", async () => {
          mockedGetAuthSession.mockResolvedValue(mockProUserWithStripe);
          (prisma.user.findUnique as Mock).mockResolvedValue(mockProUserWithStripe);

          const mockPortalSession = { url: "https://billing.stripe.com/session_456" };
          vi.mocked(stripe.billingPortal.sessions.create).mockResolvedValue(mockPortalSession as any); // Cast as any

          const formData = new FormData();
          formData.append("intent", "create-billing-portal-session");
          formData.append("linkId", "dummy-link-id");
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });

          const response = await action({ request, params: {}, context: {} });
          expect(response.status).toBe(302);
          expect(response.headers.get("Location")).toBe(mockPortalSession.url);
          expect(stripe.billingPortal.sessions.create).toHaveBeenCalled();
        });
        
        it("should return 500 if user has no stripeCustomerId", async () => {
          const userWithoutStripeId: User = { ...mockProUserWithStripe, stripeCustomerId: null };
          mockedGetAuthSession.mockResolvedValue(userWithoutStripeId); 
          (prisma.user.findUnique as Mock).mockResolvedValue(userWithoutStripeId);

          const formData = new FormData();
          formData.append("intent", "create-billing-portal-session");
          formData.append("linkId", "dummy-link-id");
          const request = new Request("http://localhost/dashboard", { method: "POST", body: formData });
          
          try {
            await action({ request, params: {}, context: {} });
            expect.fail("Action should have thrown");
          } catch(e) {
            const errorResponse = e as Response;
            expect(errorResponse.status).toBe(500); // Or specific error from invariant
            // The invariant "User does not have a Stripe customer ID." will throw an Error,
            // which Remix catches and turns into a 500 if not caught by the action.
            // The action itself throws a Response("Could not open billing portal...", {status: 500})
            // if the invariant fails or other errors occur.
            // The response body is text, not JSON for this specific error path from the action
            expect(await errorResponse.text()).toContain("Could not open billing portal");
          }
        });
        // Add more tests: Stripe API errors, etc.
      });
    });
    // --- End tests for Stripe intents ---
   });
 });
