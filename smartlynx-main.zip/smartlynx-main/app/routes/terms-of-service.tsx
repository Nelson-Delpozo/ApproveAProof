import type { MetaFunction } from "@remix-run/node";

export const meta: MetaFunction = () => {
  return [
    { title: "Terms of Service | SmartLynx" },
    { name: "description", content: "SmartLynx Terms of Service" },
  ];
};

// Basic Tailwind styling can be applied here or via a shared layout component
const containerClasses = "container mx-auto px-4 py-8 prose lg:prose-xl dark:prose-invert"; // Added dark:prose-invert
const headingClasses = "text-2xl font-bold mb-4"; // These might be overridden by prose, but kept for structure
const subHeadingClasses = "text-xl font-semibold mt-6 mb-3"; // These might be overridden by prose
const paragraphClasses = "mb-4";
const listClasses = "list-disc list-inside mb-4";

export default function TermsOfService() {
  return (
    <div className={containerClasses}>
      <h1 className={headingClasses}>Terms of Service for SmartLynx</h1>
      <p className={paragraphClasses}>
        <strong>Last Updated: April 18, 2025</strong>
      </p>

      <p className={paragraphClasses}>
        Welcome to SmartLynx! These Terms of Service (&quot;Terms&quot;) govern your use of the smartlynx.app website and the SmartLynx service (collectively, the &quot;Service&quot;) operated by SmartLynx (&quot;us&quot;, &quot;we&quot;, or &quot;our&quot;).
      </p>
      <p className={paragraphClasses}>
        Please read these Terms carefully before using our Service. Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the Service. By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service.
      </p>
      {/* <p className={paragraphClasses}>
        <strong>Disclaimer:</strong> This is a template Terms of Service. It is essential to consult with a legal professional to ensure these terms are appropriate for your specific service, comply with all legal requirements, and adequately protect your interests.
      </p> */}

      <h2 className={subHeadingClasses}>1. Accounts</h2>
      <p className={paragraphClasses}>
        When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
      </p>
      <p className={paragraphClasses}>
        You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service. You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.
      </p>

      <h2 className={subHeadingClasses}>2. Service Description</h2>
      <p className={paragraphClasses}>
        SmartLynx provides a platform for users to upload files, generate secure shareable links, manage these links (e.g., set expiry, revoke access), and view analytics related to link access. Features may vary based on subscription tier (e.g., Free, Pro).
      </p>

      <h2 className={subHeadingClasses}>3. User Content</h2>
      <p className={paragraphClasses}>
        Our Service allows you to upload, store, link, share and otherwise make available certain information, text, graphics, videos, or other material (&quot;Content&quot;). You are responsible for the Content that you post to the Service, including its legality, reliability, and appropriateness.
      </p>
      <p className={paragraphClasses}>
        By posting Content to the Service, you grant us the right and license to use, modify, publicly perform, publicly display, reproduce, and distribute such Content on and through the Service solely for the purpose of operating and providing the Service. You retain any and all of your rights to any Content you submit, post or display on or through the Service and you are responsible for protecting those rights.
      </p>
      <p className={paragraphClasses}>
        You represent and warrant that: (i) the Content is yours (you own it) or you have the right to use it and grant us the rights and license as provided in these Terms, and (ii) the posting of your Content on or through the Service does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person.
      </p>
      <p className={paragraphClasses}>
        We reserve the right to remove any Content that violates these Terms or is otherwise objectionable, in our sole discretion.
      </p>

      <h2 className={subHeadingClasses}>4. Subscriptions and Payments</h2>
      <p className={paragraphClasses}>
        Some parts of the Service are billed on a subscription basis (&quot;Subscription(s)&quot;). You will be billed in advance on a recurring and periodic basis (&quot;Billing Cycle&quot;). Billing cycles are set either on a monthly or annual basis, depending on the type of subscription plan you select when purchasing a Subscription.
      </p>
      <p className={paragraphClasses}>
        At the end of each Billing Cycle, your Subscription will automatically renew under the exact same conditions unless you cancel it or SmartLynx cancels it. You may cancel your Subscription renewal either through your online account management page (via the Stripe Billing Portal) or by contacting SmartLynx customer support.
      </p>
      <p className={paragraphClasses}>
        A valid payment method, including credit card, is required to process the payment for your Subscription. You shall provide SmartLynx with accurate and complete billing information including full name, address, state, zip code, telephone number, and a valid payment method information. By submitting such payment information, you automatically authorize SmartLynx (via our payment processor, Stripe) to charge all Subscription fees incurred through your account to any such payment instruments.
      </p>
      <p className={paragraphClasses}>
        Should automatic billing fail to occur for any reason, SmartLynx will issue an electronic invoice indicating that you must proceed manually, within a certain deadline date, with the full payment corresponding to the billing period as indicated on the invoice.
      </p>
      <p className={paragraphClasses}>
        All fees are exclusive of all taxes, levies, or duties imposed by taxing authorities, and you shall be responsible for payment of all such taxes, levies, or duties.
      </p>

      <h2 className={subHeadingClasses}>5. Fee Changes</h2>
      <p className={paragraphClasses}>
        SmartLynx, in its sole discretion and at any time, may modify the Subscription fees for the Subscriptions. Any Subscription fee change will become effective at the end of the then-current Billing Cycle. SmartLynx will provide you with reasonable prior notice of any change in Subscription fees to give you an opportunity to terminate your Subscription before such change becomes effective. Your continued use of the Service after the Subscription fee change comes into effect constitutes your agreement to pay the modified Subscription fee amount.
      </p>

      <h2 className={subHeadingClasses}>6. Refunds</h2>
      <p className={paragraphClasses}>
        Except when required by law, paid Subscription fees are non-refundable.
      </p>

      <h2 className={subHeadingClasses}>7. Prohibited Uses</h2>
      <p className={paragraphClasses}>
        You may use the Service only for lawful purposes and in accordance with Terms. You agree not to use the Service:
      </p>
      <ul className={listClasses}>
        <li>In any way that violates any applicable national or international law or regulation.</li>
        <li>For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way.</li>
        <li>To transmit, or procure the sending of, any advertising or promotional material, including any &quot;junk mail&quot;, &quot;chain letter,&quot; &quot;spam,&quot; or any other similar solicitation.</li>
        <li>To impersonate or attempt to impersonate SmartLynx, a SmartLynx employee, another user, or any other person or entity.</li>
        <li>To upload or share any Content that is illegal, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, invasive of another&apos;s privacy, hateful, or racially, ethnically, or otherwise objectionable.</li>
        <li>To infringe any patent, trademark, trade secret, copyright, or other intellectual property rights of any party.</li>
        <li>To engage in any other conduct that restricts or inhibits anyone&apos;s use or enjoyment of the Service, or which, as determined by us, may harm SmartLynx or users of the Service or expose them to liability.</li>
        <li>To interfere with or disrupt the Service or servers or networks connected to the Service.</li>
        <li>To attempt to gain unauthorized access to the Service, other accounts, computer systems or networks connected to the Service, through hacking, password mining or any other means.</li>
      </ul>

      <h2 className={subHeadingClasses}>8. Intellectual Property</h2>
      <p className={paragraphClasses}>
        The Service and its original content (excluding Content provided by users), features and functionality are and will remain the exclusive property of SmartLynx and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of SmartLynx.
      </p>

      <h2 className={subHeadingClasses}>9. Termination</h2>
      <p className={paragraphClasses}>
        We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms. Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service or cancel your subscription via the billing portal.
      </p>
      <p className={paragraphClasses}>
        All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.
      </p>

      <h2 className={subHeadingClasses}>10. Indemnification</h2>
      <p className={paragraphClasses}>
        You agree to defend, indemnify and hold harmless SmartLynx and its licensee and licensors, and their employees, contractors, agents, officers and directors, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney&apos;s fees), resulting from or arising out of a) your use and access of the Service, by you or any person using your account and password; b) a breach of these Terms, or c) Content posted on the Service.
      </p>

      <h2 className={subHeadingClasses}>11. Limitation Of Liability</h2>
      <p className={paragraphClasses}>
        In no event shall SmartLynx, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service; (ii) any conduct or content of any third party on the Service; (iii) any content obtained from the Service; and (iv) unauthorized access, use or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence) or any other legal theory, whether or not we have been informed of the possibility of such damage, and even if a remedy set forth herein is found to have failed of its essential purpose.
      </p>

      <h2 className={subHeadingClasses}>12. Disclaimer</h2>
      <p className={paragraphClasses}>
        Your use of the Service is at your sole risk. The Service is provided on an &quot;AS IS&quot; and &quot;AS AVAILABLE&quot; basis. The Service is provided without warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, non-infringement or course of performance.
      </p>
      <p className={paragraphClasses}>
        SmartLynx its subsidiaries, affiliates, and its licensors do not warrant that a) the Service will function uninterrupted, secure or available at any particular time or location; b) any errors or defects will be corrected; c) the Service is free of viruses or other harmful components; or d) the results of using the Service will meet your requirements.
      </p>

      <h2 className={subHeadingClasses}>13. Governing Law</h2>
      <p className={paragraphClasses}>
        These Terms shall be governed and construed in accordance with the laws of [Your State/Country, e.g., California, United States], without regard to its conflict of law provisions.
      </p>
      <p className={paragraphClasses}>
        Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our Service, and supersede and replace any prior agreements we might have between us regarding the Service.
      </p>

      <h2 className={subHeadingClasses}>14. Changes</h2>
      <p className={paragraphClasses}>
        We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
      </p>
      <p className={paragraphClasses}>
        By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Service.
      </p>

      <h2 className={subHeadingClasses}>15. Contact Us</h2>
      <p className={paragraphClasses}>
        If you have any questions about these Terms, please contact us: linkshare@smartlynx.app
      </p>
    </div>
  );
}
