import type { ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import type Stripe from "stripe";
import invariant from "tiny-invariant";

import { prisma } from "~/db.server";
import { stripe } from "~/stripe.server";

// Ensure the webhook secret is set in the environment
invariant(process.env.STRIPE_WEBHOOK_SECRET, "STRIPE_WEBHOOK_SECRET must be set");
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

export async function action({ request }: ActionFunctionArgs) {
  if (request.method !== "POST") {
    return json({ message: "Method Not Allowed" }, 405);
  }

  const sig = request.headers.get("stripe-signature");
  if (!sig) {
    console.error("⚠️ Missing Stripe signature header.");
    return json({ error: "Missing Stripe signature." }, 400);
  }

  let event: Stripe.Event;

  try {
    // Read the raw body text
    const payload = await request.text();
    // Verify the webhook signature
    event = stripe.webhooks.constructEvent(payload, sig, endpointSecret);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error(`⚠️ Webhook signature verification failed: ${message}`);
    return json({ error: `Webhook Error: ${message}` }, 400);
  }

  console.log(`✅ Stripe Webhook Received: ${event.type}`);

  // Handle the event
  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      console.log(`Checkout session completed: ${session.id}`);

      // Check if the session mode is subscription
      if (session.mode !== "subscription") {
        console.log(`Ignoring checkout session ${session.id} - not a subscription.`);
        return json({ received: true });
      }

      // --- Robustly extract IDs ---
      let subscriptionId: string | null = null;
      if (typeof session.subscription === 'string') {
        subscriptionId = session.subscription;
      } else if (session.subscription?.id) {
        subscriptionId = session.subscription.id;
      }

      let customerId: string | null = null;
      if (typeof session.customer === 'string') {
        customerId = session.customer;
      } else if (session.customer?.id) {
        customerId = session.customer.id;
      }
      // --- End Robust ID extraction ---

      if (!subscriptionId || !customerId) {
        console.error(`⚠️ Missing or invalid subscription or customer ID in checkout session ${session.id}`);
        return json({ error: "Missing or invalid subscription or customer ID." }, 400);
      }

      try {
        // Retrieve the subscription to get status and plan details
        // No need for 'as string' anymore, we ensured it's a string or null above
        const subscription = await stripe.subscriptions.retrieve(subscriptionId);

        // Find the user by Stripe Customer ID
        // No need for 'as string' anymore
        const user = await prisma.user.findUnique({
          where: { stripeCustomerId: customerId },
        });

        if (!user) {
          console.error(`⚠️ User not found for Stripe customer ID: ${customerId}`);
          // Consider creating the user if they somehow don't exist, or log error
          return json({ error: "User not found." }, 404); // Or 400?
        }

        // Update the user record
        await prisma.user.update({
          where: { id: user.id },
          data: {
            stripeSubscriptionId: subscription.id,
            stripeSubscriptionStatus: subscription.status,
            // Determine plan based on the price ID (assuming only one item)
            // This requires knowing which price ID corresponds to which plan
            // TODO: Make this more robust if multiple plans/prices exist
            plan: subscription.items.data[0]?.price.id === process.env.STRIPE_PRO_PRICE_ID ? "PRO" : "FREE",
          },
        });
        console.log(`✅ Updated user ${user.id} with subscription ${subscription.id}`);

      } catch (dbError) {
        console.error("⚠️ Database error handling checkout.session.completed:", dbError);
        return json({ error: "Database update failed." }, 500);
      }
      break;
    }

    case "customer.subscription.updated": {
      const subscription = event.data.object as Stripe.Subscription;
      console.log(`Subscription updated: ${subscription.id}, Status: ${subscription.status}`);

      const customerId = subscription.customer;

      try {
        // Find the user by Stripe Customer ID
        const user = await prisma.user.findUnique({
          where: { stripeCustomerId: customerId as string },
        });

        if (!user) {
          console.error(`⚠️ User not found for Stripe customer ID: ${customerId}`);
          return json({ error: "User not found." }, 404);
        }

        // Update the user record
        await prisma.user.update({
          where: { id: user.id },
          data: {
            stripeSubscriptionStatus: subscription.status,
            // Update plan based on price ID if it changed (or handle cancellations)
            plan: subscription.items.data[0]?.price.id === process.env.STRIPE_PRO_PRICE_ID && subscription.status === 'active' ? "PRO" : "FREE",
          },
        });
        console.log(`✅ Updated user ${user.id} subscription status to ${subscription.status}`);

      } catch (dbError) {
        console.error("⚠️ Database error handling customer.subscription.updated:", dbError);
        return json({ error: "Database update failed." }, 500);
      }
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      console.log(`Subscription deleted: ${subscription.id}, Status: ${subscription.status}`);

      const customerId = subscription.customer;

      try {
        // Find the user by Stripe Customer ID
        const user = await prisma.user.findUnique({
          where: { stripeCustomerId: customerId as string },
        });

        if (!user) {
          console.error(`⚠️ User not found for Stripe customer ID: ${customerId}`);
          return json({ error: "User not found." }, 404);
        }

        // Update the user record - typically revert to FREE plan
        await prisma.user.update({
          where: { id: user.id },
          data: {
            stripeSubscriptionStatus: subscription.status, // Should be 'canceled' or similar
            plan: "FREE", // Revert to free plan
            // Optionally clear stripeSubscriptionId? Depends on desired logic
            // stripeSubscriptionId: null,
          },
        });
        console.log(`✅ Updated user ${user.id} subscription status to ${subscription.status} (deleted), reverted to FREE plan.`);

      } catch (dbError) {
        console.error("⚠️ Database error handling customer.subscription.deleted:", dbError);
        return json({ error: "Database update failed." }, 500);
      }
      break;
    }

    // ... handle other event types if needed

    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  // Return a 200 response to acknowledge receipt of the event
  return json({ received: true });
}
