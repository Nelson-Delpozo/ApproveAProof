import { S3Client } from "@aws-sdk/client-s3"; // AWS SDK imports first
import { createPresignedPost } from "@aws-sdk/s3-presigned-post";
import { ActionFunctionArgs, json } from "@remix-run/node"; // Remix imports next
import invariant from "tiny-invariant"; // Other packages
import { v4 as uuidv4 } from "uuid";

import { getAuthSession } from "~/auth.server"; // Local app imports last

// Define constants for logo uploads
const MAX_LOGO_SIZE_MB = 2; // Set max logo size (e.g., 2MB)
const MAX_LOGO_SIZE_BYTES = MAX_LOGO_SIZE_MB * 1024 * 1024;


export const action = async ({ request }: ActionFunctionArgs) => {
  // --- Move Env Var Access, Checks, and Client Instantiation INSIDE action ---
  const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME;
  const REGION = process.env.AWS_REGION;
  const ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
  const SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;

  // Ensure required environment variables are set inside the action
  invariant(ACCESS_KEY_ID, "AWS_ACCESS_KEY_ID must be set");
  invariant(SECRET_ACCESS_KEY, "AWS_SECRET_ACCESS_KEY must be set");
  invariant(BUCKET_NAME, "AWS_S3_BUCKET_NAME must be set");
  invariant(REGION, "AWS_REGION must be set");

  // Instantiate S3 Client inside the action
  const s3Client = new S3Client({
    region: REGION,
    credentials: {
      accessKeyId: ACCESS_KEY_ID,
      secretAccessKey: SECRET_ACCESS_KEY,
    },
  });
  // --- End Moved Code ---

  const authSession = await getAuthSession(request); // Get user session data
  if (!authSession?.id) { // Check for 'id'
    return json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = authSession.id; // Use 'id' from the auth session object

  const formData = await request.formData();
  const filename = formData.get("filename");
  const contentType = formData.get("contentType");

  if (typeof filename !== "string" || filename.length === 0) {
    return json({ error: "Filename is required." }, { status: 400 });
  }
  if (typeof contentType !== "string" || contentType.length === 0) {
    return json({ error: "Content type is required." }, { status: 400 });
  }

  // Validate content type for images
  if (!contentType.startsWith("image/")) {
    return json({ error: "Invalid file type. Only images are allowed for logos." }, { status: 400 });
  }

  // Generate a unique key for S3 specifically for logos
  // Example: user-logos/{userId}/{uuid}-{originalFilename}
  const uniqueKey = `user-logos/${userId}/${uuidv4()}-${filename}`;

  try {
    // Use the locally instantiated s3Client
    const { url, fields } = await createPresignedPost(s3Client, {
      Bucket: BUCKET_NAME,
      Key: uniqueKey,
      Conditions: [
        ["content-length-range", 0, MAX_LOGO_SIZE_BYTES], // Max logo size condition
        ["starts-with", "$Content-Type", "image/"], // Ensure content type is an image
      ],
      Fields: {
        "Content-Type": contentType,
        // Consider setting ACL to public-read if logos should be directly accessible via URL
        acl: "public-read", // Explicitly set ACL for public readability
      },
      Expires: 600, // Presigned URL expires in 600 seconds (10 minutes)
    });

    console.log(`Generated presigned POST for logo key: ${uniqueKey}, user: ${userId}`);

    // **Important:** Construct the final public URL here if possible and reliable.
    // If the bucket/objects are public, the URL is predictable.
    // If not, the presigned URL itself might be needed, or a separate mechanism
    // to get a publicly accessible URL (like CloudFront).
    // Assuming public bucket for simplicity:
    const finalLogoUrl = `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${uniqueKey}`;

    // Return the POST URL/fields AND the final public URL (or key)
    // The client needs url/fields for the POST, and key/finalLogoUrl to save in the DB
    return json({ url, fields, key: uniqueKey, finalLogoUrl: finalLogoUrl });

  } catch (error) {
    console.error("Error creating presigned POST URL for logo:", error);
    return json({ error: "Failed to prepare logo upload." }, { status: 500 });
  }
};
