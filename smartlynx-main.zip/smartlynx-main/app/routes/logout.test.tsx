// Removed unused redirect import
import { describe, it, expect, vi, beforeEach } from "vitest";

import { destroyAuthSession } from "~/auth.server"; // Import the function to mock

import { loader, action } from "./logout"; // Import loader and action

// Mock the auth.server module
vi.mock("~/auth.server"); // Mock before import
const mockedDestroyAuthSession = vi.mocked(destroyAuthSession);

// Mock environment variables used by the route
const mockEnv = {
  AUTH0_DOMAIN: "test-domain.auth0.com",
  AUTH0_CLIENT_ID: "test-client-id",
  AUTH0_LOGOUT_URL: "http://localhost:3000/", // Example return URL
};

describe("Logout Route", () => {
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    vi.resetAllMocks();
    // Store original env and set mock env
    originalEnv = process.env;
    process.env = { ...originalEnv, ...mockEnv };
  });

  afterEach(() => {
    // Restore original env
    process.env = originalEnv;
  });

  // Helper to construct the expected Auth0 logout URL
  const getExpectedLogoutUrl = () => {
    const params = new URLSearchParams({
      client_id: mockEnv.AUTH0_CLIENT_ID,
      returnTo: mockEnv.AUTH0_LOGOUT_URL,
    });
    return `https://${mockEnv.AUTH0_DOMAIN}/v2/logout?${params.toString()}`;
  };

  const testCases = [
    { name: "loader", handler: loader },
    { name: "action", handler: action },
  ];

  testCases.forEach(({ name, handler }) => {
    describe(name, () => {
      it("should destroy session and redirect to Auth0 logout URL", async () => {
        // Arrange
        const mockDestroyedCookie = "mock-destroyed-cookie-value";
        mockedDestroyAuthSession.mockResolvedValue(mockDestroyedCookie);
        const request = new Request("http://localhost/logout", { method: name === 'action' ? 'POST' : 'GET' });
        const expectedUrl = getExpectedLogoutUrl();
        // Removed unused expectedHeaders variable

        // Act
        const response = await handler({ request, context: {}, params: {} });

        // Assert
        expect(mockedDestroyAuthSession).toHaveBeenCalledWith(request);
        expect(response.status).toBe(302);
        expect(response.headers.get("Location")).toBe(expectedUrl);
        expect(response.headers.get("Set-Cookie")).toBe(mockDestroyedCookie);
      });

       it("should throw if AUTH0_DOMAIN is missing", async () => {
        delete process.env.AUTH0_DOMAIN;
        const request = new Request("http://localhost/logout", { method: name === 'action' ? 'POST' : 'GET' });
        await expect(handler({ request, context: {}, params: {} })).rejects.toThrow("AUTH0_DOMAIN must be set");
      });

       it("should throw if AUTH0_CLIENT_ID is missing", async () => {
        delete process.env.AUTH0_CLIENT_ID;
         const request = new Request("http://localhost/logout", { method: name === 'action' ? 'POST' : 'GET' });
        await expect(handler({ request, context: {}, params: {} })).rejects.toThrow("AUTH0_CLIENT_ID must be set");
      });

       it("should throw if AUTH0_LOGOUT_URL is missing", async () => {
        delete process.env.AUTH0_LOGOUT_URL;
         const request = new Request("http://localhost/logout", { method: name === 'action' ? 'POST' : 'GET' });
        await expect(handler({ request, context: {}, params: {} })).rejects.toThrow("AUTH0_LOGOUT_URL must be set");
      });
    });
  });
});
