import { type LoaderFunctionArgs } from "@remix-run/node"; // Remove unused createCookieSessionStorage
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest"; // Add afterEach, vi

// Remove unused import: import * as sessionServer from "~/session.server";


// Mock environment variables used by the route - MOVED TO TOP LEVEL
const mockEnv = {
  AUTH0_DOMAIN: "test-domain.auth0.com",
  AUTH0_CLIENT_ID: "test-client-id",
  AUTH0_CALLBACK_URL: "http://localhost:3000/callback",
  SESSION_SECRET: "test-secret",
};

// Define the reusable mock session object structure
const mockSession = {
  get: vi.fn(),
  set: vi.fn(),
  flash: vi.fn(),
  unset: vi.fn(),
  has: vi.fn(),
  destroy: vi.fn(),
  id: "mock-session-id",
  data: {},
};

// Mock the session storage directly within the factory
vi.mock("~/session.server", () => {
  // Define the mock functions inside the factory scope
  const mockGetSessionFn = vi.fn();
  const mockCommitSessionFn = vi.fn();
  const mockDestroySessionFn = vi.fn();

  // Return the mocked structure
  return {
    sessionStorage: {
      getSession: mockGetSessionFn,
      commitSession: mockCommitSessionFn,
      destroySession: mockDestroySessionFn,
    },
  };
});

// Import the mocked module to access its mocked functions
import { sessionStorage } from "~/session.server";

// Import the route functions *after* mocks and other imports
import { loader, action } from "./signup";

const mockedSessionStorage = vi.mocked(sessionStorage, true); // Deep mock access

describe("Signup Route", () => {
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    originalEnv = process.env;
    process.env = { ...originalEnv, ...mockEnv };
    vi.clearAllMocks(); // Clear call history etc.

    // Reset mock implementations for each test using the imported mock
    mockedSessionStorage.getSession.mockResolvedValue(mockSession);
    mockedSessionStorage.commitSession.mockResolvedValue("mock-cookie-value");
    // Reset internal session mock calls
    vi.mocked(mockSession.get).mockClear();
    vi.mocked(mockSession.set).mockClear();
    vi.mocked(mockSession.flash).mockClear();
  });

  afterEach(() => {
    process.env = originalEnv;
    // No need to clear mocks here if cleared in beforeEach
  });

  // Helper to create mock args
  const createMockArgs = (method = "GET"): LoaderFunctionArgs => ({
    request: new Request(`http://localhost/signup`, { // Use signup URL
      method,
      headers: new Headers(),
    }),
    params: {},
    context: {},
  });


  // Helper to construct the expected redirect URL base (without state)
  const getExpectedRedirectUrl = (screenHint?: string) => {
    const params = new URLSearchParams({
      client_id: mockEnv.AUTH0_CLIENT_ID,
      redirect_uri: mockEnv.AUTH0_CALLBACK_URL,
      response_type: "code",
      scope: "openid profile email",
    });
    // State is dynamic, so we only check the base URL
    if (screenHint) params.set("screen_hint", screenHint);

    return `https://${mockEnv.AUTH0_DOMAIN}/authorize?${params.toString()}`;
  };

  describe("loader", () => {
    it("should redirect to Auth0 with state, screen_hint, and set-cookie header", async () => {
      // Arrange
      const args = createMockArgs(); // Use helper to create args
      const expectedUrlBase = getExpectedRedirectUrl("signup"); // Base URL with hint
      // Mocks are now configured globally via vi.mock above

      // Act
      // Loader returns the redirect response
      const response = await loader(args); // Pass args

      // Assert
      expect(response).toBeDefined();
      expect(response).toBeInstanceOf(Response);
      expect(response.status).toBe(302);
      const location = response.headers.get("Location");
      expect(location).toBeDefined();
      expect(location?.startsWith(expectedUrlBase)).toBe(true);
      expect(location).toContain("&state=");
      expect(location).toContain("&screen_hint=signup");
      expect(response.headers.get("Set-Cookie")).toBe("mock-cookie-value");
      // Use the imported mocked storage object for assertions
      expect(mockedSessionStorage.getSession).toHaveBeenCalledTimes(1);
      expect(mockedSessionStorage.commitSession).toHaveBeenCalledTimes(1);
      expect(mockSession.flash).toHaveBeenCalledWith('oauth2_state', expect.any(String));
    });

     // Invariant checks throw actual Errors
     it("should throw if AUTH0_DOMAIN is missing", async () => {
      delete process.env.AUTH0_DOMAIN;
      const args = createMockArgs(); // Pass args
      await expect(loader(args)).rejects.toThrow("AUTH0_DOMAIN must be set");
    });

     it("should throw if AUTH0_CLIENT_ID is missing", async () => {
      delete process.env.AUTH0_CLIENT_ID;
      const args = createMockArgs(); // Pass args
      await expect(loader(args)).rejects.toThrow("AUTH0_CLIENT_ID must be set");
    });

     it("should throw if AUTH0_CALLBACK_URL is missing", async () => {
      delete process.env.AUTH0_CALLBACK_URL;
      const args = createMockArgs(); // Pass args
      await expect(loader(args)).rejects.toThrow("AUTH0_CALLBACK_URL must be set");
    });
  });

  describe("action", () => {
     it("should redirect to Auth0 with state, screen_hint, and set-cookie header (same as loader)", async () => {
      // Arrange
      const args = createMockArgs("POST"); // Use POST method for action
      const expectedUrlBase = getExpectedRedirectUrl("signup"); // Base URL with hint
      // Mocks are configured globally

      // Act
      // Action also returns the redirect response
      const response = await action(args); // Pass args

       // Assert
      expect(response).toBeDefined();
      expect(response).toBeInstanceOf(Response);
      expect(response.status).toBe(302);
      const location = response.headers.get("Location");
      expect(location).toBeDefined();
      expect(location?.startsWith(expectedUrlBase)).toBe(true);
      expect(location).toContain("&state=");
      expect(location).toContain("&screen_hint=signup");
      expect(response.headers.get("Set-Cookie")).toBe("mock-cookie-value");
      // Use the imported mocked storage object for assertions
      expect(mockedSessionStorage.getSession).toHaveBeenCalledTimes(1);
      expect(mockedSessionStorage.commitSession).toHaveBeenCalledTimes(1);
      expect(mockSession.flash).toHaveBeenCalledWith('oauth2_state', expect.any(String));
    });
  });
});
