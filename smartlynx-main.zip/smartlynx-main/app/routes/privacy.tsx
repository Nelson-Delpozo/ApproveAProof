import type { MetaFunction } from "@remix-run/node";

export const meta: MetaFunction = () => {
  return [
    { title: "Privacy Policy | SmartLynx" },
    { name: "description", content: "SmartLynx Privacy Policy" },
  ];
};

// Basic Tailwind styling can be applied here or via a shared layout component
const containerClasses = "container mx-auto px-4 py-8 prose lg:prose-xl dark:prose-invert"; // Added dark:prose-invert
const headingClasses = "text-2xl font-bold mb-4"; // These might be overridden by prose
const subHeadingClasses = "text-xl font-semibold mt-6 mb-3"; // These might be overridden by prose
const paragraphClasses = "mb-4";
const listClasses = "list-disc list-inside mb-4";

export default function PrivacyPolicy() {
  return (
    <div className={containerClasses}>
      <h1 className={headingClasses}>Privacy Policy for SmartLynx</h1>
      <p className={paragraphClasses}>
        <strong>Last Updated: April 18, 2025</strong>
      </p>

      <p className={paragraphClasses}>
        Welcome to SmartLynx (&quot;us&quot;, &quot;we&quot;, or &quot;our&quot;). We operate the smartlynx.app website and the SmartLynx service (hereinafter referred to as the &quot;Service&quot;).
      </p>
      <p className={paragraphClasses}>
        This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy.
      </p>
      {/* <p className={paragraphClasses}>
        <strong>Disclaimer:</strong> This is a template Privacy Policy. It is essential to consult with a legal professional to ensure this policy meets all legal requirements and accurately reflects your data practices.
      </p> */}

      <h2 className={subHeadingClasses}>Information Collection and Use</h2>
      <p className={paragraphClasses}>
        We collect several different types of information for various purposes to provide and improve our Service to you.
      </p>

      <h3 className={subHeadingClasses}>Types of Data Collected</h3>

      <h4 className={subHeadingClasses}>Personal Data</h4>
      <p className={paragraphClasses}>
        While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to:
      </p>
      <ul className={listClasses}>
        <li>Email address</li>
        <li>First name and last name (if provided)</li>
        <li>Payment information (processed by Stripe, see below)</li>
        <li>Usage Data (see below)</li>
      </ul>

      <h4 className={subHeadingClasses}>Files You Upload</h4>
      <p className={paragraphClasses}>
        When you upload files to share via our Service, we store these files on secure cloud infrastructure (e.g., AWS S3 or similar). We do not access the content of your files except as necessary to provide the Service (e.g., generating thumbnails, streaming downloads) or as required by law.
      </p>

      <h4 className={subHeadingClasses}>Usage Data</h4>
      <p className={paragraphClasses}>
        We may also collect information on how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer&apos;s Internet Protocol address (e.g., IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers, link access information (views, downloads, approximate location based on IP address), and other diagnostic data.
      </p>

      <h4 className={subHeadingClasses}>Tracking & Cookies Data</h4>
      <p className={paragraphClasses}>
        We use cookies and similar tracking technologies to track the activity on our Service and hold certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service (e.g., session management).
      </p>

      <h2 className={subHeadingClasses}>Use of Data</h2>
      <p className={paragraphClasses}>
        SmartLynx uses the collected data for various purposes:
      </p>
      <ul className={listClasses}>
        <li>To provide and maintain the Service</li>
        <li>To notify you about changes to our Service</li>
        <li>To allow you to participate in interactive features of our Service when you choose to do so</li>
        <li>To provide customer care and support</li>
        <li>To provide analysis or valuable information (like link analytics) so that we can improve the Service</li>
        <li>To monitor the usage of the Service</li>
        <li>To detect, prevent and address technical issues</li>
        <li>To process payments for subscription services</li>
      </ul>

      <h2 className={subHeadingClasses}>Payment Processing</h2>
      <p className={paragraphClasses}>
        We use Stripe, Inc. (&quot;Stripe&quot;) for payment processing. We do not store your full credit card details on our servers. When you provide payment information, it is sent directly to Stripe. Stripe&apos;s use of your personal information is governed by their Privacy Policy, which can be viewed at <a href="https://stripe.com/privacy" target="_blank" rel="noopener noreferrer">https://stripe.com/privacy</a>. We store information provided by Stripe related to your subscription status and customer ID to manage your account plan.
      </p>

      <h2 className={subHeadingClasses}>Transfer Of Data</h2>
      <p className={paragraphClasses}>
        Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ from those from your jurisdiction. If you are located outside the United States and choose to provide information to us, please note that we transfer the data, including Personal Data, to the United States and process it there. Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.
      </p>
      <p className={paragraphClasses}>
        SmartLynx will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.
      </p>

      <h2 className={subHeadingClasses}>Disclosure Of Data</h2>
      <h3 className={subHeadingClasses}>Legal Requirements</h3>
      <p className={paragraphClasses}>
        SmartLynx may disclose your Personal Data in the good faith belief that such action is necessary to:
      </p>
      <ul className={listClasses}>
        <li>To comply with a legal obligation</li>
        <li>To protect and defend the rights or property of SmartLynx</li>
        <li>To prevent or investigate possible wrongdoing in connection with the Service</li>
        <li>To protect the personal safety of users of the Service or the public</li>
        <li>To protect against legal liability</li>
      </ul>

      <h2 className={subHeadingClasses}>Security of Data</h2>
      <p className={paragraphClasses}>
        The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data and uploaded files (e.g., encryption, access controls), we cannot guarantee its absolute security.
      </p>

      <h2 className={subHeadingClasses}>Service Providers</h2>
      <p className={paragraphClasses}>
        We may employ third-party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used. These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose. Examples include cloud hosting providers (e.g., AWS, Vercel), payment processors (Stripe), and email delivery services.
      </p>

      <h2 className={subHeadingClasses}>Links To Other Sites</h2>
      <p className={paragraphClasses}>
        Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party&apos;s site. We strongly advise you to review the Privacy Policy of every site you visit. We have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.
      </p>

      <h2 className={subHeadingClasses}>Children&apos;s Privacy</h2>
      <p className={paragraphClasses}>
        Our Service does not address anyone under the age of 13 (&quot;Children&quot;). We do not knowingly collect personally identifiable information from anyone under the age of 13. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.
      </p>

      <h2 className={subHeadingClasses}>Changes To This Privacy Policy</h2>
      <p className={paragraphClasses}>
        We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. We will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;Last Updated&quot; date at the top of this Privacy Policy. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
      </p>

      <h2 className={subHeadingClasses}>Contact Us</h2>
      <p className={paragraphClasses}>
        If you have any questions about this Privacy Policy, please contact us: linkshare@smartlynx.app
      </p>
    </div>
  );
}
