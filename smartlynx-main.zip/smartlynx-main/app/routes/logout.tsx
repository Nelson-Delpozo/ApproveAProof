import type { LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import invariant from "tiny-invariant";

import { destroyAuthSession } from "~/auth.server"; // Use our session helper

// This route handles logging the user out, both locally and from Auth0.
export async function loader({ request }: LoaderFunctionArgs) {
  invariant(process.env.AUTH0_DOMAIN, "AUTH0_DOMAIN must be set");
  invariant(process.env.AUTH0_CLIENT_ID, "AUTH0_CLIENT_ID must be set");
  invariant(process.env.AUTH0_LOGOUT_URL, "AUTH0_LOGOUT_URL must be set"); // Where Auth0 redirects after logout

  // Construct the Auth0 logout URL
  const params = new URLSearchParams({
    client_id: process.env.AUTH0_CLIENT_ID,
    returnTo: process.env.AUTH0_LOGOUT_URL, // URL to redirect to after Auth0 logout is complete
  });
  const auth0LogoutUrl = `https://${process.env.AUTH0_DOMAIN}/v2/logout?${params.toString()}`;

  // Destroy the local Remix session first
  const headers = new Headers();
  headers.append("Set-Cookie", await destroyAuthSession(request));

  // Redirect the user to Auth0's logout endpoint
  return redirect(auth0LogoutUrl, { headers });
}

// Action function can also trigger logout if needed
export async function action({ request }: LoaderFunctionArgs) {
    return loader({ request, context: {}, params: {} });
}

// No default export needed.
