import { randomBytes } from "node:crypto"; // Import for state generation

import { redirect, type LoaderFunctionArgs } from "@remix-run/node"; // Add LoaderFunctionArgs
import invariant from "tiny-invariant";

import { sessionStorage } from "~/session.server"; // Import session storage

// This route specifically initiates the Auth0 flow with a hint to show the sign-up screen.
export async function loader({ request }: LoaderFunctionArgs) { // Add request parameter
  invariant(process.env.AUTH0_DOMAIN, "AUTH0_DOMAIN must be set");
  invariant(process.env.AUTH0_CLIENT_ID, "AUTH0_CLIENT_ID must be set");
  invariant(process.env.AUTH0_CALLBACK_URL, "AUTH0_CALLBACK_URL must be set");

  // Get session to store state
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));

  // Generate random state for CSRF protection
  const state = randomBytes(32).toString("hex");
  session.flash("oauth2_state", state); // Store state in flash session

  // Manually construct the Auth0 authorization URL with screen_hint
  const params = new URLSearchParams({
    client_id: process.env.AUTH0_CLIENT_ID,
    redirect_uri: process.env.AUTH0_CALLBACK_URL,
    response_type: "code", // Using Authorization Code Flow
    scope: "openid profile email", // Request basic user info + email
    screen_hint: "signup", // Add hint to show signup page
    state: state, // Add generated state to parameters
  });

  const authorizeUrl = `https://${process.env.AUTH0_DOMAIN}/authorize?${params.toString()}`;

  // Redirect the user to the constructed Auth0 Universal Login URL, committing the session
  return redirect(authorizeUrl, {
    status: 302,
    headers: {
      "Set-Cookie": await sessionStorage.commitSession(session), // Commit session with state
    },
  });
}

// Action function: Handles POST requests (optional)
export async function action(args: LoaderFunctionArgs) { // Use full args
  // In case someone POSTs here, redirect same as GET
  return loader(args); // Pass full args
}

// No default export needed as this route only performs redirects.
