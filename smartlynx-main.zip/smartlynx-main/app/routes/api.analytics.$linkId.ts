import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import invariant from "tiny-invariant";

import { getAuthSession } from "~/auth.server";
import { getAnalyticsEventsForLink } from "~/models/analytics.server";

const DEFAULT_PAGE_SIZE = 20;

export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await getAuthSession(request);
  if (!user) {
    // Must be logged in to fetch analytics
    throw new Response("Unauthorized", { status: 401 });
  }

  invariant(params.linkId, "Missing linkId parameter");
  const { linkId } = params;

  // Get page number from query parameters, default to 1
  const url = new URL(request.url);
  const page = parseInt(url.searchParams.get("page") || "1", 10);
  const pageSize = parseInt(url.searchParams.get("pageSize") || `${DEFAULT_PAGE_SIZE}`, 10);

  if (isNaN(page) || page < 1) {
    throw new Response("Invalid page number", { status: 400 });
  }
  if (isNaN(pageSize) || pageSize < 1) {
      throw new Response("Invalid page size", { status: 400 });
    }

  try {
    const result = await getAnalyticsEventsForLink(user.id, linkId, page, pageSize);

    if (!result) {
      // Either link doesn't exist or doesn't belong to user
      throw new Response("Analytics data not found or forbidden", { status: 404 });
    }

    // Return the paginated events and total count
    // Dates will be automatically serialized to strings by json()
    return json(result);
  } catch (error) {
    console.error(`Failed to load analytics for link ${linkId}, page ${page}:`, error);
    
    // If the error is already a Response (like our 404 response), re-throw it
    if (error instanceof Response) {
      throw error;
    }
    
    // For other errors, re-throw the original error to match test expectations
    // This allows the error boundary to handle it appropriately
    throw error;
  }
}
