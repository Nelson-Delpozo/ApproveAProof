import { type Session, type SessionStorage } from "@remix-run/node"; // Add SessionStorage type, remove unused redirect
import { jwtDecode } from "jwt-decode";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest"; // Add afterEach, remove unused Mock type
import { mockDeep, mock, mockReset } from "vitest-mock-extended"; // Add mockReset

import {
  getAuth0AuthenticationClient, // Import the getter function
  findOrCreateUserByAuthProfile,
  setAuthSession,
} from "~/auth.server";
import { sessionStorage } from "~/session.server"; // Keep this import for type casting

import { loader } from "./callback"; // Import the loader function

// --- Mock Dependencies ---
vi.mock("jwt-decode");

// Mock the entire auth.server module
vi.mock("~/auth.server");

// Mock the session storage module
vi.mock("~/session.server", () => ({
  // Provide a mock implementation for sessionStorage
  sessionStorage: mockDeep<SessionStorage>(), // Use SessionStorage type
}));

// Prisma is mocked globally via setup-test-env.ts

// --- Typed Mocks ---
const mockedJwtDecode = vi.mocked(jwtDecode);
const mockedFindOrCreateUser = vi.mocked(findOrCreateUserByAuthProfile);
const mockedSetAuthSession = vi.mocked(setAuthSession);
// Cast the globally mocked sessionStorage to its mocked type
const mockedSessionStorage = sessionStorage as unknown as ReturnType<typeof mockDeep<SessionStorage>>;
const mockedGetAuth0Client = vi.mocked(getAuth0AuthenticationClient);

// --- Mock Auth0 Client Instance ---
// Create a mock instance for the AuthenticationClient's relevant parts
const mockAuthClientInstance = {
  oauth: {
    authorizationCodeGrant: vi.fn(),
  },
  // Add other methods if needed by the loader
};

// Mock data
const mockCode = "valid-auth-code";
const mockIdToken = "mock.id.token";
const mockAccessToken = "mock.access.token";
const mockDecodedToken = {
  sub: "auth0|user123",
  email: "callback@example.com",
  email_verified: true,
  name: "Callback User",
};
const mockUser = {
  id: "db-user-id-42",
  email: mockDecodedToken.email,
  auth0Sub: mockDecodedToken.sub,
  createdAt: new Date(), // Keep dates for type consistency if needed
  updatedAt: new Date(),
  stripeCustomerId: null,
  stripeSubscriptionId: null,
  stripeSubscriptionStatus: null,
  plan: "FREE", // Default plan
};
const mockSession = mock<Session>(); // Mock Session object
const mockCookie = "mock-session-cookie"; // Mock cookie string

describe("Callback Route Loader", () => {
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    // Reset all mocks (including Prisma from global setup)
    mockReset(mockedSessionStorage); // Reset deep mock
    vi.resetAllMocks(); // Reset standard vi mocks

    // --- Setup Mocks for Each Test ---
    // Mock the getter to return our specific mock instance
    // Cast the instance to the expected return type of the getter
    mockedGetAuth0Client.mockReturnValue(
      mockAuthClientInstance as unknown as ReturnType<typeof getAuth0AuthenticationClient>
    );

    // Default mock for getSession returning a basic mock session
    mockedSessionStorage.getSession.mockResolvedValue(mockSession);
    // Default mock for commitSession
    mockedSessionStorage.commitSession.mockResolvedValue(mockCookie);
    // Default mock for setAuthSession returning the same mock session
    mockedSetAuthSession.mockResolvedValue(mockSession);
    // Default mock for session.get (can be overridden)
    vi.mocked(mockSession.get).mockReturnValue(null);
    // Remove default mock for session.flash as it's causing TS errors and session.get is used instead

    // Store original env and set mock env
    originalEnv = { ...process.env }; // Clone original env
    // Set necessary env vars for the loader
    process.env = {
      ...process.env, // Keep existing test env vars
      AUTH0_CALLBACK_URL: "http://localhost:3000/callback",
      // Ensure other Auth0 vars are present if getAuth0AuthenticationClient checks them
      AUTH0_DOMAIN: "test-domain.auth0.com",
      AUTH0_CLIENT_ID: "test-client-id",
      AUTH0_CLIENT_SECRET: "test-secret",
    };
  });

  afterEach(() => {
    // Restore original env
    process.env = originalEnv;
  });

  // Helper to create Request object
  const createRequest = (url: string, cookie?: string) => {
    const headers = new Headers();
    if (cookie) {
      headers.set("Cookie", cookie);
    }
    return new Request(url, { headers });
  };

  it("should redirect to login with error if code is missing in URL", async () => {
    // Arrange
    const request = createRequest("http://localhost:3000/callback?error=missing_code", mockCookie);
    // No specific mocks needed as it should redirect early

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe("/login?error=callback_failed");
  });

  it("should redirect to login with error if state is missing in URL", async () => {
    // Arrange
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue("session-state-value"); // Session has state
    // Act
    const response = await loader({ request, params: {}, context: {} });
    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe("/login?error=invalid_state");
    // Check that commitSession was called to clear the invalid state
    expect(mockedSessionStorage.commitSession).toHaveBeenCalledWith(mockSession);
  });

  it("should redirect to login with error if state is missing in session", async () => {
    // Arrange
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=url-state-value`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(null); // Session has no state
    // Act
    const response = await loader({ request, params: {}, context: {} });
    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe("/login?error=invalid_state");
    expect(mockedSessionStorage.commitSession).toHaveBeenCalledWith(mockSession);
  });

  it("should redirect to login with error if state mismatch", async () => {
    // Arrange
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=url-state-value`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue("different-session-state"); // State mismatch
    // Act
    const response = await loader({ request, params: {}, context: {} });
    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe("/login?error=invalid_state");
    expect(mockedSessionStorage.commitSession).toHaveBeenCalledWith(mockSession);
  });


  it("should redirect to login with error if token exchange fails", async () => {
    // Arrange
    const mockState = "state-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(mockState); // Valid state
    const exchangeError = new Error("Invalid grant");
    // Mock the specific method on the instance returned by the getter
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockRejectedValue(exchangeError);

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/login?error=${encodeURIComponent(exchangeError.message)}`);
    expect(mockAuthClientInstance.oauth.authorizationCodeGrant).toHaveBeenCalledWith({
        code: mockCode,
        redirect_uri: process.env.AUTH0_CALLBACK_URL,
    });
  });

  it("should redirect to login with error if ID token is missing", async () => {
    // Arrange
    const mockState = "state-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(mockState); // Valid state
    // Simulate response without id_token
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockResolvedValue({
        // Omit 'data' or provide it without id_token
        // The actual structure might depend on the auth0 library version
        data: { access_token: mockAccessToken, token_type: 'Bearer', expires_in: 3600 },
        // Add other required fields if the library expects them (e.g., status, headers)
        status: 200, headers: new Headers(), statusText: "OK"
    });

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/login?error=${encodeURIComponent("ID token missing from Auth0 response.")}`);
  });

   it("should redirect to login with error if decoded token is missing required fields", async () => {
    // Arrange
    const mockState = "state-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(mockState); // Valid state
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockResolvedValue({
        data: { id_token: mockIdToken, access_token: mockAccessToken, token_type: 'Bearer', expires_in: 3600 },
        status: 200, headers: new Headers(), statusText: "OK"
    });
    mockedJwtDecode.mockReturnValue({ sub: "auth0|onlysub" }); // Missing email

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/login?error=${encodeURIComponent("Decoded ID token is missing required fields (sub or email).")}`);
    expect(mockedJwtDecode).toHaveBeenCalledWith(mockIdToken);
  });

  it("should redirect to login with error if findOrCreateUser fails", async () => {
    // Arrange
    const mockState = "state-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(mockState); // Valid state
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockResolvedValue({
        data: { id_token: mockIdToken, access_token: mockAccessToken, token_type: 'Bearer', expires_in: 3600 },
        status: 200, headers: new Headers(), statusText: "OK"
    });
    mockedJwtDecode.mockReturnValue(mockDecodedToken);
    const dbError = new Error("DB connection failed");
    mockedFindOrCreateUser.mockRejectedValue(dbError);

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/login?error=${encodeURIComponent(dbError.message)}`);
    expect(mockedFindOrCreateUser).toHaveBeenCalledWith(mockDecodedToken.email, mockDecodedToken.sub);
  });

   it("should redirect to login with error if findOrCreateUser returns null", async () => {
    // Arrange
    const mockState = "state-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    vi.mocked(mockSession.get).mockReturnValue(mockState); // Valid state
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockResolvedValue({
        data: { id_token: mockIdToken, access_token: mockAccessToken, token_type: 'Bearer', expires_in: 3600 },
        status: 200, headers: new Headers(), statusText: "OK"
    });
    mockedJwtDecode.mockReturnValue(mockDecodedToken);
    // Explicitly cast null through unknown for the mock
    mockedFindOrCreateUser.mockResolvedValue(null as unknown as Awaited<ReturnType<typeof findOrCreateUserByAuthProfile>>);

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/login?error=${encodeURIComponent("Failed to find or create user in the database during callback.")}`);
  });


  it("should set session, commit, and redirect to / on success", async () => {
    // Arrange
    const mockState = "random-state-value-123";
    const request = createRequest(`http://localhost:3000/callback?code=${mockCode}&state=${mockState}`, mockCookie);
    // Mock session.get specifically for 'oauth2_state'
    vi.mocked(mockSession.get).mockImplementation((key: string) => {
      if (key === 'oauth2_state') {
        return mockState; // Return the correct state
      }
      return null; // Default for other keys
    });

    // Mock successful token exchange
    mockAuthClientInstance.oauth.authorizationCodeGrant.mockResolvedValue({
        data: { id_token: mockIdToken, access_token: mockAccessToken, token_type: 'Bearer', expires_in: 3600 },
        status: 200, headers: new Headers(), statusText: "OK"
    });
    // Mock successful token decoding
    mockedJwtDecode.mockReturnValue(mockDecodedToken);
    // Mock successful user find/create
    mockedFindOrCreateUser.mockResolvedValue(mockUser);
    // setAuthSession and commitSession are mocked in beforeEach to return mockSession/mockCookie

    // Act
    const response = await loader({ request, params: {}, context: {} });

    // Assert
    // Verify mocks were called correctly
    expect(mockAuthClientInstance.oauth.authorizationCodeGrant).toHaveBeenCalledWith({ code: mockCode, redirect_uri: process.env.AUTH0_CALLBACK_URL });
    expect(mockedJwtDecode).toHaveBeenCalledWith(mockIdToken);
    expect(mockedFindOrCreateUser).toHaveBeenCalledWith(mockDecodedToken.email, mockDecodedToken.sub);
    expect(mockedSetAuthSession).toHaveBeenCalledWith(request, mockUser); // Ensure request object is passed
    expect(mockedSessionStorage.commitSession).toHaveBeenCalledWith(mockSession); // Ensure the session returned by setAuthSession is committed

    // Check the redirect response
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe("/dashboard");
    expect(response.headers.get("Set-Cookie")).toBe(mockCookie);
  });

  // TODO: Add test for redirecting to original destination if implemented
});
