import { S3Client } from "@aws-sdk/client-s3"; // AWS SDK first
import { createPresignedPost } from "@aws-sdk/s3-presigned-post";
import { type ActionFunctionArgs } from "@remix-run/node"; // Remix types next (remove unused json, createCookieSessionStorage)
// Remove unused invariant import
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest"; // Testing utils

import * as authServer from "~/auth.server"; // Local mocks/imports last

import { action } from "./presign-upload"; // Import the action function

// Mock the S3 presigner function
vi.mock("@aws-sdk/s3-presigned-post", () => ({
  createPresignedPost: vi.fn(),
}));

// Mock the auth server function
vi.mock("~/auth.server");

// Mock environment variables
const mockEnv = {
  AWS_S3_BUCKET_NAME: "test-bucket",
  AWS_REGION: "test-region",
  AWS_ACCESS_KEY_ID: "test-key-id",
  AWS_SECRET_ACCESS_KEY: "test-secret-key",
  SESSION_SECRET: "test-session-secret", // Needed if auth relies on session
};

// NOTE: We cannot mock process.env before the module containing invariants is loaded.
// The invariant checks and S3 client instantiation MUST be inside the action function
// in the actual route file (presign-upload.tsx) for this test setup to work correctly
// without relying on global test setup files modifying process.env early.

describe("/presign-upload Action", () => {
  let originalEnv: NodeJS.ProcessEnv;

  beforeEach(() => {
    originalEnv = process.env;
    // Set env vars needed INSIDE the action function
    process.env = {
        ...originalEnv,
        AWS_S3_BUCKET_NAME: mockEnv.AWS_S3_BUCKET_NAME,
        AWS_REGION: mockEnv.AWS_REGION,
        AWS_ACCESS_KEY_ID: mockEnv.AWS_ACCESS_KEY_ID,
        AWS_SECRET_ACCESS_KEY: mockEnv.AWS_SECRET_ACCESS_KEY,
     };
    vi.clearAllMocks(); // Clear mocks
  });

  afterEach(() => {
    process.env = originalEnv;
  });

  // Helper to create mock args with authenticated user
  const createMockArgs = async (formData: FormData): Promise<ActionFunctionArgs> => {
    const request = new Request("http://localhost/presign-upload", {
      method: "POST",
      body: formData,
      headers: new Headers(), // Headers needed for session potentially
    });
    // Mock getAuthSession to return a valid user
    vi.mocked(authServer.getAuthSession).mockResolvedValue({
      id: "user-123", // Mock user ID
      email: "test@example.com",
      auth0Sub: "auth0|abc",
      // Remove createdAt and updatedAt as they are not returned by the actual function
    });
    return { request, params: {}, context: {} };
  };

   // Helper to create mock args for unauthenticated user
  const createUnauthMockArgs = async (formData: FormData): Promise<ActionFunctionArgs> => {
    const request = new Request("http://localhost/presign-upload", {
      method: "POST",
      body: formData,
      headers: new Headers(),
    });
     // Mock getAuthSession to return null
    vi.mocked(authServer.getAuthSession).mockResolvedValue(null);
    return { request, params: {}, context: {} };
  };


  it("should return 401 Unauthorized if user is not authenticated", async () => {
    const formData = new FormData();
    formData.append("filename", "test.jpg");
    formData.append("contentType", "image/jpeg");
    const args = await createUnauthMockArgs(formData);

    const response = await action(args);
    const responseJson = await response.json() as { error?: string }; // Type assertion

    expect(response.status).toBe(401);
    expect(responseJson.error).toBe("Unauthorized");
  });

  it("should return 400 if filename is missing", async () => {
    const formData = new FormData();
    // formData.append("filename", "test.jpg"); // Missing filename
    formData.append("contentType", "image/jpeg");
    const args = await createMockArgs(formData);

    const response = await action(args);
    const responseJson = await response.json() as { error?: string }; // Type assertion

    expect(response.status).toBe(400);
    expect(responseJson.error).toBe("Filename is required.");
  });

  it("should return 400 if contentType is missing", async () => {
    const formData = new FormData();
    formData.append("filename", "test.jpg");
    // formData.append("contentType", "image/jpeg"); // Missing contentType
    const args = await createMockArgs(formData);

    const response = await action(args);
    const responseJson = await response.json() as { error?: string }; // Type assertion

    expect(response.status).toBe(400);
    expect(responseJson.error).toBe("Content type is required.");
  });

  it("should return presigned URL and fields on success", async () => {
    const formData = new FormData();
    const filename = "test-image.png";
    const contentType = "image/png";
    formData.append("filename", filename);
    formData.append("contentType", contentType);
    const args = await createMockArgs(formData);

    const mockPresignedData = {
      url: "https://test-bucket.s3.test-region.amazonaws.com/",
      fields: {
        key: `user-uploads/user-123/some-uuid-${filename}`,
        "Content-Type": contentType,
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        // ... other fields
      },
    };
    // Mock the presigner function's return value
    vi.mocked(createPresignedPost).mockResolvedValue(mockPresignedData);

    const response = await action(args);
    // Type assertion for the success case
    const responseJson = await response.json() as { url: string; fields: Record<string, string>; key: string; error?: string };

    expect(response.status).toBe(200);
    // Check for success properties
    expect(responseJson.url).toBe(mockPresignedData.url);
    expect(responseJson.fields).toEqual(mockPresignedData.fields);
    expect(responseJson.key).toBeDefined();
    expect(responseJson.key).toContain(`user-uploads/user-123/`);
    expect(responseJson.key).toContain(`-${filename}`);

    // Verify createPresignedPost was called with expected parameters
    expect(createPresignedPost).toHaveBeenCalledWith(
      expect.any(S3Client), // Check if an S3Client instance was passed
      expect.objectContaining({
        Bucket: mockEnv.AWS_S3_BUCKET_NAME,
        Key: expect.stringContaining(`user-uploads/user-123/`),
        Conditions: expect.any(Array),
        Fields: expect.objectContaining({ "Content-Type": contentType }),
        Expires: 600,
      })
    );
  });

   it("should return 500 if createPresignedPost fails", async () => {
    const formData = new FormData();
    formData.append("filename", "test.jpg");
    formData.append("contentType", "image/jpeg");
    const args = await createMockArgs(formData);

    // Mock the presigner function to throw an error
    const testError = new Error("S3 Error");
    vi.mocked(createPresignedPost).mockRejectedValue(testError);

    const response = await action(args);
    const responseJson = await response.json() as { error?: string }; // Type assertion

    expect(response.status).toBe(500);
    expect(responseJson.error).toBe("Failed to prepare upload.");
  });

});
