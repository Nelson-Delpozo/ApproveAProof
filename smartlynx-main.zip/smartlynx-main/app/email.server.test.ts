import sgMail from "@sendgrid/mail";
import { vi, describe, it, expect, beforeEach } from "vitest";

import { sendEmail } from "../app/email.server"; // Adjust path as necessary

// Mock the @sendgrid/mail module
vi.mock("@sendgrid/mail", () => {
  return {
    default: {
      setApiKey: vi.fn(),
      send: vi.fn(), // Mock the send function
    },
  };
});

// Mock tiny-invariant as it checks process.env which might not be set in test
// Or ensure SENDGRID_API_KEY is set in test environment (e.g., via setup file or .env.test)
// For simplicity here, we'll assume the invariant check passes or is handled by test setup
vi.mock("tiny-invariant");

describe("sendEmail", () => {
  const mockSend = vi.mocked(sgMail.send); // Get a typed mock function

  beforeEach(() => {
    // Reset mocks before each test
    vi.clearAllMocks();
  });

  it("should call sgMail.send with correct parameters", async () => {
    const emailOptions = {
      to: "recipient@example.com",
      from: "sender@example.com",
      subject: "Test Subject",
      text: "Test text content",
      html: "<p>Test HTML content</p>",
    };

    // Simulate successful sending - sgMail.send resolves with [ClientResponse, {}]
    mockSend.mockResolvedValueOnce([
      { statusCode: 202, body: {}, headers: {} }, // Changed body from "" to {}
      {},
    ]);

    await sendEmail(emailOptions);

    expect(mockSend).toHaveBeenCalledTimes(1);
    expect(mockSend).toHaveBeenCalledWith({
      to: emailOptions.to,
      from: emailOptions.from,
      subject: emailOptions.subject,
      text: emailOptions.text,
      html: emailOptions.html,
    });
  });

  it("should throw an error if sgMail.send fails", async () => {
    const emailOptions = {
      to: "recipient@example.com",
      from: "sender@example.com",
      subject: "Test Failure Subject",
      text: "Test failure content",
    };
    const testError = new Error("SendGrid API Error");

    // Simulate failed sending
    mockSend.mockRejectedValueOnce(testError);

    await expect(sendEmail(emailOptions)).rejects.toThrow(
      "Failed to send email."
    );

    expect(mockSend).toHaveBeenCalledTimes(1);
    expect(mockSend).toHaveBeenCalledWith({
      to: emailOptions.to,
      from: emailOptions.from,
      subject: emailOptions.subject,
      text: emailOptions.text,
      html: undefined, // html is optional
    });
  });

  // Optional: Test if setApiKey was called (though it happens at module load)
  // it('should call sgMail.setApiKey on module load', () => {
  //   // Note: This assertion might be tricky depending on how module loading and mocks interact
  //   // It might require importing the module *within* the test or using dynamic imports.
  //   // For now, we trust the module-level code executes.
  //   const mockSetApiKey = vi.mocked(sgMail.setApiKey);
  //   expect(mockSetApiKey).toHaveBeenCalled(); // This might not work reliably here
  // });
});
