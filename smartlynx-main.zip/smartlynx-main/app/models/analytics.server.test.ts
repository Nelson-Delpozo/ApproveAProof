import type { PrismaClient as AnalyticsPrismaClient, AnalyticsEvent } from "@prisma/analytics-client"; // Analytics client types
import type { PrismaClient as MainPrismaClient, SharedLink } from "@prisma/client"; // Main client types
import { vi, describe, it, expect, beforeEach } from "vitest";
import { mockDeep, mockReset } from "vitest-mock-extended";

// Mock the ANALYTICS Prisma client module
vi.mock("~/analytics.db.server", () => ({
  prismaAnalytics: mockDeep<AnalyticsPrismaClient>(),
}));

// Mock the MAIN Prisma client module
vi.mock("~/db.server", () => ({
  prisma: mockDeep<MainPrismaClient>(),
}));

// Import the module under test *after* mocks are set up
import { prismaAnalytics } from "~/analytics.db.server"; // Mocked analytics client
import { prisma } from "~/db.server"; // Mocked main client

import {
  recordLinkViewEvent,
  recordLinkShareEvent, // Import missing function
  recordLinkDownloadEvent, // Import new function
  getAnalyticsEventsForLink,
  getAnalyticsEventCountsForLink, // + Import the function to test
} from "./analytics.server";

// Mock console.error to spy on it
// eslint-disable-next-line @typescript-eslint/no-empty-function -- We just want to spy on calls, not log during tests
const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

describe("Analytics Model Functions", () => {
  let mockPrisma: ReturnType<typeof mockDeep<MainPrismaClient>>;
  let mockPrismaAnalytics: ReturnType<typeof mockDeep<AnalyticsPrismaClient>>;

  beforeEach(() => {
    // Assign mocks before each test
    mockPrisma = prisma as unknown as typeof mockPrisma;
    mockPrismaAnalytics = prismaAnalytics as unknown as typeof mockPrismaAnalytics;
    mockReset(mockPrisma);
    mockReset(mockPrismaAnalytics);
    consoleErrorSpy.mockClear();
  });

  // --- Event Recording Tests ---

  describe("recordLinkViewEvent", () => {
    const linkId = "test-link-id";

    it("should create a VIEW analytics event with correct data", async () => {
      const mockCreatedEvent: Partial<AnalyticsEvent> = { id: "new-event-id" };
      mockPrismaAnalytics.analyticsEvent.create.mockResolvedValue(
        mockCreatedEvent as AnalyticsEvent,
      );

      await recordLinkViewEvent(linkId);

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledWith({
        data: {
          type: "VIEW",
          linkId: linkId,
        },
      });
      expect(consoleErrorSpy).not.toHaveBeenCalled();
    });

    it("should catch and log errors without throwing", async () => {
      const testError = new Error("Analytics DB connection failed");
      mockPrismaAnalytics.analyticsEvent.create.mockRejectedValue(testError);

      await expect(recordLinkViewEvent(linkId)).resolves.toBeUndefined();

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledWith(
        `Failed to record analytics event for link ${linkId}:`,
        testError,
      );
    });
  });

  describe("recordLinkShareEvent", () => {
    const linkId = "test-link-id-share";
    const recipientEmail = "test@example.com";

    it("should create a SHARE analytics event with correct data", async () => {
      const mockCreatedEvent: Partial<AnalyticsEvent> = { id: "share-event-id" };
      mockPrismaAnalytics.analyticsEvent.create.mockResolvedValue(
        mockCreatedEvent as AnalyticsEvent,
      );

      await recordLinkShareEvent(linkId, recipientEmail);

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledWith({
        data: {
          type: "SHARE",
          linkId: linkId,
          recipientEmail: recipientEmail,
        },
      });
      expect(consoleErrorSpy).not.toHaveBeenCalled();
    });

    it("should catch and log errors without throwing", async () => {
      const testError = new Error("Analytics DB connection failed");
      mockPrismaAnalytics.analyticsEvent.create.mockRejectedValue(testError);

      await expect(
        recordLinkShareEvent(linkId, recipientEmail),
      ).resolves.toBeUndefined();

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledWith(
        `Failed to record share event for link ${linkId} to ${recipientEmail}:`,
        testError,
      );
    });
  });

  describe("recordLinkDownloadEvent", () => {
    const linkId = "test-link-id-download";

    it("should create a DOWNLOAD analytics event with correct data", async () => {
      const mockCreatedEvent: Partial<AnalyticsEvent> = { id: "dl-event-id" };
      mockPrismaAnalytics.analyticsEvent.create.mockResolvedValue(
        mockCreatedEvent as AnalyticsEvent,
      );

      await recordLinkDownloadEvent(linkId);

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledWith({
        data: {
          type: "DOWNLOAD",
          linkId: linkId,
        },
      });
      expect(consoleErrorSpy).not.toHaveBeenCalled();
    });

    it("should catch and log errors without throwing", async () => {
      const testError = new Error("Analytics DB connection failed");
      mockPrismaAnalytics.analyticsEvent.create.mockRejectedValue(testError);

      await expect(recordLinkDownloadEvent(linkId)).resolves.toBeUndefined();

      expect(mockPrismaAnalytics.analyticsEvent.create).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledWith(
        `Failed to record download event for link ${linkId}:`,
        testError,
      );
    });
  });

  // --- Event Fetching Tests ---

  describe("getAnalyticsEventsForLink", () => {
    const userId = "user-owner-id";
    const otherUserId = "user-other-id";
    const sharedLinkId = "link-owned-by-user";
    // Mock SharedLink from main DB
    const mockLink: SharedLink = {
      id: sharedLinkId,
      userId: userId,
      originalFileName: "test.txt",
      storageKey: "test-key",
      fileType: "text/plain",
      fileSizeBytes: 123,
      accessKey: "access-key",
      description: null,
      expiresAt: null,
      revoked: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    // Mock AnalyticsEvent from analytics DB
    const mockEvents: Pick<
      AnalyticsEvent,
      "id" | "type" | "createdAt" | "recipientEmail"
    >[] = [
      {
        id: "event1",
        type: "VIEW",
        createdAt: new Date(),
        recipientEmail: null,
      },
      {
        id: "event2",
        type: "DOWNLOAD",
        createdAt: new Date(),
        recipientEmail: null,
      },
    ];
    const totalCount = 50;

    it("should return paginated events and total count for the correct user", async () => {
      // Mock main DB call for link ownership check
      mockPrisma.sharedLink.findUnique.mockResolvedValue(mockLink);
      // Mock the individual Prisma calls within the transaction
      mockPrismaAnalytics.analyticsEvent.findMany.mockResolvedValue(mockEvents as AnalyticsEvent[]);
      mockPrismaAnalytics.analyticsEvent.count.mockResolvedValue(totalCount);
      // Remove the $transaction mock implementation - rely on deep mock for findMany/count


      const page = 2;
      const pageSize = 10;
      const result = await getAnalyticsEventsForLink(
        userId,
        sharedLinkId,
        page,
        pageSize,
      );

      // Verify link check (main DB)
      expect(mockPrisma.sharedLink.findUnique).toHaveBeenCalledWith({
        where: { id: sharedLinkId },
        select: { userId: true },
      });

      // Verify the individual calls were made with correct args
      expect(mockPrismaAnalytics.analyticsEvent.findMany).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { linkId: sharedLinkId },
          select: {
            id: true,
            type: true,
            createdAt: true,
            recipientEmail: true,
          },
          orderBy: { createdAt: "desc" },
          skip: (page - 1) * pageSize,
          take: pageSize,
        }),
      );
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { linkId: sharedLinkId },
        }),
      );

       // Verify result structure
      expect(result).toEqual({
        events: mockEvents, // Should match the structure returned by the function
        totalCount: totalCount,
      });
    });

    it("should return null if link is not found", async () => {
      // Mock main DB call
      mockPrisma.sharedLink.findUnique.mockResolvedValue(null);

      const result = await getAnalyticsEventsForLink(
        userId,
        "non-existent-link-id",
      );

      expect(mockPrisma.sharedLink.findUnique).toHaveBeenCalledWith({
        where: { id: "non-existent-link-id" },
        select: { userId: true },
      });
      expect(mockPrismaAnalytics.$transaction).not.toHaveBeenCalled(); // Analytics DB not called
      expect(result).toBeNull();
    });

    it("should return null if link does not belong to the user", async () => {
      // Mock link belonging to a different user (main DB)
      const otherUserMockLink = { ...mockLink, userId: otherUserId };
      mockPrisma.sharedLink.findUnique.mockResolvedValue(otherUserMockLink);

      const result = await getAnalyticsEventsForLink(userId, sharedLinkId);

      expect(mockPrisma.sharedLink.findUnique).toHaveBeenCalledWith({
        where: { id: sharedLinkId },
        select: { userId: true },
      });
      expect(mockPrismaAnalytics.$transaction).not.toHaveBeenCalled(); // Analytics DB not called
      expect(result).toBeNull();
    });

    it("should use default pagination values if not provided", async () => {
      // Mock main DB call
      mockPrisma.sharedLink.findUnique.mockResolvedValue(mockLink);
      // Mock the individual Prisma calls
      mockPrismaAnalytics.analyticsEvent.findMany.mockResolvedValue(mockEvents as AnalyticsEvent[]);
      mockPrismaAnalytics.analyticsEvent.count.mockResolvedValue(totalCount);
      // Remove the $transaction mock implementation


      await getAnalyticsEventsForLink(userId, sharedLinkId); // Call with defaults

      // Verify the individual calls were made with default skip/take
      expect(mockPrismaAnalytics.analyticsEvent.findMany).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ skip: 0, take: 20 }), // Default page=1, pageSize=20
      );
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledTimes(1);
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith(
        expect.objectContaining({ where: { linkId: sharedLinkId } }),
      );
    });
  });

  // --- Tests for getAnalyticsEventCountsForLink ---
  describe("getAnalyticsEventCountsForLink", () => {
    const linkId = "test-link-id-counts";

    it("should return correct counts for VIEW, DOWNLOAD, and SHARE events", async () => {
      // Mock the count calls for each event type
      mockPrismaAnalytics.analyticsEvent.count
        .mockResolvedValueOnce(5) // VIEW count
        .mockResolvedValueOnce(3) // DOWNLOAD count
        .mockResolvedValueOnce(2); // SHARE count

      const counts = await getAnalyticsEventCountsForLink(linkId);

      expect(counts).toEqual({
        viewCount: 5,
        downloadCount: 3,
        shareCount: 2,
      });

      // Verify that prismaAnalytics.analyticsEvent.count was called for each type
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith({
        where: { linkId: linkId, type: "VIEW" },
      });
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith({
        where: { linkId: linkId, type: "DOWNLOAD" },
      });
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith({
        where: { linkId: linkId, type: "SHARE" },
      });
      expect(consoleErrorSpy).not.toHaveBeenCalled();
    });

    it("should return zero counts and log error if Prisma count fails", async () => {
      const testError = new Error("DB count failed");
      // Mock one of the count calls to reject
      mockPrismaAnalytics.analyticsEvent.count.mockRejectedValueOnce(testError);

      const counts = await getAnalyticsEventCountsForLink(linkId);

      expect(counts).toEqual({
        viewCount: 0,
        downloadCount: 0,
        shareCount: 0,
      });

      // It should have attempted the first count call
      expect(mockPrismaAnalytics.analyticsEvent.count).toHaveBeenCalledWith({
        where: { linkId: linkId, type: "VIEW" },
      });
      // It should have logged the error
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledWith(
        `Failed to fetch analytics counts for link ${linkId}:`,
        testError,
      );
    });
  });
});
