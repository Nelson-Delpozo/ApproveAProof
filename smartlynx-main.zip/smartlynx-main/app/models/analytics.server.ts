import type { AnalyticsEvent } from "@prisma/analytics-client"; // Import types

import { prismaAnalytics } from "~/analytics.db.server";
import { prisma } from "~/db.server"; // Keep for SharedLink check

/**
 * Records a 'VIEW' analytics event for a given shared link ID.
 * Includes error handling to prevent analytics failures from breaking link access.
 *
 * @param linkId - The ID of the SharedLink being viewed.
 */
export async function recordLinkViewEvent(linkId: string): Promise<void> {
  try {
    await prismaAnalytics.analyticsEvent.create({
      data: {
        type: "VIEW", // Use the enum value from the correct client
        linkId: linkId, // Directly set the linkId
        // timestamp is handled by @default(now()) in schema
        // ipAddress, userAgent etc. could be added here if available
      },
    });
    // Optional: Log success if needed for debugging
    // console.log(`Analytics event recorded for link ${linkId}`);
  } catch (error) {
    // Log the error, but do not re-throw.
    // Failing to record analytics should not prevent the user from accessing the link.
    console.error(`Failed to record analytics event for link ${linkId}:`, error);
  }
}

/**
 * Records a 'SHARE' analytics event for a given shared link ID.
 * Includes error handling.
 *
 * @param linkId - The ID of the SharedLink being shared.
 * @param recipientEmail - The email address the link was shared with.
 */
export async function recordLinkShareEvent(
  linkId: string,
  recipientEmail: string,
): Promise<void> {
  try {
    await prismaAnalytics.analyticsEvent.create({
      data: {
        type: "SHARE", // Use the enum value from the correct client
        recipientEmail: recipientEmail, // Store the recipient email
        linkId: linkId, // Directly set the linkId
        // timestamp is handled by @default(now()) in schema
        // ipAddress and userAgent could potentially be added here if available
      },
    });
  } catch (error) {
    console.error(
      `Failed to record share event for link ${linkId} to ${recipientEmail}:`,
      error,
    );
  }
}

/**
 * Records a 'DOWNLOAD' analytics event for a given shared link ID.
 * Includes error handling.
 *
 * @param linkId - The ID of the SharedLink being downloaded.
 */
export async function recordLinkDownloadEvent(linkId: string): Promise<void> {
  try {
    await prismaAnalytics.analyticsEvent.create({
      data: {
        type: "DOWNLOAD", // Use the enum value from the correct client
        linkId: linkId, // Directly set the linkId
        // timestamp is handled by @default(now()) in schema
        // ipAddress, userAgent etc. could be added here if available
      },
    });
  } catch (error) {
    console.error(
      `Failed to record download event for link ${linkId}:`,
      error,
    );
  }
}

/**
 * Fetches the counts of VIEW, DOWNLOAD, and SHARE events for a specific link ID
 * from the analytics database.
 *
 * @param linkId - The ID of the SharedLink to fetch counts for.
 * @returns An object containing the counts for each event type.
 */
export async function getAnalyticsEventCountsForLink(linkId: string): Promise<{
  viewCount: number;
  downloadCount: number;
  shareCount: number;
}> {
  try {
    // Use Promise.all to fetch counts concurrently
    const [viewCount, downloadCount, shareCount] = await Promise.all([
      prismaAnalytics.analyticsEvent.count({
        where: { linkId: linkId, type: "VIEW" },
      }),
      prismaAnalytics.analyticsEvent.count({
        where: { linkId: linkId, type: "DOWNLOAD" },
      }),
      prismaAnalytics.analyticsEvent.count({
        where: { linkId: linkId, type: "SHARE" },
      }),
    ]);
    return { viewCount, downloadCount, shareCount };
  } catch (error) {
    console.error(
      `Failed to fetch analytics counts for link ${linkId}:`,
      error,
    );
    // Return zero counts on error to avoid breaking the UI
    return { viewCount: 0, downloadCount: 0, shareCount: 0 };
  }
}

export interface GetAnalyticsEventsResult {
  // Export the interface
  events: Pick<
    AnalyticsEvent,
    "id" | "type" | "createdAt" | "recipientEmail"
  >[]; // Use T[] syntax for array type
  totalCount: number;
}

/**
 * Fetches paginated analytics events for a specific shared link,
 * ensuring the link belongs to the specified user.
 *
 * @param userId - The ID of the user requesting the events.
 * @param sharedLinkId - The ID of the SharedLink to fetch events for.
 * @param page - The page number (1-based). Defaults to 1.
 * @param pageSize - The number of events per page. Defaults to 20.
 * @returns An object containing the events for the page and the total count, or null if link doesn't belong to user.
 */
export async function getAnalyticsEventsForLink(
  userId: string,
  sharedLinkId: string,
  page = 1,
  pageSize = 20,
): Promise<GetAnalyticsEventsResult | null> {
  // First, verify the link belongs to the user using the main prisma client
  const link = await prisma.sharedLink.findUnique({
    where: { id: sharedLinkId },
    select: { userId: true }, // Only fetch userId for verification
  });

  if (!link || link.userId !== userId) {
    // Link not found or doesn't belong to the user
    return null;
  }

  const skip = (page - 1) * pageSize;
  const take = pageSize;

  try {
    // Instead of using $transaction, which is causing issues in tests,
    // let's use Promise.all to run the queries in parallel
    const [events, totalCount] = await Promise.all([
      prismaAnalytics.analyticsEvent.findMany({
        where: { linkId: sharedLinkId }, // Query by linkId
        select: {
          id: true,
          type: true, // Select 'type' instead of 'eventType'
          createdAt: true, // Use 'createdAt' which is the default timestamp
          recipientEmail: true,
        },
        orderBy: { createdAt: "desc" }, // Order by 'createdAt'
        skip: skip,
        take: take,
      }),
      prismaAnalytics.analyticsEvent.count({
        where: { linkId: sharedLinkId }, // Count by linkId
      }),
    ]);

    // The 'events' array from Prisma with the select clause already matches the required shape.
    return { events, totalCount };
  } catch (error) {
    console.error(
      `Failed to fetch paginated analytics events for link ${sharedLinkId} (user ${userId}):`,
      error,
    );
    // Return empty/zero values on error to avoid breaking the UI
    return { events: [], totalCount: 0 };
  }
}
