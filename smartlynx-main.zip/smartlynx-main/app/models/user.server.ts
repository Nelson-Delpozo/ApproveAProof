import type { User } from "@prisma/client";
// Removed bcrypt import

import { prisma } from "~/db.server";

export type { User } from "@prisma/client";

export async function getUserById(id: User["id"]) {
  return prisma.user.findUnique({ where: { id } });
}

export async function getUserByEmail(email: User["email"]) {
  return prisma.user.findUnique({ where: { email } });
}

// Updated createUser for testing purposes - allows setting plan/stripe details
export async function createUser(
  email: User["email"],
  password?: string, // Keep password arg for compatibility, though not used for hashing
  plan: User["plan"] = "FREE", // Add plan with default
  stripeSubscriptionStatus: User["stripeSubscriptionStatus"] = null, // Add status
  stripeSubscriptionId: User["stripeSubscriptionId"] = null, // Add sub ID
  auth0Sub?: User["auth0Sub"], // Keep optional auth0Sub
  stripeCustomerId: User["stripeCustomerId"] = null, // + Add stripeCustomerId
) {
  // Note: Password is not hashed here as Auth0 handles authentication.
  // This function is primarily for seeding test users with specific states.
  return prisma.user.create({
    data: {
      email,
      auth0Sub: auth0Sub ?? `auth0test|${email}`, // Provide a default mock auth0Sub
      plan: plan, // Set plan
      stripeSubscriptionStatus: stripeSubscriptionStatus, // Set status
      stripeSubscriptionId: stripeSubscriptionId, // Set sub ID
      stripeCustomerId: stripeCustomerId, // + Set stripeCustomerId
    },
  });
}

// New function to handle user lookup/creation based on Auth0 profile
export async function findOrCreateUserByAuthProfile(
  email: User["email"],
  auth0Sub: NonNullable<User["auth0Sub"]>, // Ensure auth0Sub is provided
) {
  // Try to find user by Auth0 subject first (most reliable link)
  let user = await prisma.user.findUnique({
    where: { auth0Sub },
  });

  if (user) {
    // Optional: Update email if it has changed in Auth0?
    if (user.email !== email) {
      user = await prisma.user.update({
        where: { id: user.id },
        data: { email },
      });
    }
    return user;
  }

  // If not found by auth0Sub, try by email
  user = await prisma.user.findUnique({
    where: { email },
  });

  if (user) {
    // User exists with this email but no auth0Sub, link them
    user = await prisma.user.update({
      where: { id: user.id },
      data: { auth0Sub }, // Link existing email user to Auth0 account
    });
    return user;
  }

  // If no user found by auth0Sub or email, create a new one
  return prisma.user.create({
    data: {
      email,
      auth0Sub,
    },
  });
}


export async function deleteUserByEmail(email: User["email"]) {
  return prisma.user.delete({ where: { email } });
}

// Removed verifyLogin function as Auth0 handles verification
