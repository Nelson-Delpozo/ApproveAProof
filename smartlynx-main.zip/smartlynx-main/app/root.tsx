import { cssBundleHref } from "@remix-run/css-bundle";
import type { LinksFunction, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Links,
  LiveReload,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
  Link, // Import Link for navigation
  useLoaderData, // Import useLoaderData hook
  isRouteErrorResponse, // Import for typed error handling
  useRouteError, // Import hook to access error
} from "@remix-run/react";

import { getAuthSession } from "~/auth.server"; // Changed import
import Header from "~/components/Header"; // Import the new Header component
import stylesheet from "~/tailwind.css";
import { ThemeProvider } from "~/contexts/ThemeContext"; // Import ThemeProvider

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: stylesheet },
  ...(cssBundleHref ? [{ rel: "stylesheet", href: cssBundleHref }] : []),
];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  // Use getAuthSession to get user data based on Auth0 session
  return json({ user: await getAuthSession(request) });
};

export default function App() {
  // Get the user data from the loader
  const { user } = useLoaderData<typeof loader>();

  return (
    <ThemeProvider>
      <html lang="en" className="h-full">
        <head>
          <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <Meta />
        <Links />
      </head>
      {/* Add background color and flex layout for sticky footer */}
      {/* Updated body classes for theme support */}
      <body className="flex flex-col min-h-screen bg-page-background-light dark:bg-page-background-dark text-text-light dark:text-text-dark transition-colors duration-200">
        {/* Render the Header, passing user data */}
        <Header user={user} />
        {/* Main content area that grows */}
        <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8"> {/* Added container/padding */}
          <Outlet />
        </main>
        <ScrollRestoration />
        <Scripts />
        <LiveReload />
        {/* Render the Footer */}
        <Footer />
      </body>
    </html>
  </ThemeProvider>
  );
}

// Global Error Boundary
export function ErrorBoundary() {
  const error = useRouteError();
  console.error("Root Error Boundary caught error:", error);

  // Determine the message based on the error type
  let title = "An Unexpected Error Occurred";
  let message = "We're sorry, something went wrong. Please try refreshing the page.";

  if (isRouteErrorResponse(error)) {
    title = `${error.status} ${error.statusText}`;
    switch (error.status) {
      case 401:
        message = "Oops! Looks like you don't have permission to access this page.";
        break;
      case 404:
        message = "Oops! Looks like this page doesn't exist.";
        break;
      default:
        message = error.data?.message || message; // Use server message if available
    }
  } else if (error instanceof Error) {
    // You might want to log error.stack here in a real app
    // For security, don't display stack trace to the user in production
    // message = error.message; // Potentially display generic message instead
  }

  return (
    <html lang="en" className="h-full">
      <head>
        <title>{title}</title>
        <Meta />
        <Links />
      </head>
      <body className="flex flex-col items-center justify-center min-h-screen bg-slate-100 text-center p-4">
        <div className="bg-white p-8 rounded shadow-md">
          <h1 className="text-2xl font-bold text-red-600 mb-4">{title}</h1>
          <p className="text-gray-700 mb-6">{message}</p>
          <Link
            to="/"
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition duration-200"
          >
            Go to Homepage
          </Link>
        </div>
        <Scripts />
      </body>
    </html>
  );
}


// Simple Footer Component
function Footer() {
  const currentYear = new Date().getFullYear();
  return (
    // Updated footer classes for theme support
    <footer className="mt-auto py-4 px-4 text-center text-xs text-neutral-500 dark:text-neutral-400 bg-page-background-light dark:bg-page-background-dark border-t border-border-light dark:border-border-dark transition-colors duration-200">
      <div className="container mx-auto flex justify-center items-center gap-4">
        <span>© {currentYear} SmartLynx. All rights reserved.</span>
        <Link to="/privacy" className="hover:text-primary-600 dark:hover:text-primary-400 hover:underline">Privacy Policy</Link>
        <Link to="/terms-of-service" className="hover:text-primary-600 dark:hover:text-primary-400 hover:underline">Terms of Service</Link>
      </div>
    </footer>
  );
}
