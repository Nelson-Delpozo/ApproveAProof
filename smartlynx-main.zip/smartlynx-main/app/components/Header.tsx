import { Link } from "@remix-run/react";
import { ThemeToggle } from '~/components/ThemeToggle'; // Import ThemeToggle

// Define the props for the Header component
// We expect a user object (or null if not logged in)
interface HeaderProps {
  // Define the expected user structure based on common auth patterns
  // or the actual return type of getAuthSession if known precisely.
  // Allowing null handles the logged-out state.
  user: {
    id: string;
    email: string;
    // Add other potential fields if needed by the header later, otherwise keep minimal
  } | null;
}

export default function Header({ user }: HeaderProps) {
  const isLoggedIn = !!user;

  return (
    // Updated header classes for theme support
    <header className="bg-card-background-light dark:bg-card-background-dark shadow-sm sticky top-0 z-10 transition-colors duration-200 border-b border-border-light dark:border-border-dark">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo/Brand Name */}
          <div className="flex-shrink-0">
            {/* Updated Link text color for theme */}
            <Link to="/" className="text-2xl font-bold text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
              SmartLynx
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            {isLoggedIn ? (
              <>
                <Link
                  to="/dashboard"
                  className="text-neutral-600 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Dashboard
                </Link>
                {/* Logout is typically handled by a form POST in Remix */}
                <form action="/logout" method="post">
                  <button
                    type="submit"
                    className="text-neutral-600 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400 px-3 py-2 rounded-md text-sm font-medium"
                  >
                    Logout
                  </button>
                </form>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-neutral-600 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  // Updated button classes for theme
                  className="bg-primary-600 hover:bg-primary-700 dark:bg-primary-500 dark:hover:bg-primary-600 text-white px-4 py-2 rounded-md text-sm font-medium shadow-sm"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}
