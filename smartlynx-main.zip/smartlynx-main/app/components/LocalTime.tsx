import { useEffect, useState } from "react";
import { parseISO } from 'date-fns';

export function LocalTime({ iso }: { iso: string }) {
  // Initialize with the ISO string itself as a fallback during SSR
  // or return null/empty string if preferred initial state is blank
  const [local, setLocal] = useState("");

  useEffect(() => {
    // This effect runs only on the client after hydration
    try {
      if (!iso) {
        return;
      }

      // Parse the ISO string to a Date object
      // Handle all possible timezone formats:
      // 1. With 'Z' suffix (e.g., 2025-04-26T02:32:00.000Z)
      // 2. With '+00' timezone (e.g., 2025-05-01 22:15:00+00)
      // 3. With no timezone info (e.g., 2025-05-01 22:15:00)
      // Use parseISO for robust ISO string parsing
      const date = parseISO(iso);
      
      // Check if the date is valid before formatting
      if (!isNaN(date.getTime())) {
        // Use toLocaleString with explicit options for consistent formatting
        setLocal(date.toLocaleString(undefined, {
          year: 'numeric',
          month: 'numeric',
          day: 'numeric',
          hour: 'numeric',
          minute: 'numeric',
          hour12: true
        }));
      } else {
        // Optionally setLocal to an error string or empty if date is invalid
        // For now, it will just keep the initial `local` state (empty string)
      }
    } catch (error) {
      // Keep initial state or set an error message
      // For now, it will just keep the initial `local` state (empty string) on error
    }
  }, [iso]); // Re-run if the iso prop changes

  // Render the client-formatted date, or the initial state (empty string during SSR)
  return <>{local}</>;
}
