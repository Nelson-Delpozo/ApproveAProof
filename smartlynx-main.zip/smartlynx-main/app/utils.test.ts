import { describe, test, expect } from "vitest";

import { validateEmail, formatDateTimeLocal, parseLocalDateTime } from "./utils";

test("validateEmail returns false for non-emails", () => {
  expect(validateEmail(undefined)).toBe(false);
  expect(validateEmail(null)).toBe(false);
  expect(validateEmail("")).toBe(false);
  expect(validateEmail("not-an-email")).toBe(false);
  expect(validateEmail("n@")).toBe(false);
});

test("validateEmail returns true for emails", () => {
  expect(validateEmail("kody@example.com")).toBe(true);
});

// Tests for the new date-time functions
describe("Date-time utility functions", () => {
  test("formatDateTimeLocal formats a date correctly", () => {
    // Create a date with a specific UTC time
    const utcDate = new Date(Date.UTC(2025, 3, 22, 16, 30, 0)); // April 22, 2025, 16:30:00 UTC
    
    // Format the date
    const formatted = formatDateTimeLocal(utcDate);
    
    // Check the format is correct (YYYY-MM-DDTHH:MM)
    expect(formatted).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/);
  });
  
  test("parseLocalDateTime parses a date string correctly", () => {
    // Create a date-time string in local format
    const dateTimeString = "2025-04-22T12:30";
    
    // Parse the date
    const parsed = parseLocalDateTime(dateTimeString, "UTC"); // Provide a timezone
    
    // Verify it's a valid Date object
    expect(parsed instanceof Date).toBe(true);
    expect(isNaN(parsed.getTime())).toBe(false); // This was the failing assertion, should now pass
  });
  
  test("parseLocalDateTime correctly interprets local time with a specific timezone", () => {
    const localDateTimeString = "2025-04-22T16:00"; // 4:00 PM
    const clientTimezone = "America/New_York"; 
    
    // Parse using our function, providing the client's timezone
    const parsedDate = parseLocalDateTime(localDateTimeString, clientTimezone);
    
    // Expected UTC: April 22, 2025, 16:00 EDT (UTC-4) is 2025-04-22T20:00:00Z
    // Note: Date.UTC month is 0-indexed, so April is 3.
    const expectedUtcTimestamp = Date.UTC(2025, 3, 22, 20, 0, 0); 
    
    // The getTime() method returns milliseconds since epoch (UTC), so this compares the absolute point in time.
    expect(parsedDate.getTime()).toBe(expectedUtcTimestamp);
  });
});
