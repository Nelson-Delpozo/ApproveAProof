import { createCookieSessionStorage } from "@remix-run/node";
import invariant from "tiny-invariant";

// Note: Auth0 handles user authentication and session management.
// This sessionStorage might still be used by the Auth0 SDK (e.g., for state, nonce, or storing tokens).
// Custom user session logic (getUserId, getUser, createUserSession, logout) has been removed.
// The actual authentication checks and logout will be handled via Auth0 SDK integration.

invariant(process.env.SESSION_SECRET, "SESSION_SECRET must be set");

export const sessionStorage = createCookieSessionStorage({
  cookie: {
    name: "__session", // Consider if Auth0 SDK requires a specific name or uses its own cookies
    httpOnly: true,
    path: "/",
    sameSite: "lax",
    secrets: [process.env.SESSION_SECRET],
    secure: process.env.NODE_ENV === "production",
    // maxAge might be managed by Auth0 session lifetime or SDK settings
  },
});

// Removed: getSession, getUserId, getUser, requireUserId, requireUser, createUserSession, logout
// These will be replaced by Auth0 SDK functionalities.
