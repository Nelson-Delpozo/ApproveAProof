import sgMail from "@sendgrid/mail";
import invariant from "tiny-invariant";

// Moved API key check and setting inside the function

interface EmailOptions {
  to: string;
  from: string; // Consider having a default 'from' address
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail({
  to,
  from,
  subject,
  text,
  html,
}: EmailOptions): Promise<void> {
  // Check and set API key only when the function is actually called
  invariant(process.env.SENDGRID_API_KEY, "SENDGRID_API_KEY must be set");
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);

  const msg = {
    to,
    from, // TODO: Use a verified sender address from SendGrid
    subject,
    text,
    html,
  };

  try {
    console.log(`Attempting to send email to ${to} with subject "${subject}"`);
    // TODO: Ensure SENDGRID_API_KEY is valid and sender is verified in production
    // Use type assertion to satisfy strict type checking
    await sgMail.send(msg as sgMail.MailDataRequired);
    console.log(`Email successfully sent to ${to}`); // Removed (simulated)
    // In a real app, you might want more robust logging or tracking here
  } catch (error) {
    console.error("Error sending email via SendGrid:", error);
    // Handle specific SendGrid errors if necessary
    // Re-throw or handle the error appropriately for the calling context
    throw new Error("Failed to send email.");
  }
}

// Example usage (for testing or other modules):
/*
await sendEmail({
  to: 'test@example.com',
  from: 'noreply@yourdomain.com', // Use your verified sender
  subject: 'Test Email from SmartLynx',
  text: 'This is a test email.',
  html: '<strong>This is a test email.</strong>',
});
*/
