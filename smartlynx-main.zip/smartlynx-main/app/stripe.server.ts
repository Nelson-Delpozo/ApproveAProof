import Stripe from 'stripe';
import invariant from 'tiny-invariant';

invariant(process.env.STRIPE_SECRET_KEY, 'STRIPE_SECRET_KEY must be set');

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2025-03-31.basil', // Use the latest API version
  typescript: true,
});

// You might add helper functions here later, e.g., for retrieving
// Stripe customer data or managing subscriptions, if needed elsewhere.
// Re-saving to check for TS errors after clean install.
