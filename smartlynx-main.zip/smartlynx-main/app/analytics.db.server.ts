import { PrismaClient } from "@prisma/analytics-client";
import invariant from "tiny-invariant";

import { singleton } from "./singleton.server";

// Hard-code a unique key, so we can look up the client when this module gets re-imported
const prismaAnalytics = singleton("prismaAnalytics", () => {
  const logThreshold = 0; // Or longer time in milliseconds, e.g. 50
  const client = new PrismaClient({
    log: [
      { level: "query", emit: "event" },
      { level: "error", emit: "stdout" },
      { level: "warn", emit: "stdout" },
    ],
  });
  client.$on("query", (e) => {
    if (e.duration < logThreshold) return;
    // eslint-disable-next-line no-console
    console.log(`prisma:query - ${e.duration}ms - ${e.query}`);
  });
  client.$connect();
  return client;
});

// Ensure ANALYTICS_DATABASE_URL is set
invariant(
  process.env.ANALYTICS_DATABASE_URL,
  "ANALYTICS_DATABASE_URL must be set",
);

export { prismaAnalytics };
