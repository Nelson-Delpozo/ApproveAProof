/// <reference types="vitest" />
/// <reference types="vite/client" />

import react from "@vitejs/plugin-react";
import tsconfigPaths from "vite-tsconfig-paths";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [react(), tsconfigPaths()],
  // Specify the directory where .env files are located
  envDir: ".", // Project root
  test: {
    globals: true,
    environment: "happy-dom", // or 'jsdom', 'node' depending on needs
    // Ensure .env.test is loaded (Vitest might do this by default with envDir, but explicit is safer)
    // Alternatively, use `dotenv` package in setupFiles if needed.
    setupFiles: ["./test/setup-test-env.ts"],
  },
});
