# Remix Indie Stack

![The Remix Indie Stack](https://repository-images.githubusercontent.com/465928257/a241fa49-bd4d-485a-a2a5-5cb8e4ee0abf)

Learn more about [Remix Stacks](https://remix.run/stacks).

```sh
npx create-remix@latest --template remix-run/indie-stack
```

## What's in the stack

- [Fly app deployment](https://fly.io) with [Docker](https://www.docker.com/)
- Production-ready [SQLite Database](https://sqlite.org)
- Healthcheck endpoint for [Fly backups region fallbacks](https://fly.io/docs/reference/configuration/#services-http_checks)
- [GitHub Actions](https://github.com/features/actions) for deploy on merge to production and staging environments
- Email/Password Authentication with [cookie-based sessions](https://remix.run/utils/sessions#md-createcookiesessionstorage)
- Database ORM with [Prisma](https://prisma.io)
- Styling with [Tailwind](https://tailwindcss.com/)
- End-to-end testing with [Cypress](https://cypress.io)
- Local third party request mocking with [MSW](https://mswjs.io)
- Unit testing with [Vitest](https://vitest.dev) and [Testing Library](https://testing-library.com)
- Code formatting with [Prettier](https://prettier.io)
- Linting with [ESLint](https://eslint.org)
- Static Types with [TypeScript](https://typescriptlang.org)

Not a fan of bits of the stack? Fork it, change it, and use `npx create-remix --template your/repo`! Make it your own.

## Quickstart

Click this button to create a [Gitpod](https://gitpod.io) workspace with the project set up and Fly pre-installed

[![Gitpod Ready-to-Code](https://img.shields.io/badge/Gitpod-Ready--to--Code-blue?logo=gitpod)](https://gitpod.io/#https://github.com/remix-run/indie-stack/tree/main)

## Local Development Setup

This project uses Docker Compose to run local PostgreSQL databases for development and testing, ensuring isolation from production data.

**Prerequisites:**

*   [Node.js](https://nodejs.org/) (Check `package.json` for version) and [npm](https://www.npmjs.com/)
*   [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running.

**Steps:**

1.  **Clone the Repository:**
    ```sh
    git clone <your-repo-url>
    cd smartlynx
    ```

2.  **Install Dependencies:**
    ```sh
    npm install
    ```

3.  **Configure Environment Variables:**
    *   Copy the example environment file:
        ```sh
        cp .env.example .env
        ```
    *   **Important:** Open `docker-compose.yml` and replace `yoursecurepassword` with strong, unique passwords for both `db_main` and `db_analytics`.
    *   Open the newly created `.env` file.
    *   Update `DATABASE_URL` and `ANALYTICS_DATABASE_URL` to use the passwords you set in `docker-compose.yml`. The format should be:
        ```dotenv
        DATABASE_URL="postgresql://postgres:your_main_db_password@localhost:5432/smartlynx_dev"
        ANALYTICS_DATABASE_URL="postgresql://postgres:your_analytics_db_password@localhost:5433/smartlynx_analytics_dev"
        ```
    *   Fill in any other required secrets (Session Secret, API keys for Auth0, AWS S3, SendGrid, Stripe, etc.) for local development.
    *   **Ensure `.env` is listed in your `.gitignore` file.**

4.  **Start Local Databases:**
    *   Make sure Docker Desktop is running.
    *   In your terminal (in the project root), run:
        ```sh
        docker compose up -d
        ```
    *   This command will download the PostgreSQL images (if needed) and start the database containers in the background. Wait for it to complete.

5.  **Apply Database Migrations:**
    *   Run the following commands one by one to set up the database schemas:
        ```sh
        npx prisma migrate dev --schema=prisma/schema.prisma
        npx prisma migrate dev --schema=prisma/analytics.schema.prisma
        ```

6.  **(Optional) Seed Databases:**
    *   If you want to populate your local databases with initial test data:
        ```sh
        npm run seed
        ```

7.  **Start Development Server:**
    ```sh
    npm run dev
    ```
    *   This starts the Remix application, which will now connect to your local Docker databases.

**Viewing Local Databases:**

*   You can easily view and interact with the data in your local databases using Prisma Studio.
*   To view the **main** database (`smartlynx_dev`):
    ```sh
    npx prisma studio --schema=prisma/schema.prisma
    ```
*   To view the **analytics** database (`smartlynx_analytics_dev`):
    ```sh
    npx prisma studio --schema=prisma/analytics.schema.prisma
    ```
*   These commands will open a GUI in your web browser.

## Deployment

This project is configured for deployment on Vercel.

### Vercel Environment Configuration

When deploying to Vercel, it's crucial to configure environment variables correctly for different environments (Production vs. Preview).

1.  **Environment Scopes:** In your Vercel project settings (Settings -> Environment Variables), use the **Scopes** feature to assign different values for Production and Preview environments.
2.  **Database URLs:**
    *   Set `DATABASE_URL` and `ANALYTICS_DATABASE_URL` for the **Production** scope using your production Neon branch connection strings.
    *   Set `DATABASE_URL` and `ANALYTICS_DATABASE_URL` for the **Preview** scope using your development/preview Neon branch connection strings.
3.  **Stripe Keys:**
    *   Set Stripe variables (`STRIPE_SECRET_KEY`, `STRIPE_PUBLIC_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRO_PRICE_ID`) for the **Production** scope using your **Live** Stripe keys and Price ID.
    *   Set Stripe variables for the **Preview** scope using your **Test** Stripe keys and Price ID.
4.  **Auth0 URLs:**
    *   **Vercel:**
        *   Set `AUTH0_CALLBACK_URL` for the **Preview** scope. Recommended value: `https://${VERCEL_URL}/callback` (uses Vercel's system variable).
        *   Set `AUTH0_LOGOUT_URL` for the **Preview** scope. Recommended value: `https://${VERCEL_URL}`.
        *   Set the appropriate production domain URLs for these variables in the **Production** scope.
    *   **Auth0 Dashboard:**
        *   Go to your Auth0 Application settings.
        *   In "Allowed Callback URLs", add the URL pattern for your Vercel previews (e.g., `https://*-your-org.vercel.app/callback` or your specific preview domain pattern) **in addition to** your production callback URL.
        *   In "Allowed Logout URLs", add the URL pattern for your Vercel previews (e.g., `https://*-your-org.vercel.app` or your specific preview domain pattern) **in addition to** your production logout URL.
5.  **Other Variables:** Configure other secrets (SendGrid, AWS, Session Secret) appropriately for each scope as needed.

### Automatic Deployments (Requires Working Git Integration)

*   Configure Vercel (Settings -> Git) to connect to your GitHub repository.
*   Set `main` as the **Production Branch**.
*   Ensure Preview deployments are enabled for other branches (like `develop`) under the Git settings (e.g., "Deploy all unassigned git branches").
*   Pushes to `main` will trigger Production deployments.
*   Pushes to `develop` (or other configured preview branches) will trigger Preview deployments with unique URLs.

*(Note: The following Fly.io deployment instructions are from the original template and may not be applicable if deploying solely to Vercel)*

Prior to your first deployment, you'll need to do a few things:

- [Install Fly](https://fly.io/docs/getting-started/installing-flyctl/)

- Sign up and log in to Fly

  ```sh
  fly auth signup
  ```

  > **Note:** If you have more than one Fly account, ensure that you are signed into the same account in the Fly CLI as you are in the browser. In your terminal, run `fly auth whoami` and ensure the email matches the Fly account signed into the browser.

- Create two apps on Fly, one for staging and one for production:

  ```sh
  fly apps create smartlynx-b62e
  fly apps create smartlynx-b62e-staging
  ```

  > **Note:** Make sure this name matches the `app` set in your `fly.toml` file. Otherwise, you will not be able to deploy.

  - Initialize Git.

  ```sh
  git init
  ```

- Create a new [GitHub Repository](https://repo.new), and then add it as the remote for your project. **Do not push your app yet!**

  ```sh
  git remote add origin <ORIGIN_URL>
  ```

- Add a `FLY_API_TOKEN` to your GitHub repo. To do this, go to your user settings on Fly and create a new [token](https://web.fly.io/user/personal_access_tokens/new), then add it to [your repo secrets](https://docs.github.com/en/actions/security-guides/encrypted-secrets) with the name `FLY_API_TOKEN`.

- Add a `SESSION_SECRET` to your fly app secrets, to do this you can run the following commands:

  ```sh
  fly secrets set SESSION_SECRET=$(openssl rand -hex 32) --app smartlynx-b62e
  fly secrets set SESSION_SECRET=$(openssl rand -hex 32) --app smartlynx-b62e-staging
  ```

  If you don't have openssl installed, you can also use [1Password](https://1password.com/password-generator) to generate a random secret, just replace `$(openssl rand -hex 32)` with the generated secret.

- Create a persistent volume for the sqlite database for both your staging and production environments. Run the following:

  ```sh
  fly volumes create data --size 1 --app smartlynx-b62e
  fly volumes create data --size 1 --app smartlynx-b62e-staging
  ```

Now that everything is set up you can commit and push your changes to your repo. Every commit to your `main` branch will trigger a deployment to your production environment, and every commit to your `dev` branch will trigger a deployment to your staging environment.

### Connecting to your database

The sqlite database lives at `/data/sqlite.db` in your deployed application. You can connect to the live database by running `fly ssh console -C database-cli`.

### Getting Help with Deployment

If you run into any issues deploying to Fly, make sure you've followed all of the steps above and if you have, then post as many details about your deployment (including your app name) to [the Fly support community](https://community.fly.io). They're normally pretty responsive over there and hopefully can help resolve any of your deployment issues and questions.

## GitHub Actions

We use GitHub Actions for continuous integration and deployment. Anything that gets into the `main` branch will be deployed to production after running tests/build/etc. Anything in the `dev` branch will be deployed to staging.

## Testing

### Cypress

We use Cypress for our End-to-End tests in this project. You'll find those in the `cypress` directory. As you make changes, add to an existing file or create a new file in the `cypress/e2e` directory to test your changes.

We use [`@testing-library/cypress`](https://testing-library.com/cypress) for selecting elements on the page semantically.

To run these tests in development, run `npm run test:e2e:dev` which will start the dev server for the app as well as the Cypress client. Make sure the database is running in docker as described above.

We have a utility for testing authenticated features without having to go through the login flow:

```ts
cy.login();
// you are now logged in as a new user
```

We also have a utility to auto-delete the user at the end of your test. Just make sure to add this in each test file:

```ts
afterEach(() => {
  cy.cleanupUser();
});
```

That way, we can keep your local db clean and keep your tests isolated from one another.

### Vitest

For lower level tests of utilities and individual components, we use `vitest`. We have DOM-specific assertion helpers via [`@testing-library/jest-dom`](https://testing-library.com/jest-dom).

### Type Checking

This project uses TypeScript. It's recommended to get TypeScript set up for your editor to get a really great in-editor experience with type checking and auto-complete. To run type checking across the whole project, run `npm run typecheck`.

### Linting

This project uses ESLint for linting. That is configured in `.eslintrc.cjs`.

### Formatting

We use [Prettier](https://prettier.io/) for auto-formatting in this project. It's recommended to install an editor plugin (like the [VSCode Prettier plugin](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)) to get auto-formatting on save. There's also a `npm run format` script you can run to format all files in the project.
