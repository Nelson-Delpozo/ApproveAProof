import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function seed() {
  const email = "rachel@remix.run";

  // cleanup the existing database
  await prisma.user.delete({ where: { email } }).catch(() => {
    // no worries if it doesn't exist yet
  });

  const user = await prisma.user.create({
    data: {
      email,
      // No password needed, Auth0 handles it
      // Optionally add a default plan or other fields if desired for the seed user
      plan: "FREE", // Example: Set default plan for seed user
    },
  });

  // Removed Note creation as the model is gone
  // await prisma.note.create({ ... });
  // await prisma.note.create({ ... });

  console.log(`Database has been seeded with user ${user.email}. 🌱`);
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
