/*
  Warnings:

  - You are about to drop the column `eventType` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `geoCity` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `geoCountry` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `ipAddress` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `linkId` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `timestamp` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `userAgent` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - Added the required column `sharedLinkId` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.
  - Added the required column `type` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT "AnalyticsEvent_linkId_fkey";

-- AlterTable
ALTER TABLE "AnalyticsEvent" DROP COLUMN "eventType",
DROP COLUMN "geoCity",
DROP COLUMN "geoCountry",
DROP COLUMN "ipAddress",
DROP COLUMN "linkId",
DROP COLUMN "timestamp",
DROP COLUMN "userAgent",
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "sharedLinkId" TEXT NOT NULL,
ADD COLUMN     "type" TEXT NOT NULL;

-- CreateIndex
CREATE INDEX "AnalyticsEvent_sharedLinkId_type_idx" ON "AnalyticsEvent"("sharedLinkId", "type");

-- AddForeignKey
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_sharedLinkId_fkey" FOREIGN KEY ("sharedLinkId") REFERENCES "SharedLink"("id") ON DELETE CASCADE ON UPDATE CASCADE;
