/*
  Warnings:

  - You are about to drop the column `eventType` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `sharedLinkId` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `timestamp` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `accessKey` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `description` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `expiresAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `fileSizeBytes` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `fileType` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `originalFileName` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `revoked` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `storageKey` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the `User` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `linkId` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.
  - Added the required column `type` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "EventType" AS ENUM ('VIEW', 'DOWNLOAD', 'SHARE');

-- DropForeignKey
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT "AnalyticsEvent_sharedLinkId_fkey";

-- DropForeignKey
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT "AnalyticsEvent_userId_fkey";

-- DropForeignKey
ALTER TABLE "SharedLink" DROP CONSTRAINT "SharedLink_userId_fkey";

-- DropIndex
DROP INDEX "AnalyticsEvent_sharedLinkId_idx";

-- DropIndex
DROP INDEX "AnalyticsEvent_userId_idx";

-- DropIndex
DROP INDEX "SharedLink_accessKey_key";

-- AlterTable
ALTER TABLE "AnalyticsEvent" DROP COLUMN "eventType",
DROP COLUMN "sharedLinkId",
DROP COLUMN "timestamp",
DROP COLUMN "userId",
ADD COLUMN     "country" TEXT,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "linkId" TEXT NOT NULL,
ADD COLUMN     "referer" TEXT,
ADD COLUMN     "type" "EventType" NOT NULL,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "SharedLink" DROP COLUMN "accessKey",
DROP COLUMN "createdAt",
DROP COLUMN "description",
DROP COLUMN "expiresAt",
DROP COLUMN "fileSizeBytes",
DROP COLUMN "fileType",
DROP COLUMN "originalFileName",
DROP COLUMN "revoked",
DROP COLUMN "storageKey",
DROP COLUMN "updatedAt",
DROP COLUMN "userId";

-- DropTable
DROP TABLE "User";

-- CreateIndex
CREATE INDEX "AnalyticsEvent_linkId_createdAt_idx" ON "AnalyticsEvent"("linkId", "createdAt" DESC);

-- AddForeignKey
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_linkId_fkey" FOREIGN KEY ("linkId") REFERENCES "SharedLink"("id") ON DELETE CASCADE ON UPDATE CASCADE;
