/*
  Warnings:

  - You are about to drop the column `createdAt` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `sharedLinkId` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - You are about to drop the column `type` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - Added the required column `eventType` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.
  - Added the required column `linkId` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT "AnalyticsEvent_sharedLinkId_fkey";

-- DropIndex
DROP INDEX "AnalyticsEvent_sharedLinkId_type_idx";

-- AlterTable
ALTER TABLE "AnalyticsEvent" DROP COLUMN "createdAt",
DROP COLUMN "sharedLinkId",
DROP COLUMN "type",
ADD COLUMN     "eventType" TEXT NOT NULL,
ADD COLUMN     "linkId" TEXT NOT NULL,
ADD COLUMN     "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- CreateIndex
CREATE INDEX "AnalyticsEvent_linkId_eventType_idx" ON "AnalyticsEvent"("linkId", "eventType");

-- AddForeignKey
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_linkId_fkey" FOREIGN KEY ("linkId") REFERENCES "SharedLink"("id") ON DELETE CASCADE ON UPDATE CASCADE;
