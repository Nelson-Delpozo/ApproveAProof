/*
  Warnings:

  - You are about to drop the `AnalyticsEvent` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[accessKey]` on the table `SharedLink` will be added. If there are existing duplicate values, this will fail.
  - The required column `accessKey` was added to the `SharedLink` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `fileSizeBytes` to the `SharedLink` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fileType` to the `SharedLink` table without a default value. This is not possible if the table is not empty.
  - Added the required column `originalFileName` to the `SharedLink` table without a default value. This is not possible if the table is not empty.
  - Added the required column `storageKey` to the `SharedLink` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `SharedLink` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userId` to the `SharedLink` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "SharedLink" ADD COLUMN     "accessKey" TEXT NOT NULL,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "description" TEXT,
ADD COLUMN     "expiresAt" TIMESTAMPTZ,
ADD COLUMN     "fileSizeBytes" INTEGER NOT NULL,
ADD COLUMN     "fileType" TEXT NOT NULL,
ADD COLUMN     "originalFileName" TEXT NOT NULL,
ADD COLUMN     "revoked" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "storageKey" TEXT NOT NULL,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "userId" TEXT NOT NULL;

-- DropTable
DROP TABLE "AnalyticsEvent";

-- DropEnum
DROP TYPE "EventType";

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "auth0Sub" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "stripeCustomerId" TEXT,
    "stripeSubscriptionId" TEXT,
    "stripeSubscriptionStatus" TEXT,
    "plan" TEXT,
    "brandingLogoUrl" TEXT,
    "brandingColorPrimary" TEXT,
    "brandingColorText" TEXT,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "User_auth0Sub_key" ON "User"("auth0Sub");

-- CreateIndex
CREATE UNIQUE INDEX "User_stripeCustomerId_key" ON "User"("stripeCustomerId");

-- CreateIndex
CREATE UNIQUE INDEX "User_stripeSubscriptionId_key" ON "User"("stripeSubscriptionId");

-- CreateIndex
CREATE UNIQUE INDEX "SharedLink_accessKey_key" ON "SharedLink"("accessKey");

-- AddForeignKey
ALTER TABLE "SharedLink" ADD CONSTRAINT "SharedLink_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
