/*
  Warnings:

  - You are about to drop the column `linkId` on the `AnalyticsEvent` table. All the data in the column will be lost.
  - Added the required column `sharedLinkId` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userId` to the `AnalyticsEvent` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT "AnalyticsEvent_linkId_fkey";

-- DropIndex
DROP INDEX "AnalyticsEvent_linkId_eventType_idx";

-- AlterTable
ALTER TABLE "AnalyticsEvent" DROP COLUMN "linkId",
ADD COLUMN     "sharedLinkId" TEXT NOT NULL,
ADD COLUMN     "userId" TEXT NOT NULL,
ALTER COLUMN "eventType" SET DEFAULT 'VIEW';

-- CreateIndex
CREATE INDEX "AnalyticsEvent_sharedLinkId_idx" ON "AnalyticsEvent"("sharedLinkId");

-- CreateIndex
CREATE INDEX "AnalyticsEvent_userId_idx" ON "AnalyticsEvent"("userId");

-- AddForeignKey
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_sharedLinkId_fkey" FOREIGN KEY ("sharedLinkId") REFERENCES "SharedLink"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
