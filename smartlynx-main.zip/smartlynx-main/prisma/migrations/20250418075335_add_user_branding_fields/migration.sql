-- AlterTable
ALTER TABLE "User" ADD COLUMN     "brandingColorPrimary" TEXT,
ADD COLUMN     "brandingColorText" TEXT,
ADD COLUMN     "brandingLogoUrl" TEXT;
