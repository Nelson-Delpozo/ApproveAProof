-- AlterTable
ALTER TABLE "AnalyticsEvent" ADD COLUMN     "ipAddress" TEXT,
ADD COLUMN     "recipientEmail" TEXT,
ADD COLUMN     "userAgent" TEXT,
ALTER COLUMN "eventType" DROP DEFAULT;
