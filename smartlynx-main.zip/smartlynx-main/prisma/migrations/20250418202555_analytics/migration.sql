/*
  Warnings:

  - You are about to drop the column `accessKey` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `description` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `expiresAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `fileSizeBytes` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `fileType` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `originalFileName` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `revoked` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `storageKey` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `SharedLink` table. All the data in the column will be lost.
  - You are about to drop the `User` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "EventType" AS ENUM ('VIEW', 'DOWNLOAD', 'SHARE');

-- DropForeignKey
ALTER TABLE "SharedLink" DROP CONSTRAINT "SharedLink_userId_fkey";

-- DropIndex
DROP INDEX "SharedLink_accessKey_key";

-- AlterTable
ALTER TABLE "SharedLink" DROP COLUMN "accessKey",
DROP COLUMN "createdAt",
DROP COLUMN "description",
DROP COLUMN "expiresAt",
DROP COLUMN "fileSizeBytes",
DROP COLUMN "fileType",
DROP COLUMN "originalFileName",
DROP COLUMN "revoked",
DROP COLUMN "storageKey",
DROP COLUMN "updatedAt",
DROP COLUMN "userId";

-- DropTable
DROP TABLE "User";

-- CreateTable
CREATE TABLE "AnalyticsEvent" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "type" "EventType" NOT NULL,
    "linkId" TEXT NOT NULL,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "referer" TEXT,
    "country" TEXT,
    "recipientEmail" TEXT,

    CONSTRAINT "AnalyticsEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "AnalyticsEvent_linkId_createdAt_idx" ON "AnalyticsEvent"("linkId", "createdAt" DESC);
